package com.example.spiderrunner

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.atan2
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var view: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = GameView(this)
        setContentView(view)
        hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() {
        super.onPause()
        view.pauseGame()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!view.onBack()) super.onBackPressed()
    }
}

private fun K(rgb: Int): Int = rgb or -0x1000000

private fun hash(a: Int): Int {
    var x = a * -1640531527
    x = x xor (x ushr 15)
    x *= 0x2c1b3c6d
    x = x xor (x ushr 12)
    return x and 0x7fffffff
}

class Building {
    var x = 0f; var w = 0f; var top = 0f
    var style = 0; var deco = 0; var seed = 0
    var hasAnchor = false; var ax = 0f; var ay = 0f
}

class Item(val id: Int, val x: Float, val y: Float, val w: Float, val h: Float)

class GameView(private val ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback {

    companion object {
        const val LH = 216
        const val G = 1100f
        const val STEP = 1f / 120f
        const val JUMP_V = 335f
        const val HW = 5f
        const val STREET_Y = 288f
        const val DEATH_Y = 296f
        const val ZIP_RANGE = 310f
        const val PX_PER_M = 8f
        const val FW = 64
        const val PVX = 31
        const val PVY = 32
        const val BH = 512
        const val WS = BH / 216f

        const val ST_MENU = 0; const val ST_PLAY = 1; const val ST_PAUSE = 2
        const val ST_OVER = 3; const val ST_EDIT = 4

        const val P_RUN = 0; const val P_AIR = 1; const val P_SWING = 2
        const val P_ZIP = 3; const val P_WALL = 4

        const val ID_PLAY = 1; const val ID_SUIT = 2; const val ID_GFX = 3; const val ID_FPS = 4
        const val ID_SND = 5; const val ID_CTRL = 6; const val ID_DIAG = 7; const val ID_EXIT = 8
        const val ID_RESUME = 9; const val ID_RESTART = 10; const val ID_MENU = 11
        const val ID_DONE = 12; const val ID_RESET = 13; const val ID_SIZEP = 14
        const val ID_SIZEM = 15; const val ID_OPAC = 16
    }

    private val SKY = IntArray(12)
    private val BASE = intArrayOf(K(0xB5553A), K(0x9C9C98), K(0x8CC3D8))
    private val DARK = intArrayOf(K(0x8A3D2A), K(0x6F6F72), K(0x5E98B4))
    private val LIGHT = intArrayOf(K(0xCB6B4B), K(0xB9B6AC), K(0xBFE4F0))
    private val CREAM = K(0xEADFC4)
    private val INK = K(0x14202E)
    private val WHITE = K(0xFFFFFF)
    private val BRICKLINE = K(0xA04A33)
    private val WIN_DARK = K(0x34495E)
    private val WIN_LIT = K(0xF2D98B)
    private val WIN_GLASS = K(0xB5DCEC)
    private val WIN_GLASS_B = K(0x7FB5CC)
    private val SILL = K(0xD8CBB0)
    private val STEEL = K(0x59606B)
    private val WOOD = K(0x8B5A3C)
    private val WOOD_L = K(0xA9744F)
    private val WOOD_D = K(0x5E3B26)
    private val GRAYL = K(0xB4B7BB)
    private val GRAYD = K(0x7C8087)
    private val GREEN = K(0x4E9A4A)
    private val GREEN_D = K(0x2F6B33)
    private val RED = K(0xC62F2F)
    private val BLUE = K(0x2B4FA8)
    private val LIGHTB = K(0x5C80D6)
    private val SUIT_A = intArrayOf(K(0xD62828), K(0x23232E), K(0xF08A24))
    private val SUIT_B = intArrayOf(K(0x1D3F9E), K(0xB01E1E), K(0x6A2C91))
    private val SUIT_NAME = arrayOf("CLASSIC", "MIDNIGHT", "SUNRISE")
    private val SUIT_REQ = intArrayOf(0, 500, 1500)
    private val FPS_OPTS = intArrayOf(30, 45, 60, 90)
    private val GFX_NAME = arrayOf("LOW", "MED", "HIGH")

    private val lock = Any()
    private val prefs = ctx.getSharedPreferences("rooftop_hero", Context.MODE_PRIVATE)
    private var bmp: Bitmap? = null
    private var cv: Canvas? = null
    private var lw = 384
    private var scale = 1f
    private val p = Paint()
    private val srcR = Rect(); private val dstR = Rect(); private val blitP = Paint()
    private var loop: Loop? = null
    private var tone: ToneGenerator? = null
    private var lastSfx = 0L

    private var gfx = 1; private var fpsI = 2; private var snd = 2; private var diag = false
    private var suit = 0; private var best = 0; private var runs = 0; private var totalM = 0
    private var opac = 0.55f
    private val bx = FloatArray(4); private val by = FloatArray(4); private val bs = FloatArray(4)
    private val defBx = floatArrayOf(0.90f, 0.10f, 0.76f, 0.94f)
    private val defBy = floatArrayOf(0.74f, 0.74f, 0.84f, 0.10f)
    private val defBs = floatArrayOf(46f, 40f, 36f, 20f)
    private val btnDown = BooleanArray(4)
    private val ptr = IntArray(16) { -1 }
    private var sel = 0

    private var st = ST_MENU
    private var editFrom = ST_MENU
    private var time = 0f
    private var acc = 0f
    private var menuItems = arrayOf<Item>()
    private var pauseItems = arrayOf<Item>()
    private var overItems = arrayOf<Item>()
    private var editItems = arrayOf<Item>()

    private val world = ArrayDeque<Building>()
    private val pool = ArrayList<Building>()
    private var genX = 0f
    private var lastTop = 150f
    private var runSeed = 1
    private var rng = java.util.Random(1)

    private var px = 0f; private var py = 150f; private var vx = 0f; private var vy = 0f
    private var ps = P_RUN
    private var airT = 0f; private var coyote = 0f; private var jumpBuf = 0f
    private var jumped = false; private var cut = false; private var canFlip = false
    private var landT = 0f; private var wallT = 0f; private var wallCd = 0f; private var startT = 0f
    private var shootT = 0f; private var zipCd = 0f; private var zipT = 0f
    private var runPhase = 0f
    private var wallHit = false
    private var hitB: Building? = null
    private var wallB: Building? = null
    private var jumpHeld = false; private var swingHeld = false
    private var swingPress = false; private var zipPress = false
    private var ax = 0f; private var ay = 0f; private var ropeL = 0f
    private var zTx = 0f; private var zTy = 0f
    private var cAx = 0f; private var cAy = 0f
    private var indT = 0f; private var indZip = false; private var indSwing = false
    private var iZx = 0f; private var iZy = 0f; private var iAx = 0f; private var iAy = 0f
    private var dist = 0.0
    private var lastMile = 0
    private var toast = ""; private var toastT = 0f

    private var camX = -100f; private var camY = 40f

    // Hero sprite sheet: 3 suit rows x 10 frames (0 = idle, 1..9 = run cycle), 64x64 each, drawn 1:1
    private var heroSheet: Bitmap? = null
    private val spriteP = Paint()
    private val fSrc = Rect(); private val fDst = Rect()
    private var handSx = 0f; private var handSy = 0f

    private val MAXP = 40
    private val pxs = FloatArray(MAXP); private val pys = FloatArray(MAXP)
    private val pvx = FloatArray(MAXP); private val pvy = FloatArray(MAXP)
    private val plife = FloatArray(MAXP)

    private var fpsAvg = 60f; private var frameMs = 0f
    private var visB = 0; private var activeP = 0; private var memMb = 0L; private var memT = 0f

    init {
        holder.addCallback(this)
        p.isAntiAlias = false
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        blitP.isFilterBitmap = false
        blitP.isAntiAlias = false
        for (i in SKY.indices) {
            val t = i / (SKY.size - 1f)
            val r = (0x2F + (0xC8 - 0x2F) * t).toInt()
            val g = (0x8F + (0xEA - 0x8F) * t).toInt()
            val b = (0xE8 + (0xFB - 0xE8) * t).toInt()
            SKY[i] = K((r shl 16) or (g shl 8) or b)
        }
        spriteP.isFilterBitmap = false
        spriteP.isAntiAlias = false
        try {
            val o = BitmapFactory.Options(); o.inScaled = false
            ctx.assets.open("hero.png").use { heroSheet = BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Exception) { heroSheet = null }
        loadPrefs()
        resetWorld()
        camX = -100f; camY = 40f
    }

    private fun loadPrefs() {
        gfx = prefs.getInt("gfx", 1); fpsI = prefs.getInt("fps", 2); snd = prefs.getInt("snd", 2)
        diag = prefs.getBoolean("diag", false); suit = prefs.getInt("suit", 0)
        best = prefs.getInt("best", 0); runs = prefs.getInt("runs", 0); totalM = prefs.getInt("total", 0)
        opac = prefs.getFloat("opac", 0.55f)
        resetControls()
        val s = prefs.getString("ctl", null)
        if (s != null) {
            try {
                val parts = s.split(";")
                for (i in 0 until 4) {
                    val v = parts[i].split(",")
                    bx[i] = v[0].toFloat(); by[i] = v[1].toFloat(); bs[i] = v[2].toFloat()
                }
            } catch (e: Exception) { resetControls() }
        }
        if (best < SUIT_REQ[suit]) suit = 0
    }

    private fun resetControls() {
        for (i in 0 until 4) { bx[i] = defBx[i]; by[i] = defBy[i]; bs[i] = defBs[i] }
    }

    private fun saveSettings() {
        prefs.edit().putInt("gfx", gfx).putInt("fps", fpsI).putInt("snd", snd)
            .putBoolean("diag", diag).putInt("suit", suit).putFloat("opac", opac).apply()
    }

    private fun saveControls() {
        val sb = StringBuilder()
        for (i in 0 until 4) { sb.append(bx[i]).append(',').append(by[i]).append(',').append(bs[i]); if (i < 3) sb.append(';') }
        prefs.edit().putString("ctl", sb.toString()).putFloat("opac", opac).apply()
    }

    private fun saveStats() {
        prefs.edit().putInt("best", best).putInt("runs", runs).putInt("total", totalM).apply()
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        makeTone()
        loop = Loop().also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        synchronized(lock) {
            scale = hh / LH.toFloat()
            val bw = max((320 * WS).roundToInt(), (w * BH.toFloat() / hh).roundToInt())
            lw = ceil(bw / WS).toInt()
            val b = Bitmap.createBitmap(bw, BH, Bitmap.Config.ARGB_8888)
            bmp = b; cv = Canvas(b)
            srcR.set(0, 0, bw, BH); dstR.set(0, 0, w, hh)
            buildLayouts()
        }
    }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        val l = loop
        l?.alive = false
        try { l?.join(800) } catch (e: Exception) { }
        loop = null
        tone?.release(); tone = null
    }

    fun pauseGame() {
        synchronized(lock) {
            if (st == ST_PLAY) { st = ST_PAUSE; releaseAll() }
            saveSettings(); saveControls(); saveStats()
        }
    }

    fun onBack(): Boolean {
        synchronized(lock) {
            when (st) {
                ST_PLAY -> { st = ST_PAUSE; releaseAll(); return true }
                ST_PAUSE -> { st = ST_PLAY; return true }
                ST_EDIT -> { tapItem(ID_DONE); return true }
                ST_OVER -> { toMenu(); return true }
                else -> {}
            }
        }
        return false
    }

    private inner class Loop : Thread() {
        @Volatile var alive = true
        override fun run() {
            var last = System.nanoTime()
            while (alive) {
                val t0 = System.nanoTime()
                var dt = (t0 - last) / 1e9f
                last = t0
                if (dt > 0.1f) dt = 0.1f
                synchronized(lock) { update(dt); render() }
                blit()
                val spent = System.nanoTime() - t0
                val target = 1_000_000_000L / FPS_OPTS[fpsI]
                if (spent < target) {
                    try { sleep((target - spent) / 1_000_000L, ((target - spent) % 1_000_000L).toInt()) } catch (e: Exception) { }
                }
                val full = (System.nanoTime() - t0) / 1e9f
                if (full > 0f) fpsAvg = fpsAvg * 0.92f + (1f / full) * 0.08f
                frameMs = frameMs * 0.92f + (spent / 1e6f) * 0.08f
            }
        }
    }

    private fun blit() {
        val b = bmp ?: return
        val c = try { holder.lockCanvas() } catch (e: Exception) { null } ?: return
        c.drawBitmap(b, srcR, dstR, blitP)
        try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
    }

    private fun makeTone() {
        tone?.release()
        tone = if (snd > 0) try { ToneGenerator(AudioManager.STREAM_MUSIC, intArrayOf(0, 30, 60, 100)[snd]) } catch (e: Exception) { null } else null
    }

    private fun sfx(t: Int, ms: Int = 40) {
        if (snd == 0) return
        val now = System.nanoTime()
        if (now - lastSfx < 70_000_000L) return
        lastSfx = now
        try { tone?.startTone(t, ms) } catch (e: Exception) { }
    }

    private fun buildLayouts() {
        val cx = lw / 2f
        menuItems = arrayOf(
            Item(ID_PLAY, 24f, 78f, 120f, 30f), Item(ID_SUIT, 24f, 114f, 120f, 24f),
            Item(ID_CTRL, 24f, 144f, 120f, 24f), Item(ID_EXIT, 24f, 174f, 120f, 24f),
            Item(ID_GFX, 156f, 78f, 140f, 24f), Item(ID_FPS, 156f, 108f, 140f, 24f),
            Item(ID_SND, 156f, 138f, 140f, 24f), Item(ID_DIAG, 156f, 168f, 140f, 24f))
        pauseItems = arrayOf(
            Item(ID_RESUME, cx - 60, 52f, 120f, 26f), Item(ID_RESTART, cx - 60, 84f, 120f, 26f),
            Item(ID_CTRL, cx - 60, 116f, 120f, 26f), Item(ID_MENU, cx - 60, 148f, 120f, 26f))
        overItems = arrayOf(
            Item(ID_RESTART, cx - 125, 150f, 120f, 28f), Item(ID_MENU, cx + 5, 150f, 120f, 28f))
        val x0 = cx - 158
        editItems = arrayOf(
            Item(ID_SIZEM, x0, 96f, 58f, 22f), Item(ID_SIZEP, x0 + 62, 96f, 58f, 22f),
            Item(ID_OPAC, x0 + 124, 96f, 58f, 22f), Item(ID_RESET, x0 + 186, 96f, 58f, 22f),
            Item(ID_DONE, x0 + 248, 96f, 68f, 22f))
    }

    private fun label(id: Int): String = when (id) {
        ID_PLAY -> "PLAY"
        ID_SUIT -> "SUIT " + SUIT_NAME[suit]
        ID_CTRL -> "CONTROLS"
        ID_EXIT -> "EXIT"
        ID_GFX -> "GRAPHICS " + GFX_NAME[gfx]
        ID_FPS -> "FPS " + FPS_OPTS[fpsI]
        ID_SND -> if (snd == 0) "SOUND OFF" else "SOUND " + snd
        ID_DIAG -> if (diag) "STATS ON" else "STATS OFF"
        ID_RESUME -> "RESUME"
        ID_RESTART -> if (st == ST_OVER) "RETRY" else "RESTART"
        ID_MENU -> "MENU"
        ID_DONE -> "DONE"
        ID_RESET -> "RESET"
        ID_SIZEP -> "SIZE +"
        ID_SIZEM -> "SIZE -"
        ID_OPAC -> "OPAC " + (opac * 100).toInt()
        else -> ""
    }

    private fun tapItem(id: Int) {
        sfx(ToneGenerator.TONE_PROP_BEEP, 30)
        when (id) {
            ID_PLAY -> startRun()
            ID_SUIT -> {
                var s = suit
                for (i in 0 until 3) { s = (s + 1) % 3; if (best >= SUIT_REQ[s]) break }
                suit = s; saveSettings()
            }
            ID_GFX -> { gfx = (gfx + 1) % 3; saveSettings() }
            ID_FPS -> { fpsI = (fpsI + 1) % FPS_OPTS.size; saveSettings() }
            ID_SND -> { snd = (snd + 1) % 4; makeTone(); saveSettings() }
            ID_DIAG -> { diag = !diag; saveSettings() }
            ID_CTRL -> { editFrom = st; st = ST_EDIT; sel = 0 }
            ID_EXIT -> (ctx as? Activity)?.finish()
            ID_RESUME -> st = ST_PLAY
            ID_RESTART -> startRun()
            ID_MENU -> toMenu()
            ID_DONE -> { saveControls(); st = editFrom }
            ID_RESET -> { resetControls(); opac = 0.55f; saveControls() }
            ID_SIZEP -> bs[sel] = min(bs[sel] + 4f, 80f)
            ID_SIZEM -> bs[sel] = max(bs[sel] - 4f, 14f)
            ID_OPAC -> { opac += 0.15f; if (opac > 0.9f) opac = 0.25f }
        }
    }

    private fun toMenu() {
        st = ST_MENU
        dist = 0.0
        resetWorld()
        camX = -100f; camY = 40f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        synchronized(lock) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex
                    touchDown(e.getPointerId(i), e.getX(i) / scale, e.getY(i) / scale)
                }
                MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount)
                    touchMove(e.getPointerId(i), e.getX(i) / scale, e.getY(i) / scale)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> touchUp(e.getPointerId(e.actionIndex))
                MotionEvent.ACTION_CANCEL -> releaseAll()
                else -> {}
            }
        }
        return true
    }

    private fun hitItem(list: Array<Item>, x: Float, y: Float): Item? {
        for (m in list) if (x >= m.x && x <= m.x + m.w && y >= m.y && y <= m.y + m.h) return m
        return null
    }

    private fun hitButton(x: Float, y: Float): Int {
        for (k in 3 downTo 0) {
            val r = bs[k] * 0.58f
            val cx = bx[k] * lw; val cy = by[k] * LH
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy <= r * r) return k
        }
        return -1
    }

    private fun touchDown(id: Int, x: Float, y: Float) {
        when (st) {
            ST_PLAY -> {
                val k = hitButton(x, y)
                if (k >= 0 && id < 16) { ptr[id] = k; press(k) }
            }
            ST_EDIT -> {
                val m = hitItem(editItems, x, y)
                if (m != null) tapItem(m.id)
                else { val k = hitButton(x, y); if (k >= 0 && id < 16) { sel = k; ptr[id] = k } }
            }
            else -> {
                val list = when (st) { ST_MENU -> menuItems; ST_PAUSE -> pauseItems; else -> overItems }
                val m = hitItem(list, x, y)
                if (m != null) tapItem(m.id)
            }
        }
    }

    private fun touchMove(id: Int, x: Float, y: Float) {
        if (st == ST_EDIT && id < 16 && ptr[id] >= 0) {
            val k = ptr[id]
            bx[k] = (x / lw).coerceIn(0.05f, 0.95f)
            by[k] = (y / LH).coerceIn(0.08f, 0.92f)
        }
    }

    private fun touchUp(id: Int) {
        if (id >= 16) return
        val k = ptr[id]
        if (k >= 0) {
            ptr[id] = -1
            if (st == ST_PLAY) release(k) else if (st == ST_EDIT) saveControls()
        }
    }

    private fun press(k: Int) {
        btnDown[k] = true
        when (k) {
            0 -> { jumpHeld = true; jumpBuf = 0.12f }
            1 -> { swingHeld = true; swingPress = true }
            2 -> zipPress = true
            3 -> { st = ST_PAUSE; releaseAll() }
        }
    }

    private fun release(k: Int) {
        btnDown[k] = false
        when (k) { 0 -> jumpHeld = false; 1 -> swingHeld = false }
    }

    private fun releaseAll() {
        for (i in ptr.indices) ptr[i] = -1
        for (i in 0 until 4) btnDown[i] = false
        jumpHeld = false; swingHeld = false; swingPress = false; zipPress = false
    }

    private fun diff(): Float = min(1f, (dist / PX_PER_M).toFloat() / 2000f)
    private fun targetSpeed(): Float = 105f + 135f * diff()
    private fun meters(): Int = (dist / PX_PER_M).toInt()

    private fun resetWorld() {
        while (world.isNotEmpty()) pool.add(world.removeFirst())
        genX = -120f; lastTop = 150f
        rng = java.util.Random(runSeed.toLong())
        ensureWorld(lw + 800f)
    }

    private fun ensureWorld(upTo: Float) {
        while (genX < upTo) spawn()
    }

    private fun cullWorld(behind: Float) {
        while (world.size > 3 && world.first().x + world.first().w < behind) pool.add(world.removeFirst())
    }

    private fun spawn() {
        val b = if (pool.isEmpty()) Building() else pool.removeAt(pool.size - 1)
        val d = diff()
        val reach = targetSpeed() * 0.46f
        var gap = 0f
        val w: Float
        var t: Float
        b.hasAnchor = false
        if (world.isEmpty()) {
            w = 420f; t = 150f
        } else {
            val big = rng.nextFloat() < 0.10f + 0.22f * d
            gap = if (big) min(reach * 1.5f + rng.nextFloat() * reach * (0.6f + d), 260f)
            else 16f + rng.nextFloat() * max(8f, (reach - 16f) * (0.55f + 0.45f * d))
            w = if (rng.nextFloat() < 0.35f) 160f + rng.nextFloat() * 140f
            else max(44f, (60f + rng.nextFloat() * 100f) * (1f - 0.3f * d))
            t = lastTop + (rng.nextFloat() * 2f - 1f) * (28f + 34f * d)
            t = t.coerceIn(88f, 172f)
            if (t < lastTop - 36f) t = lastTop - 36f
            if (gap > reach) t = max(t, lastTop - 14f)
        }
        b.x = genX + gap; b.w = w; b.top = t
        val r = rng.nextFloat()
        b.style = if (r < 0.45f) 0 else if (r < 0.75f) 1 else 2
        b.deco = if (w > 70f) rng.nextInt(8) else 0
        b.seed = rng.nextInt() and 0x7fffffff
        if (gap > reach * 0.85f) {
            b.hasAnchor = true
            b.ax = b.x - gap / 2f
            b.ay = min(lastTop, t) - 68f - rng.nextFloat() * 14f
        }
        genX = b.x + w
        lastTop = t
        world.addLast(b)
    }

    private fun rebase(shift: Float) {
        for (i in 0 until world.size) { val b = world[i]; b.x -= shift; b.ax -= shift }
        px -= shift; camX -= shift; genX -= shift; ax -= shift; zTx -= shift
        for (i in 0 until MAXP) plife[i] = 0f
    }

    private fun startRun() {
        runSeed = (System.nanoTime() and 0x7fffffff).toInt()
        dist = 0.0
        resetWorld()
        px = 0f; py = 150f; vx = 0f; vy = 0f; ps = P_RUN
        startT = 0.7f; landT = 0f; wallCd = 0f; zipCd = 0f; jumpBuf = 0f; coyote = 0f
        jumped = false; canFlip = false; wallB = null
        releaseAll()
        for (i in 0 until MAXP) plife[i] = 0f
        lastMile = 0; toast = ""; toastT = 0f
        camX = px - lw * 0.3f; camY = py - LH * 0.64f
        acc = 0f
        st = ST_PLAY
    }

    private fun die() {
        st = ST_OVER
        val m = meters()
        runs++; totalM += m
        if (m > best) best = m
        saveStats()
        releaseAll()
    }

    private fun update(dt: Float) {
        time += dt
        if (toastT > 0f) toastT -= dt
        when (st) {
            ST_PLAY -> {
                acc += dt
                var n = 0
                while (acc >= STEP && n < 8) { physics(STEP); acc -= STEP; n++ }
                if (n == 8) acc = 0f
                if (st == ST_PLAY) camera(dt)
            }
            ST_MENU -> menuScroll(dt)
            ST_EDIT -> if (editFrom == ST_MENU) menuScroll(dt)
        }
        if (diag) {
            memT -= dt
            if (memT <= 0f) { memT = 1f; val rt = Runtime.getRuntime(); memMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L }
        }
    }

    private fun menuScroll(dt: Float) {
        camX += 40f * dt
        ensureWorld(camX + lw + 300f)
        cullWorld(camX - 200f)
    }

    private fun camera(dt: Float) {
        val tx = px - lw * 0.30f + vx * 0.2f
        camX += (tx - camX) * min(1f, 7f * dt)
        camX = camX.coerceIn(px - lw * 0.62f, px - 70f)
        var ty = py - LH * 0.64f
        if (ps == P_SWING) ty = (py * 0.7f + ay * 0.3f) - LH * 0.62f
        camY += (ty - camY) * min(1f, 4f * dt)
        camY = camY.coerceIn(py - (LH - 52f), py - 45f)
    }

    private fun physics(dt: Float) {
        coyote -= dt; jumpBuf -= dt; zipCd -= dt; landT -= dt; wallCd -= dt; shootT -= dt; airT += dt
        val prevX = px
        if (swingPress) { swingPress = false; if (ps != P_SWING && startT <= 0f) trySwing() }
        if (zipPress) {
            zipPress = false
            if (startT <= 0f && zipCd <= 0f && (ps == P_AIR || ps == P_SWING || ps == P_WALL)) tryZip()
        }
        if (!swingHeld && ps == P_SWING) releaseSwing()
        val ts = targetSpeed()

        when (ps) {
            P_RUN -> {
                if (startT > 0f) { startT -= dt; vx = 0f }
                else {
                    vx += (ts - vx) * min(1f, 7f * dt)
                    if (jumpBuf > 0f) doJump()
                    else {
                        runPhase += vx * dt * 0.06f
                        moveX(vx * dt)
                        if (ps == P_RUN && !supported()) {
                            ps = P_AIR; coyote = 0.1f; airT = 0f; canFlip = false; jumped = false; cut = true
                        }
                    }
                }
            }
            P_AIR -> {
                if (vx < ts) vx += 160f * dt
                vy = min(vy + G * dt, 720f)
                if (!jumpHeld && jumped && !cut && vy < -150f) { vy *= 0.45f; cut = true }
                moveX(vx * dt)
                if (ps == P_AIR) { moveY(vy * dt); if (ps == P_AIR) unstick() }
                if (ps == P_AIR && jumpBuf > 0f && coyote > 0f) doJump()
            }
            P_WALL -> {
                if (jumpBuf > 0f) {
                    vy = -300f; vx = -70f; ps = P_AIR; wallCd = 0.3f; airT = 0f
                    jumped = false; cut = true; canFlip = false; jumpBuf = 0f
                    sfx(ToneGenerator.TONE_DTMF_3)
                } else {
                    if (wallT > 0f) { vy = -125f; wallT -= dt } else vy = min(vy + 500f * dt, 80f)
                    py += vy * dt
                    val wb = wallB
                    if (wb == null) { ps = P_AIR; airT = 0f }
                    else if (py <= wb.top) {
                        px = wb.x + HW + 1f; py = wb.top; vy = 0f; vx = ts * 0.7f
                        ps = P_RUN; landT = 0.12f
                    } else {
                        vx = 0f
                        moveX(40f * dt)
                        if (!wallHit && ps == P_WALL) { ps = P_AIR; airT = 0f; canFlip = false }
                    }
                }
            }
            P_SWING -> {
                if (blocked(px, py - 11f, ax, ay) || ax < camX - 40f) releaseSwing()
                else {
                    val oxp = px; val oyp = py - 11f
                    vy = min(vy + G * dt, 720f)
                    if (vx < 320f) vx += 70f * dt
                    moveX(vx * dt)
                    if (ps == P_SWING) {
                        moveY(vy * dt)
                        if (ps == P_SWING) {
                            val ddx = px - ax; val ddy = (py - 11f) - ay
                            val d = sqrt(ddx * ddx + ddy * ddy)
                            if (d > ropeL) {
                                val k = ropeL / d
                                px = ax + ddx * k; py = ay + ddy * k + 11f
                                vx = (px - oxp) / dt; vy = (py - 11f - oyp) / dt
                            }
                            val sp = sqrt(vx * vx + vy * vy)
                            if (sp > 430f) { vx *= 430f / sp; vy *= 430f / sp }
                            unstick()
                        }
                    }
                }
            }
            P_ZIP -> {
                zipT += dt
                val dxz = zTx - px; val dyz = zTy - py
                val d = sqrt(dxz * dxz + dyz * dyz)
                if (jumpBuf > 0f) {
                    ps = P_AIR; airT = 0f; canFlip = false; jumped = false; cut = true; jumpBuf = 0f
                } else if (d < 10f) {
                    px = zTx; py = zTy
                    vx = min(max(ts, abs(vx) * 0.6f), 360f); vy = 0f
                    ps = P_RUN; landT = 0.2f; zipCd = 0.35f
                    spawnDust()
                } else if (zipT > 1f) {
                    ps = P_AIR; airT = 0f; canFlip = false; jumped = false; cut = true
                } else {
                    val sp = min(720f, 280f + zipT * 3200f)
                    vx = dxz / d * sp; vy = dyz / d * sp
                    px += vx * dt; py += vy * dt
                }
            }
        }

        for (i in 0 until MAXP) if (plife[i] > 0f) {
            plife[i] -= dt; pxs[i] += pvx[i] * dt; pys[i] += pvy[i] * dt; pvy[i] += 300f * dt
        }
        if (px > prevX) dist += (px - prevX).toDouble()
        val m = meters()
        if (m / 500 > lastMile) { lastMile = m / 500; toast = "${lastMile * 500} M!"; toastT = 2f; if (m > best) best = m }
        indicators(dt)
        ensureWorld(px + lw + 700f)
        cullWorld(min(camX, px) - 200f)
        if (px > 150000f) rebase(100000f)
        if (py > DEATH_Y) die()
    }

    private fun doJump() {
        vy = -JUMP_V; ps = P_AIR; jumpBuf = 0f; coyote = 0f; airT = 0f
        jumped = true; cut = false; canFlip = true
        sfx(ToneGenerator.TONE_DTMF_5)
        spawnDust()
    }

    private fun landed() {
        val impact = vy
        vy = 0f
        if (ps != P_RUN) {
            ps = P_RUN
            landT = if (impact > 320f) 0.25f else 0.13f
            spawnDust()
            sfx(ToneGenerator.TONE_DTMF_0)
        }
        canFlip = false
    }

    private fun moveX(dx: Float) {
        var nx = px + dx
        wallHit = false
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW + abs(dx) + 4f) break
            if (b.x + b.w < px - HW - 4f) continue
            if (py > b.top + 2f) {
                if (dx > 0f && px + HW <= b.x + 0.5f && nx + HW > b.x) { nx = b.x - HW; wallHit = true; hitB = b }
                else if (dx < 0f && px - HW >= b.x + b.w - 0.5f && nx - HW < b.x + b.w) nx = b.x + b.w + HW
            }
        }
        px = nx
        if (wallHit && ps != P_WALL) {
            if (ps == P_SWING) { ps = P_AIR }
            vx = 0f
            if (wallCd <= 0f) { ps = P_WALL; wallB = hitB; wallT = 0.7f; vy = -125f; jumped = false; canFlip = false }
        }
    }

    private fun moveY(dy: Float) {
        val pf = py
        py += dy
        if (dy >= 0f) {
            for (i in 0 until world.size) {
                val b = world[i]
                if (b.x > px + HW) break
                if (b.x + b.w < px - HW) continue
                if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && pf <= b.top + 0.01f && py >= b.top) {
                    py = b.top; landed(); return
                }
            }
        }
    }

    private fun supported(): Boolean {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && abs(py - b.top) < 2f) return true
        }
        return false
    }

    private fun unstick() {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && py > b.top + 2f) {
                if (py - b.top < 8f) { py = b.top; landed() }
                else { px = b.x - HW; if (vx > 0f) vx = 0f }
            }
        }
    }

    private fun blocked(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        for (s in 1..7) {
            val t = s / 8f
            val sx = x1 + (x2 - x1) * t; val sy = y1 + (y2 - y1) * t
            for (i in 0 until world.size) {
                val b = world[i]
                if (b.x > sx) break
                if (sx <= b.x + b.w && sy > b.top) return true
            }
        }
        return false
    }

    private fun findAnchor(): Boolean {
        var bd = 1e9f; var found = false
        val cy = py - 11f
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + 600f) break
            if (!b.hasAnchor || b.ax < px + 8f) continue
            val dx = b.ax - px; val dy = b.ay - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d > 300f || d < 40f || b.ay > py - 35f) continue
            if (blocked(px, cy, b.ax, b.ay)) continue
            if (d < bd) { bd = d; cAx = b.ax; cAy = b.ay; found = true }
        }
        return found
    }

    private fun trySwing() {
        if (ps == P_ZIP) return
        if (findAnchor()) {
            ax = cAx; ay = cAy
            val dx = ax - px; val dy = ay - (py - 11f)
            ropeL = sqrt(dx * dx + dy * dy)
            ps = P_SWING; shootT = 0.15f; jumped = false; canFlip = false
            sfx(ToneGenerator.TONE_DTMF_8)
        }
    }

    private fun releaseSwing() {
        ps = P_AIR; airT = 0f; canFlip = true; jumped = false; cut = true
        sfx(ToneGenerator.TONE_DTMF_2)
    }

    private fun findZip(): Boolean {
        var bd = 1e9f; var found = false
        val cy = py - 11f
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x - px > ZIP_RANGE) break
            val tx = b.x + min(22f, b.w * 0.5f)
            if (tx < px + 30f) continue
            val dx = tx - px; val dy = (b.top - 6f) - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d > ZIP_RANGE || d < 30f || b.top < py - 150f) continue
            if (blocked(px, cy, tx, b.top - 8f)) continue
            if (d < bd) { bd = d; zTx = tx; zTy = b.top; found = true }
        }
        return found
    }

    private fun tryZip() {
        if (findZip()) {
            ps = P_ZIP; zipT = 0f; shootT = 0.15f; zipCd = 0.5f; canFlip = false
            sfx(ToneGenerator.TONE_DTMF_9, 60)
        }
    }

    private fun indicators(dt: Float) {
        indT -= dt
        if (indT > 0f) return
        indT = 0.08f
        indZip = false; indSwing = false
        if (ps == P_AIR || ps == P_SWING) {
            if (zipCd <= 0f && findZip()) { indZip = true; iZx = zTx; iZy = zTy }
        }
        if (ps == P_AIR || ps == P_RUN) {
            if (findAnchor()) { indSwing = true; iAx = cAx; iAy = cAy }
        }
    }

    private fun spawnDust() {
        val n = if (gfx == 0) 2 else if (gfx == 1) 4 else 8
        var made = 0
        for (i in 0 until MAXP) {
            if (made >= n) break
            if (plife[i] <= 0f) {
                plife[i] = 0.35f; pxs[i] = px + (made - n / 2f); pys[i] = py - 1f
                pvx[i] = -30f + (made % 3) * 25f - vx * 0.15f; pvy[i] = -30f - (made % 2) * 25f
                made++
            }
        }
    }

    private fun rc(c: Canvas, x: Int, y: Int, w: Int, h: Int, col: Int) {
        p.color = col
        c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), p)
    }

    private fun rf(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) {
        p.color = col
        c.drawRect(x, y, x + w, y + h, p)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, center: Boolean = false) {
        p.textSize = size
        p.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        p.color = INK; c.drawText(s, x + 1f, y + 1f, p)
        p.color = col; c.drawText(s, x, y, p)
    }

    private fun render() {
        val c = cv ?: return
        c.save()
        c.scale(WS, WS)
        val ox = floor(camX).toInt(); val oy = floor(camY).toInt()
        drawBackground(c, ox, oy)
        drawWorld(c, ox, oy)
        val showPlayer = st == ST_PLAY || st == ST_PAUSE || st == ST_OVER || (st == ST_EDIT && editFrom != ST_MENU)
        if (showPlayer) drawPlayer(c, ox, oy)
        drawParticles(c, ox, oy)
        if (showPlayer) drawWebs(c, ox, oy)

        when (st) {
            ST_PLAY -> { drawHud(c); drawButtons(c) }
            ST_MENU -> drawMenu(c)
            ST_PAUSE -> { dim(c); text(c, "PAUSED", lw / 2f, 40f, 20f, WHITE, true); for (m in pauseItems) drawItem(c, m) }
            ST_OVER -> drawOver(c)
            ST_EDIT -> {
                drawButtons(c)
                text(c, "DRAG BUTTONS TO MOVE  -  TAP ONE, THEN SIZE", lw / 2f, 60f, 9f, WHITE, true)
                text(c, "SELECTED: " + arrayOf("JUMP", "WEB", "ZIP", "PAUSE")[sel], lw / 2f, 76f, 9f, K(0xFFE27A), true)
                for (m in editItems) drawItem(c, m)
            }
        }
        if (diag) drawDiag(c)
        c.restore()
    }

    private fun dim(c: Canvas) {
        p.color = (0x99 shl 24) or 0x0B1626
        c.drawRect(0f, 0f, lw.toFloat(), LH.toFloat(), p)
    }

    private fun drawBackground(c: Canvas, ox: Int, oy: Int) {
        val bandH = LH / SKY.size + 1
        for (i in SKY.indices) rc(c, 0, i * LH / SKY.size, lw, bandH, SKY[i])

        p.color = K(0xFFF3B0)
        c.drawCircle(lw * 0.80f, 38f, 11f, p)

        val n = if (gfx == 0) 3 else if (gfx == 1) 5 else 7
        val span = (lw + 200).toFloat()
        for (i in 0 until n) {
            var sx = ((i * 151 + 40) - camX * 0.05f - (if (gfx == 0) 0f else time * (2f + i))) % span
            if (sx < 0f) sx += span
            sx -= 100f
            val cy = 14f + ((i * 29) % 70) - camY * 0.02f
            val w = (38 + (i * 13) % 30).toFloat()
            rf(c, sx + 6f, cy, w - 12f, 8f, WHITE)
            rf(c, sx, cy + 4f, w, 8f, WHITE)
            rf(c, sx + w * 0.3f, cy - 4f, w * 0.35f, 8f, WHITE)
            rf(c, sx, cy + 10f, w, 2f, K(0xD3E6F4))
        }
        skyline(c, 0.12f, K(0xA9CDE8), 150f, 40, 95, 16, 11)
        if (gfx >= 2) drawBirds(c)
        if (gfx >= 1) skyline(c, 0.25f, K(0x8DB6D8), 176f, 25, 70, 20, 77)
    }

    private fun skyline(c: Canvas, par: Float, col: Int, base0: Float, minH: Int, maxH: Int, colW: Int, seed: Int) {
        p.color = col
        val off = camX * par
        val first = floor(off / colW).toInt()
        val base = base0 - (camY - 20f) * par * 0.35f
        val n = lw / colW + 2
        for (k in 0..n) {
            val idx = first + k
            val hh = minH + hash(idx * 7 + seed) % (maxH - minH)
            val x = idx * colW - off
            c.drawRect(x, base - hh, x + colW - 1f, LH.toFloat(), p)
            if (hash(idx + seed + 99) % 5 == 0) c.drawRect(x + colW / 2f - 1f, base - hh - 10f, x + colW / 2f + 1f, base - hh, p)
        }
    }

    private fun drawBirds(c: Canvas) {
        for (i in 0 until 3) {
            val sx = ((time * 26f + i * 170f) % (lw + 60f)) - 30f
            val sy = 40f + i * 20f + sin(time * 2f + i) * 4f
            val up = ((time * 6f + i).toInt() and 1) == 0
            p.color = INK
            if (up) { c.drawRect(sx, sy, sx + 2f, sy + 1f, p); c.drawRect(sx + 3f, sy - 1f, sx + 5f, sy, p) }
            else { c.drawRect(sx, sy - 1f, sx + 2f, sy, p); c.drawRect(sx + 3f, sy, sx + 5f, sy + 1f, p) }
        }
    }

    private fun drawWorld(c: Canvas, ox: Int, oy: Int) {
        val sy = floor(STREET_Y).toInt() - oy
        if (sy < LH) { rc(c, 0, sy, lw, LH - sy + 2, K(0x6B6B72)); rc(c, 0, sy, lw, 2, K(0x8A8A92)) }
        visB = 0
        for (i in 0 until world.size) {
            val b = world[i]
            val sx = floor(b.x).toInt() - ox
            if (sx > lw + 20) break
            if (sx + b.w < -20f || b.top - oy > LH) continue
            visB++
            drawBuilding(c, b, ox, oy)
        }

        for (i in 0 until world.size) {
            val b = world[i]
            if (!b.hasAnchor) continue
            val sx = floor(b.ax).toInt() - ox
            if (sx < -10 || sx > lw + 10) continue
            val sy2 = floor(b.ay).toInt() - oy
            rc(c, sx, 0, 1, sy2, INK)
            rc(c, sx - 3, sy2 - 1, 7, 12, K(0x2F3640))
            rc(c, sx - 1, sy2 + 1, 3, 2, K(0xD9423A))
            rc(c, sx - 1, sy2 + 4, 3, 2, K(0xE8C23A))
            rc(c, sx - 1, sy2 + 7, 3, 2, K(0x4CAF50))
        }

        if (st == ST_PLAY) {
            if (indSwing) {
                val sx = floor(iAx).toInt() - ox; val sy2 = floor(iAy).toInt() - oy
                rc(c, sx - 6, sy2 - 4, 13, 1, WHITE); rc(c, sx - 6, sy2 + 14, 13, 1, WHITE)
            }
            if (indZip) {
                val sx = floor(iZx).toInt() - ox; val sy2 = floor(iZy).toInt() - oy
                rc(c, sx - 3, sy2 - 12, 7, 1, WHITE); rc(c, sx, sy2 - 12, 1, 4, WHITE)
            }
        }
    }

    private fun drawBuilding(c: Canvas, b: Building, ox: Int, oy: Int) {
        val x = floor(b.x).toInt() - ox
        val w = ceil(b.w).toInt()
        val y = floor(b.top).toInt() - oy
        val s = b.style
        val bot = LH + 2
        val top = max(y, -2)
        rc(c, x, top, w, bot - top, BASE[s])
        rc(c, x, top, 4, bot - top, DARK[s])
        rc(c, x + w - 2, top, 2, bot - top, LIGHT[s])

        rc(c, x, y, w, 2, CREAM); rc(c, x, y + 2, w, 3, LIGHT[s]); rc(c, x, y + 5, w, 1, DARK[s])
        if (gfx >= 2 && s == 0) {
            var yy = max(y + 9, 0)
            while (yy < LH) { rc(c, x + 4, yy, w - 6, 1, BRICKLINE); yy += 6 }
        }

        val rowH = if (s == 2) 16 else 18
        val ww = if (s == 2) 10 else 6
        val wh = if (s == 2) 11 else 9
        var row = 0
        var wy = y + 14
        while (wy < LH) {
            if (wy + wh > 0 && !(gfx == 0 && row >= 3)) {
                var wx = x + 9
                var col = 0
                while (wx + ww < x + w - 8) {
                    if (wx + ww > 0 && wx < lw) {
                        val hh = hash(b.seed + row * 31 + col * 7)
                        val color = if (s == 2) (if (hh % 7 == 0) WIN_GLASS_B else WIN_GLASS)
                        else if (hh % 6 == 0) WIN_LIT else WIN_DARK
                        rc(c, wx, wy, ww, wh, color)
                        if (s == 0 && gfx >= 1) rc(c, wx - 1, wy + wh, ww + 2, 1, SILL)
                        if (s == 2) rc(c, wx, wy, 2, 1, WHITE)
                    }
                    wx += 14; col++
                }
            }
            wy += rowH; row++
        }
        if (gfx >= 2 && s == 0 && w > 90) drawFireEscape(c, x + w - 26, y + 30)
        if (gfx >= 1) drawDeco(c, b, x, y, w)
    }

    private fun drawFireEscape(c: Canvas, x: Int, y0: Int) {
        var y = y0
        p.strokeWidth = 1f
        while (y < LH) {
            rc(c, x, y, 18, 1, INK)
            rc(c, x, y - 4, 1, 4, INK); rc(c, x + 17, y - 4, 1, 4, INK)
            p.color = INK
            c.drawLine(x + 2f, y.toFloat(), (x + 15).toFloat(), (y + 30).toFloat(), p)
            y += 36
        }
    }

    private fun drawDeco(c: Canvas, b: Building, x: Int, y: Int, w: Int) {
        val d = x + 10 + (b.seed % max(1, w - 50))
        when (b.deco) {
            1 -> { rc(c, d + 2, y - 8, 2, 8, STEEL); rc(c, d + 12, y - 8, 2, 8, STEEL)
                rc(c, d, y - 20, 16, 12, WOOD); rc(c, d, y - 20, 16, 2, WOOD_L); rc(c, d + 2, y - 24, 12, 4, WOOD_D) }
            2 -> { rc(c, d + 4, y - 30, 1, 30, STEEL); rc(c, d, y - 24, 9, 1, STEEL); rc(c, d + 1, y - 18, 7, 1, STEEL) }
            3 -> { rc(c, d, y - 7, 12, 7, GRAYL); rc(c, d + 2, y - 5, 8, 1, GRAYD)
                rc(c, d + 14, y - 5, 9, 5, GRAYL); rc(c, d + 16, y - 3, 5, 1, GRAYD) }
            4 -> { rc(c, d, y - 14, 7, 14, DARK[0]); rc(c, d - 1, y - 16, 9, 3, K(0x3A3A40)) }
            5 -> if (gfx >= 2) { rc(c, d, y - 4, 26, 4, WOOD_D); rc(c, d + 1, y - 9, 8, 5, GREEN)
                rc(c, d + 10, y - 12, 9, 8, GREEN_D); rc(c, d + 19, y - 8, 6, 4, GREEN) }
            6 -> if (gfx >= 2) { rc(c, d + 4, y - 14, 2, 14, STEEL); rc(c, d + 30, y - 14, 2, 14, STEEL)
                rc(c, d, y - 32, 38, 18, CREAM); rc(c, d, y - 32, 38, 3, RED); rc(c, d + 4, y - 24, 20, 2, BLUE)
                rc(c, d + 4, y - 20, 14, 2, GRAYD) }
            7 -> { rc(c, d, y - 6, 30, 1, STEEL); rc(c, d, y - 6, 1, 6, STEEL); rc(c, d + 29, y - 6, 1, 6, STEEL)
                rc(c, d + 14, y - 6, 1, 6, STEEL) }
        }
    }

    private fun drawParticles(c: Canvas, ox: Int, oy: Int) {
        var n = 0
        p.color = CREAM
        for (i in 0 until MAXP) if (plife[i] > 0f) {
            n++
            val sx = pxs[i] - ox; val sy = pys[i] - oy
            c.drawRect(sx, sy, sx + 2f, sy + 2f, p)
        }
        activeP = n

        val fast = st == ST_PLAY && (ps == P_ZIP || vx > 200f)
        val cnt = if (gfx == 0) 0 else if (gfx == 1) 4 else 8
        if (fast && cnt > 0) {
            val sx0 = floor(px).toInt() - ox; val sy0 = floor(py).toInt() - oy
            val seed = (time * 30f).toInt()
            for (i in 0 until cnt) {
                val h = hash(seed * 13 + i)
                val yy = sy0 - 26 + h % 30
                val len = 14 + h % 18
                rc(c, sx0 - 14 - len - (h % 12), yy, len, 1, WHITE)
            }
        }
    }

    private fun drawWebs(c: Canvas, ox: Int, oy: Int) {
        val hx = handSx; val hy = handSy
        p.strokeWidth = 1f
        p.color = WHITE
        if (ps == P_SWING) c.drawLine(hx, hy, ax - ox, ay - oy, p)
        else if (ps == P_ZIP) c.drawLine(hx, hy, zTx - ox, zTy - 6f - oy, p)
    }

    private fun limb(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int) {
        p.color = col; p.strokeWidth = 3f
        c.drawLine(x1, y1, x2, y2, p)
    }

    private fun drawFrame(c: Canvas, f: Int) {
        val sh = heroSheet ?: return
        val row = suit.coerceIn(0, 2)
        fSrc.set(f * FW, row * FW, f * FW + FW, row * FW + FW)
        fDst.set(-PVX, -PVY, FW - PVX, FW - PVY)
        c.drawBitmap(sh, fSrc, fDst, spriteP)
    }

    private fun runFrame(phase: Float): Int = ((phase * 1.4324f).toInt() % 9) + 1

    private fun drawPlayer(c: Canvas, ox: Int, oy: Int) {
        val sx = floor(px).toInt() - ox
        val sy = floor(py).toInt() - oy
        var frame = 0
        var rot = 0f
        var offX = 0f; var offY = 0f
        var hx = 22f; var hy = -11f
        var squash = false
        when (ps) {
            P_RUN -> {
                if (startT > 0f || vx < 8f) frame = 0
                else {
                    frame = runFrame(runPhase)
                    squash = landT > 0f
                    if (landT > 0f) frame = 4
                }
            }
            P_AIR -> {
                if (vy < -20f) { frame = 6; rot = -6f }
                else if (vy > 260f) { frame = 4; rot = 14f }
                else { frame = 5; rot = 6f }
                if (canFlip) {
                    val f = ((airT - 0.1f) / 0.5f).coerceIn(0f, 1f)
                    if (f < 1f) { rot += f * 360f; frame = 4 }
                }
                if (shootT > 0f) frame = 5
            }
            P_SWING -> {
                rot = Math.toDegrees(atan2((ax - px).toDouble(), -(ay - (py - 11f)).toDouble())).toFloat()
                val sp = sqrt(vx * vx + vy * vy)
                frame = if (shootT > 0f) 5 else if (sp > 250f || px > ax) 6 else 0
                if (frame == 0) { hx = 7f; hy = -27f }
            }
            P_ZIP -> {
                val ang = Math.toDegrees(atan2(vx.toDouble(), -vy.toDouble())).toFloat()
                rot = (ang - 90f).coerceIn(-75f, 75f)
                frame = if (zipT < 0.08f) 5 else 6
                hx = 24f; hy = -11f
            }
            P_WALL -> {
                // feet planted on the wall, body lying away from it, moving up
                rot = -90f
                offX = -18f; offY = 4f
                frame = if (wallT > 0f) runFrame(time * 7f) else 2
                hx = 22f; hy = -11f
            }
        }
        val cr = cos(Math.toRadians(rot.toDouble())).toFloat()
        val sr = sin(Math.toRadians(rot.toDouble())).toFloat()
        handSx = sx + (offX + hx * cr - hy * sr) / WS
        handSy = sy + (-PVY + offY + hx * sr + hy * cr) / WS
        c.save()
        c.scale(1f / WS, 1f / WS)
        c.translate((sx * WS).roundToInt().toFloat(), (sy * WS).roundToInt().toFloat())
        if (squash) c.scale(1.12f, 0.85f, 0f, 0f)
        c.translate(offX, -PVY.toFloat() + offY)
        c.rotate(rot, 0f, 0f)
        drawFrame(c, frame)
        c.restore()
    }

    private fun drawHud(c: Canvas) {
        text(c, "${meters()} M", 8f, 16f, 14f, WHITE)
        text(c, "BEST $best", 8f, 27f, 8f, CREAM)
        if (toastT > 0f) text(c, toast, lw / 2f, 60f, 16f, K(0xFFE27A), true)
        if (startT > 0f) text(c, "GET READY", lw / 2f, 80f, 12f, WHITE, true)
    }

    private val labels = arrayOf("JUMP", "WEB", "ZIP", "II")

    private fun drawButtons(c: Canvas) {
        val a = (opac * 255).toInt()
        for (k in 0 until 4) {
            val cx = bx[k] * lw; val cy = by[k] * LH; val r = bs[k] / 2f
            p.style = Paint.Style.FILL
            p.color = ((if (btnDown[k]) min(255, a + 70) else a) shl 24) or 0x1E2A3A
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f
            p.color = if (st == ST_EDIT && sel == k) K(0xFFE27A) else ((min(255, a + 60)) shl 24) or 0xFFFFFF
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.FILL
            p.textSize = max(7f, r * 0.42f); p.textAlign = Paint.Align.CENTER
            p.color = ((min(255, a + 90)) shl 24) or 0xFFFFFF
            c.drawText(labels[k], cx, cy + p.textSize * 0.35f, p)
        }
    }

    private fun drawItem(c: Canvas, m: Item) {
        val x = m.x.toInt(); val y = m.y.toInt(); val w = m.w.toInt(); val h = m.h.toInt()
        rc(c, x - 1, y - 1, w + 2, h + 2, INK)
        rc(c, x, y, w, h, if (m.id == ID_PLAY) RED else BLUE)
        rc(c, x, y, w, 2, if (m.id == ID_PLAY) K(0xE86A5A) else LIGHTB)
        text(c, label(m.id), m.x + m.w / 2f, m.y + m.h / 2f + 4f, 10f, WHITE, true)
    }

    private fun drawMenu(c: Canvas) {
        text(c, "ROOFTOP HERO", 24f, 44f, 28f, K(0xD62828))
        text(c, "RUN. SWING. ZIP.", 26f, 60f, 10f, WHITE)
        for (m in menuItems) drawItem(c, m)
        text(c, "BEST $best M   RUNS $runs   TOTAL $totalM M", 24f, 210f, 8f, WHITE)
        text(c, "HOLD WEB NEAR A SIGNAL  -  ZIP IN THE AIR", 156f, 205f, 7f, CREAM)
        if (suit == 0 && best < SUIT_REQ[1]) text(c, "UNLOCK SUITS: 500 M / 1500 M", 156f, 214f, 7f, CREAM)
    }

    private fun drawOver(c: Canvas) {
        dim(c)
        text(c, "WIPEOUT!", lw / 2f, 50f, 24f, K(0xFF6A5A), true)
        text(c, "${meters()} M", lw / 2f, 84f, 20f, WHITE, true)
        text(c, "BEST $best M", lw / 2f, 102f, 10f, CREAM, true)
        text(c, "RUNS $runs  TOTAL $totalM M", lw / 2f, 120f, 8f, CREAM, true)
        for (m in overItems) drawItem(c, m)
    }

    private fun drawDiag(c: Canvas) {
        val y0 = if (st == ST_PLAY) 40f else 12f
        text(c, "FPS ${fpsAvg.roundToInt()}  FRAME ${"%.1f".format(frameMs)} MS", 8f, y0, 7f, K(0xB6FFB6))
        text(c, "BUILDINGS ${visB}/${world.size}  PARTICLES $activeP", 8f, y0 + 9f, 7f, K(0xB6FFB6))
        text(c, "MEM $memMb MB  SEED $runSeed", 8f, y0 + 18f, 7f, K(0xB6FFB6))
    }
}
