package com.example.spiderrunner

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Explicit animation state machine for the hero.
 *
 * The physics controller in GameView stays the single authority over position and
 * velocity. This layer only OBSERVES it each fixed step (via [AnimInput]) and decides
 * which named animation state is active, how long the blend into it takes, and which
 * gameplay events (voice, camera) fire on entry. It never writes velocity, so a swing
 * release or a landing can never reset momentum.
 *
 * Priority (lower ordinal = more important), per the spec:
 *   CRITICAL    forced recovery (heavy landing)
 *   TRAVERSAL   wall, zip, corner, edge climb
 *   MOVEMENT    jump, swing, air locomotion, landings
 *   TRICK       aerial tricks / style
 *   LOCOMOTION  idle, run, sprint, slide
 *
 * Interruption rule: a request interrupts the current state when it is STRICTLY more
 * important, or when the current state's [AnimState.lockT] has elapsed. Because the
 * target is re-resolved every step, a request that is blocked by a lock is simply
 * applied as soon as the lock ends; input is never dropped.
 */
enum class Prio { CRITICAL, TRAVERSAL, MOVEMENT, TRICK, LOCOMOTION }

enum class AnimState(val prio: Prio, val lockT: Float = 0f) {
    // ground locomotion
    IDLE(Prio.LOCOMOTION),
    RUN(Prio.LOCOMOTION, 0.08f),
    SPRINT(Prio.LOCOMOTION, 0.10f),
    SLIDE(Prio.LOCOMOTION, 0.10f),
    // landing and recovery
    LAND_LIGHT(Prio.MOVEMENT),
    LAND_MEDIUM(Prio.MOVEMENT, 0.06f),
    LAND_HEAVY(Prio.CRITICAL, 0.14f),
    LAND_ROLL(Prio.MOVEMENT, 0.10f),
    LAND_RECOVER(Prio.LOCOMOTION),
    // jump and air
    JUMP_TAKEOFF(Prio.MOVEMENT, 0.06f),
    AIR_RISE(Prio.MOVEMENT),
    AIR_FALL(Prio.MOVEMENT, 0.05f),
    AIR_FAST_FALL(Prio.MOVEMENT, 0.05f),
    // aerial tricks
    AIR_FRONTFLIP(Prio.TRICK),
    AIR_BACKFLIP(Prio.TRICK),
    AIR_TWIST(Prio.TRICK),
    AIR_STYLE(Prio.TRICK),
    AIR_DOUBLEFLIP(Prio.TRICK),
    // web swing
    SWING_START(Prio.MOVEMENT, 0.08f),
    SWING_RISING(Prio.MOVEMENT, 0.08f),
    SWING_APEX(Prio.MOVEMENT, 0.08f),
    SWING_DESCENDING(Prio.MOVEMENT, 0.08f),
    SWING_FAST(Prio.MOVEMENT, 0.08f),
    SWING_TURNING(Prio.MOVEMENT, 0.08f),
    SWING_RELEASE(Prio.MOVEMENT, 0.08f),
    // traversal
    ZIP(Prio.TRAVERSAL),
    ZIP_BOOST(Prio.TRAVERSAL, 0.08f),
    CORNER_PERCH(Prio.TRAVERSAL),
    WALL_ENTER(Prio.TRAVERSAL, 0.08f),
    WALL_CLIMB(Prio.TRAVERSAL, 0.06f),
    WALL_RUN(Prio.TRAVERSAL, 0.06f),
    WALL_KICK(Prio.TRAVERSAL, 0.10f),
    ZIP_APPROACH(Prio.TRAVERSAL, 0.06f),     // decelerating into the target
    BOOST_PREPARE(Prio.TRAVERSAL, 0.05f),    // knees in, gathering zip momentum
    VAULT_EXECUTE(Prio.TRAVERSAL, 0.10f),    // pop over a low rooftop edge, momentum kept
    WALL_EXIT(Prio.TRAVERSAL, 0.06f),        // peeling off a wall without a kick
    EDGE_CLIMB(Prio.TRAVERSAL, 0.18f);

    val isLanding: Boolean get() = this == LAND_LIGHT || this == LAND_MEDIUM || this == LAND_HEAVY || this == LAND_ROLL
    val isTrick: Boolean get() = this.ordinal in AIR_FRONTFLIP.ordinal..AIR_DOUBLEFLIP.ordinal
    val isSwing: Boolean get() = this.ordinal in SWING_START.ordinal..SWING_RELEASE.ordinal
    val isAir: Boolean get() = this == JUMP_TAKEOFF || this == AIR_RISE || this == AIR_FALL || this == AIR_FAST_FALL
}

enum class Curve {
    LINEAR, SMOOTH, EASE_OUT, EASE_IN;

    fun eval(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return when (this) {
            LINEAR -> x
            SMOOTH -> x * x * (3f - 2f * x)
            EASE_OUT -> 1f - (1f - x) * (1f - x)
            EASE_IN -> x * x
        }
    }
}

/**
 * One row of the transition table. null from/to means "any". The most specific
 * matching row wins (exact pair > from-only > to-only > wildcard).
 *
 * rootMotion is always false: the physics controller moves the character, never the clip.
 * keepVelocity is true everywhere: no transition may modify vx/vy.
 */
class TransitionRule(
    val from: AnimState?,
    val to: AnimState?,
    val duration: Float,
    val curve: Curve,
    val note: String = "",
    val rootMotion: Boolean = false,
    val keepVelocity: Boolean = true
) {
    fun matches(a: AnimState, b: AnimState): Boolean = (from == null || from == a) && (to == null || to == b)
    fun specificity(): Int = (if (from != null) 2 else 0) + (if (to != null) 1 else 0)
}

/** Snapshot of the physics controller, filled by GameView each fixed step. */
class AnimInput {
    var mode = GameView.P_RUN
    var vx = 0f
    var vy = 0f
    var grounded = true
    var jumped = false     // a jump impulse was applied this airborne phase
    var airT = 0f
    var startT = 0f
    var landT = 0f
    var shootT = 0f
    var boostPreT = 0f
    var boostFlyT = 0f
    var kickT = 0f
    var zipHeld = false
    var ropeFrac = 0f      // distance to anchor / rope length (1 = taut)
    var zipDist = 999f     // distance to the zip target while zipping
}

class AnimStateMachine {
    companion object {
        const val SPRINT_ENTER = 225f
        const val SPRINT_EXIT = 205f
        const val FAST_FALL_VY = 460f
        const val TAKEOFF_WINDOW = 0.12f
        const val WALL_ENTER_WINDOW = 0.10f
        const val RELEASE_WINDOW = 0.14f
        const val EDGE_CLIMB_WINDOW = 0.20f
        const val RECOVER_WINDOW = 0.10f
        const val TRICK_COUNT = 6   // matches GameView jumpStyle 0..5
    }

    var current = AnimState.IDLE; private set
    var previous = AnimState.IDLE; private set
    var pending: AnimState? = null; private set       // requested but held back by a lock
    var dwell = 0f; private set                       // seconds in the current state
    var blend = 1f; private set                       // eased 0..1 progress of the active blend
    var transitions = 0; private set
    val trickActive: Boolean get() = trickT > 0f
    var activeRule: TransitionRule? = null; private set

    /** Fired once on every state change (from, to). Must not block; never wait on audio. */
    var listener: ((AnimState, AnimState) -> Unit)? = null
    /** Fired when a trick plays to its end in the air (not when a landing cuts it short). */
    var onTrickComplete: ((AnimState) -> Unit)? = null

    // ---- configuration ----
    var durationScale = 1f
    /** Per jumpStyle 0..5. A disallowed trick is skipped and the jump stays a plain jump. */
    val trickPermitted = BooleanArray(TRICK_COUNT) { true }

    val rules = ArrayList<TransitionRule>()

    private val inp = AnimInput()
    private var blendRaw = 1f
    private var blendDur = 0.1f
    private var lastMode = -1
    private var psT = 0f
    private var landState: AnimState? = null
    private var recoverT = 0f
    private var edgeT = 0f
    private var releaseT = 0f
    private var trickT = 0f
    private var wallExitT = 0f
    private var vaultT = 0f
    private var trickState = AnimState.AIR_STYLE
    private val histFrom = arrayOfNulls<AnimState>(4)
    private val histTo = arrayOfNulls<AnimState>(4)
    private var histN = 0

    init { buildRules() }

    // ------------------------------------------------------------------
    // Transition table. Durations: short for fast gameplay actions, longer
    // for expressive idle/recovery movement.
    // ------------------------------------------------------------------
    private fun buildRules() {
        fun r(f: AnimState?, t: AnimState?, d: Float, c: Curve, n: String = "") { rules.add(TransitionRule(f, t, d, c, n)) }
        val lands = AnimState.values().filter { it.isLanding }
        val tricks = AnimState.values().filter { it.isTrick }
        val swings = AnimState.values().filter { it.isSwing && it != AnimState.SWING_START && it != AnimState.SWING_RELEASE }
        val walls = listOf(AnimState.WALL_ENTER, AnimState.WALL_CLIMB, AnimState.WALL_RUN, AnimState.WALL_KICK)

        r(null, null, 0.10f, Curve.SMOOTH, "default")
        // ground
        r(AnimState.IDLE, AnimState.RUN, 0.15f, Curve.SMOOTH, "move input")
        r(AnimState.RUN, AnimState.SPRINT, 0.20f, Curve.SMOOTH, "speed >= ${SPRINT_ENTER.toInt()}")
        r(AnimState.SPRINT, AnimState.RUN, 0.20f, Curve.SMOOTH, "speed < ${SPRINT_EXIT.toInt()}")
        r(null, AnimState.IDLE, 0.20f, Curve.SMOOTH, "expressive")
        r(null, AnimState.SLIDE, 0.06f, Curve.EASE_OUT, "slide")
        // jump / air
        r(null, AnimState.JUMP_TAKEOFF, 0.05f, Curve.EASE_OUT, "impulse applied by physics")
        r(AnimState.JUMP_TAKEOFF, null, 0.12f, Curve.SMOOTH, "takeoff -> air")
        r(null, AnimState.AIR_FAST_FALL, 0.10f, Curve.EASE_IN, "vy > ${FAST_FALL_VY.toInt()}")
        // landings: fast in, longer out so landings never feel snapped
        for (s in lands) r(null, s, if (s == AnimState.LAND_HEAVY) 0.03f else 0.05f, Curve.EASE_OUT, "ground contact")
        for (s in lands) r(s, null, 0.12f, Curve.SMOOTH, "recovery out (straight into run if moving)")
        r(null, AnimState.LAND_RECOVER, 0.10f, Curve.SMOOTH)
        // tricks
        for (s in tricks) r(null, s, 0.06f, Curve.EASE_OUT, "trick start")
        for (s in tricks) r(s, null, 0.18f, Curve.SMOOTH, "extend limbs, back to air")
        // swing
        r(null, AnimState.SWING_START, 0.06f, Curve.EASE_OUT, "web shot")
        r(AnimState.SWING_START, null, 0.10f, Curve.SMOOTH, "web connected")
        for (s in swings) r(null, s, 0.12f, Curve.SMOOTH, "swing substate")
        r(null, AnimState.SWING_RELEASE, 0.04f, Curve.EASE_OUT, "release keeps velocity")
        r(AnimState.SWING_RELEASE, null, 0.16f, Curve.SMOOTH, "release -> air/trick")
        // traversal
        r(null, AnimState.ZIP, 0.05f, Curve.EASE_OUT)
        r(null, AnimState.ZIP_BOOST, 0.04f, Curve.EASE_OUT)
        r(null, AnimState.CORNER_PERCH, 0.06f, Curve.EASE_OUT)
        for (s in walls) r(null, s, 0.04f, Curve.EASE_OUT, "wall contact")
        for (s in walls) r(s, null, 0.08f, Curve.SMOOTH, "wall exit")
        r(null, AnimState.EDGE_CLIMB, 0.08f, Curve.SMOOTH, "top-out")
        r(null, AnimState.ZIP_APPROACH, 0.08f, Curve.EASE_OUT, "within 45 px of target")
        r(null, AnimState.BOOST_PREPARE, 0.04f, Curve.EASE_OUT, "jump during zip approach")
        r(null, AnimState.VAULT_EXECUTE, 0.05f, Curve.EASE_OUT, "low edge, speed kept")
        r(null, AnimState.WALL_EXIT, 0.08f, Curve.SMOOTH, "wall contact lost")
    }

    fun findRule(a: AnimState, b: AnimState): TransitionRule {
        var best: TransitionRule? = null
        for (r in rules) if (r.matches(a, b) && (best == null || r.specificity() > best.specificity())) best = r
        return best!!
    }

    // ------------------------------------------------------------------
    // Event notes from gameplay code
    // ------------------------------------------------------------------
    fun noteLanding(kind: Int, impact: Float, vx: Float) {
        landState = when (kind) {
            GameView.LK_ROLL -> AnimState.LAND_ROLL
            GameView.LK_HERO -> AnimState.LAND_HEAVY
            GameView.LK_RUSH -> AnimState.LAND_MEDIUM
            else -> if (impact > 320f) AnimState.LAND_MEDIUM else AnimState.LAND_LIGHT
        }
    }
    fun noteTrick(style: Int, duration: Float) {
        if (style < 0 || style >= TRICK_COUNT || !trickPermitted[style]) return
        trickState = trickFor(style); trickT = duration
    }
    fun noteRelease() { releaseT = RELEASE_WINDOW }
    fun noteEdgeClimb() { edgeT = EDGE_CLIMB_WINDOW }
    fun noteVault() { vaultT = 0.30f }

    fun trickFor(style: Int): AnimState = when (style) {
        0 -> AnimState.AIR_FRONTFLIP
        1 -> AnimState.AIR_BACKFLIP
        2 -> AnimState.AIR_TWIST
        4 -> AnimState.AIR_DOUBLEFLIP
        else -> AnimState.AIR_STYLE
    }

    fun reset() {
        current = AnimState.IDLE; previous = AnimState.IDLE; pending = null
        dwell = 0f; blend = 1f; blendRaw = 1f; transitions = 0; activeRule = null
        landState = null; recoverT = 0f; edgeT = 0f; releaseT = 0f; trickT = 0f; wallExitT = 0f; vaultT = 0f
        lastMode = -1; psT = 0f; histN = 0
    }

    /** Fill and return the shared input snapshot (no per-step allocation). */
    fun input(): AnimInput = inp

    // ------------------------------------------------------------------
    // Per-step update
    // ------------------------------------------------------------------
    fun update(dt: Float) {
        dwell += dt
        val prevMode = lastMode
        if (inp.mode != lastMode) { psT = 0f; lastMode = inp.mode } else psT += dt
        if (prevMode == GameView.P_WALL && inp.mode == GameView.P_AIR && inp.kickT <= 0f) wallExitT = 0.14f
        if (wallExitT > 0f) wallExitT -= dt
        if (vaultT > 0f) vaultT -= dt
        if (releaseT > 0f) releaseT -= dt
        if (edgeT > 0f) edgeT -= dt
        if (trickT > 0f) {
            trickT -= dt
            if (trickT <= 0f && inp.mode == GameView.P_AIR) onTrickComplete?.invoke(trickState)
        }
        if (inp.mode != GameView.P_AIR) { wallExitT = 0f; vaultT = 0f }
        if (recoverT > 0f) recoverT -= dt
        if (inp.mode != GameView.P_AIR) trickT = 0f
        if (inp.mode != GameView.P_AIR) releaseT = 0f
        if (inp.mode != GameView.P_RUN) edgeT = 0f

        if (inp.landT <= 0f && landState != null) {
            if (landState == AnimState.LAND_MEDIUM || landState == AnimState.LAND_HEAVY) recoverT = RECOVER_WINDOW
            landState = null
        }

        val target = resolve()
        if (target != current) {
            if (canInterrupt(target)) { begin(target); pending = null } else pending = target
        } else pending = null

        if (blendRaw < 1f) {
            blendRaw = min(1f, blendRaw + dt / blendDur)
            blend = activeRule?.curve?.eval(blendRaw) ?: 1f
        }
    }

    private fun canInterrupt(target: AnimState): Boolean =
        target.prio.ordinal < current.prio.ordinal || dwell >= current.lockT

    private fun begin(target: AnimState) {
        val rule = findRule(current, target)
        previous = current; current = target
        dwell = 0f; blendRaw = 0f; blend = 0f
        blendDur = max(0.001f, rule.duration * durationScale)
        activeRule = rule
        transitions++
        val i = histN % histFrom.size
        histFrom[i] = previous; histTo[i] = current; histN++
        listener?.invoke(previous, current)
    }

    /** Pure mapping from physics snapshot (plus event notes) to the wanted state. */
    private fun resolve(): AnimState {
        val sp = sqrt(inp.vx * inp.vx + inp.vy * inp.vy)
        return when (inp.mode) {
            GameView.P_RUN -> when {
                edgeT > 0f -> AnimState.EDGE_CLIMB
                inp.landT > 0f && landState != null -> landState!!
                recoverT > 0f -> AnimState.LAND_RECOVER
                inp.startT > 0f || inp.vx < 8f -> AnimState.IDLE
                inp.vx >= (if (current == AnimState.SPRINT) SPRINT_EXIT else SPRINT_ENTER) -> AnimState.SPRINT
                else -> AnimState.RUN
            }
            GameView.P_SLIDE -> AnimState.SLIDE
            GameView.P_AIR -> when {
                inp.kickT > 0f -> AnimState.WALL_KICK
                inp.boostFlyT > 0f -> AnimState.ZIP_BOOST
                vaultT > 0f -> AnimState.VAULT_EXECUTE
                wallExitT > 0f -> AnimState.WALL_EXIT
                releaseT > 0f -> AnimState.SWING_RELEASE
                trickT > 0f -> trickState
                inp.jumped && inp.airT < TAKEOFF_WINDOW && inp.vy < 0f -> AnimState.JUMP_TAKEOFF
                inp.vy > FAST_FALL_VY -> AnimState.AIR_FAST_FALL
                inp.vy > 40f -> AnimState.AIR_FALL
                else -> AnimState.AIR_RISE
            }
            GameView.P_SWING -> when {
                inp.shootT > 0f -> AnimState.SWING_START
                inp.vx < 30f -> AnimState.SWING_TURNING
                sp > 350f -> AnimState.SWING_FAST
                abs(inp.vy) < 45f -> AnimState.SWING_APEX
                inp.vy < 0f -> AnimState.SWING_RISING
                else -> AnimState.SWING_DESCENDING
            }
            GameView.P_ZIP -> when {
                inp.boostPreT > 0f -> AnimState.BOOST_PREPARE
                inp.zipDist < 45f -> AnimState.ZIP_APPROACH
                else -> AnimState.ZIP
            }
            GameView.P_WALL -> when {
                psT < WALL_ENTER_WINDOW -> AnimState.WALL_ENTER
                inp.zipHeld -> AnimState.WALL_RUN
                else -> AnimState.WALL_CLIMB
            }
            GameView.P_CORNER -> AnimState.CORNER_PERCH
            else -> AnimState.IDLE
        }
    }

    // ------------------------------------------------------------------
    // Debug display
    // ------------------------------------------------------------------
    fun debugLines(): Array<String> {
        val pct = (blend * 100f).toInt()
        val pend = pending?.let { " HOLD>${it.name}" } ?: ""
        val i1 = (histN - 1 + histFrom.size * 4) % histFrom.size
        val last = if (histN > 0) "${histFrom[i1]?.name}>${histTo[i1]?.name}" else "-"
        return arrayOf(
            "ANIM ${current.name} [${current.prio.name}]$pend",
            "BLEND ${previous.name}>${current.name} $pct% ${"%.2f".format(blendDur)}S",
            "DWELL ${"%.2f".format(dwell)}S  TRANS $transitions  LAST $last",
            "VEL ${inp.vx.toInt()},${inp.vy.toInt()}  ${if (inp.grounded) "GROUNDED" else "AIRBORNE"}"
        )
    }
}
