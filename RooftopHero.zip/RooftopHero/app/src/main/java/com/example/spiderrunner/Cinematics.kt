package com.example.spiderrunner

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Damped spring. Used for squash/stretch, body wobble and camera kicks so every
 * reaction anticipates, overshoots and settles instead of snapping between poses.
 *   x = current offset from rest, v = velocity.
 */
class Spring(private val k: Float, private val d: Float) {
    var x = 0f
    var v = 0f

    fun step(dt: Float) {
        v += (-k * x - d * v) * dt
        x += v * dt
    }

    /** Instantly displace (dx) and/or push (dv). */
    fun kick(dx: Float = 0f, dv: Float = 0f) { x += dx; v += dv }

    fun reset() { x = 0f; v = 0f }
}

/**
 * Cinematic layer on top of the normal follow camera. It never moves the follow
 * target, so the player always keeps control and the hero stays on screen:
 *  - zoom   : brief punch-in (>= 1 only, so the view never shows past the world edge)
 *  - offX/Y : springy offsets for thumps, sways and whip-pans
 *  - bars   : thin letterbox that eases in while a major trick plays
 */
class CineCam {
    var zoom = 1f
    var bars = 0f
    val offX = Spring(110f, 14f)
    val offY = Spring(110f, 14f)

    private var zTarget = 1f
    private var zHold = 0f
    private var barsHold = 0f

    /** Zoom toward [target] and hold for [hold] seconds, then ease back out. */
    fun zoomPulse(target: Float, hold: Float) {
        if (target > zTarget) zTarget = target
        if (hold > zHold) zHold = hold
    }

    /** Letterbox framing for [hold] seconds. */
    fun emphasize(hold: Float) { if (hold > barsHold) barsHold = hold }

    /** Smooth sway: velocity push, the offset peaks near [dx]/[dy] world px. */
    fun sway(dx: Float, dy: Float) { offX.kick(0f, dx * 11f); offY.kick(0f, dy * 11f) }

    /** Hard thump: offset jumps immediately and springs back (impacts). */
    fun thump(dx: Float, dy: Float) { offX.kick(dx, 0f); offY.kick(dy, 0f) }

    fun update(dt: Float) {
        val d = min(dt, 0.033f)
        if (zHold > 0f) zHold -= d else zTarget = 1f
        zoom += (zTarget - zoom) * min(1f, 7f * d)
        if (zoom < 1.0005f) zoom = 1f
        if (barsHold > 0f) barsHold -= d
        val bt = if (barsHold > 0f) 1f else 0f
        bars += (bt - bars) * min(1f, 8f * d)
        if (bars < 0.01f) bars = 0f
        offX.step(d); offY.step(d)
    }

    fun reset() {
        zoom = 1f; zTarget = 1f; zHold = 0f; bars = 0f; barsHold = 0f
        offX.reset(); offY.reset()
    }
}

/** Gameplay events that can trigger a voice callout. */
object Cue {
    const val JUMP = 0        // "All right, here we go!"
    const val SWING = 1       // "Coming through!"
    const val CLOSE = 2       // fast aerial / near miss: "That was close!"
    const val LAND = 3        // "Nailed it."
    const val LONG_FALL = 4   // "Okay, need a plan!"
    const val WHOA = 5        // sudden direction change: "Whoa!"
    const val ARRIVE = 6      // rooftop arrival: "Made it."
    const val RELEASE = 7     // swing release: "Let's keep moving."
    const val NICE = 8        // aerial twist / double flip: "Nice!"
    const val ROUGH = 9       // heavy landing: "That was a rough landing."
    const val BOOST = 10      // zip boost: "Whoa! Let's go!"
    const val COUNT = 11
}

class VoiceLine(val text: String, val pitch: Float, val rate: Float)

/**
 * Event-driven voice director (no random timers).
 *
 * Rules, in order:
 *  1. Per-cue cooldown, so the same moment never talks twice in a row.
 *  2. Per-cue chance, so frequent actions (jumps) stay mostly silent.
 *  3. One voice at a time. A new line can only interrupt the current one if its
 *     priority is higher (a long fall beats a jump grunt).
 *  4. Never the same line twice in a row within a cue; pitch/rate get a little
 *     random jitter so repeats still sound like fresh takes.
 *
 * Delivery uses the device TextToSpeech engine (no bundled voice assets). Each line
 * carries its own pitch / rate to sell the emotion: excited jumps are quick and high,
 * confident landings are slower and lower, panic lines are fast and squeaky.
 * [say] returns the chosen line even if no TTS engine exists, so the game can still
 * show the caption.
 */
class VoiceDirector(ctx: Context) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val rng = java.util.Random()

    private val lastCue = FloatArray(Cue.COUNT) { -100f }
    private val lastIdx = IntArray(Cue.COUNT) { -1 }
    private var busyUntil = -1f
    private var busyPrio = 0

    private fun l(t: String, p: Float, r: Float) = VoiceLine(t, p, r)

    private val pools: Array<Array<VoiceLine>> = arrayOf(
        arrayOf(l("All right, here we go!", 1.12f, 1.05f), l("Let's do this!", 1.10f, 1.08f),
            l("Up we go!", 1.18f, 1.10f), l("Hup!", 1.25f, 1.20f)),
        arrayOf(l("Coming through!", 1.10f, 1.08f), l("Heads up!", 1.15f, 1.10f),
            l("Swinging by!", 1.05f, 1.05f), l("Look out below!", 1.00f, 1.00f)),
        arrayOf(l("That was close!", 1.20f, 1.15f), l("Too close!", 1.25f, 1.20f),
            l("Phew, almost!", 1.10f, 1.05f)),
        arrayOf(l("Nailed it.", 0.95f, 0.95f), l("Smooth.", 0.92f, 0.92f),
            l("Stuck the landing.", 1.00f, 0.98f)),
        arrayOf(l("Okay, need a plan!", 1.25f, 1.25f), l("Not great, not great!", 1.30f, 1.30f),
            l("Uh oh, uh oh!", 1.35f, 1.30f)),
        arrayOf(l("Whoa!", 1.30f, 1.20f), l("Whoa, whoa!", 1.28f, 1.25f), l("Woah, okay!", 1.20f, 1.15f)),
        arrayOf(l("Made it.", 0.95f, 0.95f), l("Safe and sound.", 0.98f, 0.95f), l("Rooftop, check.", 1.00f, 1.00f)),
        arrayOf(l("Let's keep moving.", 1.00f, 1.02f), l("Onward!", 1.08f, 1.08f),
            l("Next stop, anywhere.", 1.02f, 1.00f)),
        arrayOf(l("Nice!", 1.18f, 1.10f), l("Ooh, stylish!", 1.15f, 1.08f),
            l("Okay, that was fun!", 1.10f, 1.05f)),
        arrayOf(l("That was a rough landing.", 0.90f, 0.95f), l("Ow. Okay.", 0.88f, 0.92f),
            l("My knees felt that.", 0.92f, 0.95f), l("Okay, felt that.", 0.90f, 0.95f)),
        arrayOf(l("Whoa! Let's go!", 1.25f, 1.20f), l("Hang on!", 1.20f, 1.18f),
            l("Boosting!", 1.18f, 1.15f))
    )

    //                                   JUMP  SWING CLOSE LAND  FALL  WHOA  ARRIVE REL   NICE  ROUGH BOOST
    private val cooldown = floatArrayOf(9f, 8f, 6f, 7f, 10f, 5f, 8f, 9f, 8f, 8f, 5f)
    private val chance = floatArrayOf(0.45f, 0.50f, 1.0f, 0.60f, 1.0f, 0.90f, 0.70f, 0.35f, 0.70f, 1.0f, 0.85f)
    private val prio = intArrayOf(1, 1, 3, 2, 4, 3, 2, 1, 2, 3, 3)

    init {
        try {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    try { tts?.setLanguage(Locale.US) } catch (e: Exception) { }
                    ready = true
                }
            }
        } catch (e: Exception) { tts = null }
    }

    /**
     * Ask for a callout. [now] is game time in seconds (it stops while paused),
     * [vol] is 0..1. Returns the line chosen, or null if it was gated out.
     */
    fun say(cue: Int, now: Float, vol: Float): VoiceLine? {
        if (vol <= 0f) return null
        if (now - lastCue[cue] < cooldown[cue]) return null
        if (rng.nextFloat() > chance[cue]) return null
        val busy = now < busyUntil
        if (busy && prio[cue] <= busyPrio) return null

        val pool = pools[cue]
        var i = rng.nextInt(pool.size)
        if (i == lastIdx[cue]) i = (i + 1) % pool.size
        lastIdx[cue] = i
        val line = pool[i]

        lastCue[cue] = now
        val pitch = line.pitch + (rng.nextFloat() - 0.5f) * 0.12f
        val rate = line.rate + (rng.nextFloat() - 0.5f) * 0.08f
        busyUntil = now + 0.3f + line.text.length * 0.06f / max(0.5f, rate)
        busyPrio = prio[cue]
        speak(line.text, pitch, rate, vol)
        return line
    }

    private fun speak(s: String, pitch: Float, rate: Float, vol: Float) {
        val t = tts ?: return
        if (!ready) return
        try {
            t.setPitch(pitch)
            t.setSpeechRate(rate)
            val b = Bundle()
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol)
            // FLUSH: only one line is ever audible, and a stale line never plays late.
            t.speak(s, TextToSpeech.QUEUE_FLUSH, b, "hero")
        } catch (e: Exception) { }
    }

    fun stop() {
        busyUntil = -1f; busyPrio = 0
        try { tts?.stop() } catch (e: Exception) { }
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null; ready = false
    }
}
