package com.example.spiderrunner

import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// World objects. Everything the physics touches is a Building rectangle (x, w, top; infinitely deep):
//   kind 0 = real building, kind 1 = SOLID rooftop prop (AC unit, access room, ...). Props live in the
//   same x-sorted list, so the existing landing / wall / vault / climb code handles them unchanged.
// Decor is draw-only (no collision, no targeting). Anchor is the only thing a web can attach to.
// ---------------------------------------------------------------------------------------------

const val BK_BUILDING = 0
const val BK_PROP = 1

// solid prop types (collision + drawing)
const val PT_AC = 1; const val PT_VENT = 2; const val PT_BOX = 3; const val PT_ROOM = 4
const val PT_BARRIER = 5; const val PT_PLATFORM = 6; const val PT_TANK = 7; const val PT_CRATES = 8; const val PT_PIPES = 9

// decorative types (drawing only)
const val DC_ANT = 1; const val DC_DISH = 2; const val DC_PIPE = 3; const val DC_CHIM = 4; const val DC_PLANT = 5
const val DC_RAIL = 6; const val DC_SOLAR = 7; const val DC_STACK = 8; const val DC_COLS = 9; const val DC_PALLET = 10

// anchor (web target) structures
const val AK_CRANE = 0   // crane jib + hook; the hook is the anchor
const val AK_TOWER = 1   // antenna / comm tower, tip is the anchor
const val AK_BOARD = 2   // billboard on a tall frame, top of the frame is the anchor
const val AK_TANK = 3    // water tank on a steel frame, top of the roof cone is the anchor
const val AK_SCAFF = 4   // scaffolding tower, top beam is the anchor
const val AK_BEAM = 5    // steel beam cantilevered over the gap from a roof column
const val AK_POLE = 6    // flag pole / outrigger sticking out of a tall facade

class Decor { var type = 0; var dx = 0f; var w = 0f; var h = 0f }

class Building {
    var x = 0f; var w = 0f; var top = 0f
    var style = 0; var deco = 0; var seed = 0       // deco: 1 = building under construction
    var kind = BK_BUILDING; var ptype = 0; var tier = 0
    var h = 0f                                      // prop height (props only)
    var parent: Building? = null                    // props point at the building they stand on
    val decor = ArrayList<Decor>(6)
}

class Anchor {
    var x = 0f; var y = 0f                          // the point the web attaches to
    var bx = 0f; var by = 0f                        // where the structure is bolted on (roof / wall)
    var kind = AK_CRANE; var len = 0f; var flags = 0; var seed = 0   // flags bit0 = draws mast / frame
}

/**
 * Procedural city. Pure Kotlin (no Android types) and fully seeded: the same seed, difficulty and speed
 * sequence always produces the same city, which makes layouts reproducible for testing.
 *
 * Tiers (height above the 288 px street, player is ~25 px tall):
 *   0 short   ~110-190 px  (4.5-7.5x)      1 medium ~190-280 px (7.5-11x)
 *   2 tall    ~280-400 px  (11-16x)        3 skyscraper ~400-540 px (16-21x)
 */
class CityGenerator {
    companion object {
        val TIER_LO = floatArrayOf(100f, 10f, -110f, -250f)    // roof y range per tier (smaller y = taller)
        val TIER_HI = floatArrayOf(176f, 100f, 10f, -110f)
        val W_LO = floatArrayOf(150f, 170f, 190f, 160f)         // roof length range per tier
        val W_HI = floatArrayOf(280f, 320f, 360f, 300f)
        const val TOP_MIN = -250f
        const val TOP_MAX = 176f
        const val MAX_RISE = 90f          // next roof may be at most this much higher (wall climb / corner zip)
        const val MAX_RISE_SWING = 18f    // after a swing-only gap the landing roof is level or lower
        const val MAX_DROP = 280f
        const val EDGE_L = 40f            // empty runway at the left end of a roof (landing zone)
        const val EDGE_R = 34f            // empty run-up at the right end (take-off zone, crane masts)

        fun tierOf(top: Float): Int = if (top >= 100f) 0 else if (top >= 10f) 1 else if (top >= -110f) 2 else 3
    }

    private var rng = Random(1L)
    var genX = -120f
        private set
    var lastTop = 150f
        private set
    private var tier = 0
    private var lastB: Building? = null

    private val bPool = ArrayList<Building>()
    private val aPool = ArrayList<Anchor>()
    private val dPool = ArrayList<Decor>()
    private val occ = FloatArray(48)          // occupied x-intervals on the roof being filled (start, end pairs)
    private var occN = 0

    fun reset(seed: Long, startX: Float) {
        rng = Random(seed)
        genX = startX; lastTop = 150f; tier = 0; lastB = null; occN = 0
    }

    fun shift(dx: Float) { genX -= dx }

    // ---- pooling ----
    private fun obtain(): Building {
        val b = if (bPool.isEmpty()) Building() else bPool.removeAt(bPool.size - 1)
        for (i in 0 until b.decor.size) dPool.add(b.decor[i])
        b.decor.clear()
        b.kind = BK_BUILDING; b.ptype = 0; b.parent = null; b.deco = 0; b.tier = 0
        return b
    }
    fun recycle(b: Building) { if (lastB === b) lastB = null; bPool.add(b) }
    private fun obtainAnchor(): Anchor {
        val a = if (aPool.isEmpty()) Anchor() else aPool.removeAt(aPool.size - 1)
        a.flags = 0; a.len = 0f; a.seed = rng.nextInt() and 0x7fffffff
        return a
    }
    fun recycleAnchor(a: Anchor) { aPool.add(a) }
    private fun obtainDecor(): Decor = if (dPool.isEmpty()) Decor() else dPool.removeAt(dPool.size - 1)

    // ---- occupancy helpers ----
    private fun occAdd(x0: Float, x1: Float) { if (occN + 2 <= occ.size) { occ[occN] = x0; occ[occN + 1] = x1; occN += 2 } }
    private fun occHit(x0: Float, x1: Float, pad: Float): Boolean {
        var i = 0
        while (i < occN) { if (x0 < occ[i + 1] + pad && x1 > occ[i] - pad) return true; i += 2 }
        return false
    }

    /** Adds one building (plus its rooftop props and the anchors that serve the gap before it). */
    fun spawn(world: ArrayDeque<Building>, anchors: ArrayList<Anchor>, diff: Float, speed: Float) {
        val b = obtain()
        val reach = speed * 0.46f
        val prev = lastB
        var gap = 0f
        var gapKind = 0
        val w: Float
        val t: Float
        if (prev == null) {
            w = 460f; t = 150f
        } else {
            val maxTier = if (diff < 0.05f) 1 else if (diff < 0.15f) 2 else 3
            val r = rng.nextFloat()
            var nt = tier
            if (r < 0.40f) nt = tier
            else if (r < 0.72f) nt = tier + 1
            else if (r < 0.94f) nt = tier - 1
            else nt = tier + (if (rng.nextBoolean()) 2 else -2)
            nt = nt.coerceIn(0, maxTier)

            val g = rng.nextFloat()
            gapKind = if (g < 0.10f + 0.20f * diff) 2 else if (g < 0.50f) 1 else 0
            gap = when (gapKind) {
                2 -> min(reach * 1.5f + rng.nextFloat() * reach * (0.6f + diff), 300f)        // swing gap
                1 -> 0.45f * reach + 10f + rng.nextFloat() * 0.5f * reach                       // jump / optional swing
                else -> 12f + rng.nextFloat() * (0.25f * reach + 6f)                            // hop
            }
            var tt = TIER_LO[nt] + rng.nextFloat() * (TIER_HI[nt] - TIER_LO[nt])
            val maxRise = if (gap > reach) MAX_RISE_SWING else MAX_RISE
            if (tt < lastTop - maxRise) tt = lastTop - maxRise
            if (tt > lastTop + MAX_DROP) tt = lastTop + MAX_DROP
            t = tt.coerceIn(TOP_MIN, TOP_MAX)

            val tr = tierOf(t)
            var wv = W_LO[tr] + rng.nextFloat() * (W_HI[tr] - W_LO[tr])
            if (rng.nextFloat() < 0.12f) wv += 80f + rng.nextFloat() * 120f                     // the odd very long roof
            w = max(130f, wv * (1f - 0.2f * diff))
        }
        b.tier = tierOf(t)
        b.x = genX + gap; b.w = w; b.top = t
        val sr = rng.nextFloat()
        b.style = when (b.tier) {
            0 -> if (sr < 0.55f) 0 else if (sr < 0.85f) 1 else 2
            1 -> if (sr < 0.35f) 0 else if (sr < 0.75f) 1 else 2
            2 -> if (sr < 0.15f) 0 else if (sr < 0.50f) 1 else 2
            else -> if (sr < 0.05f) 0 else if (sr < 0.30f) 1 else 2
        }
        b.seed = rng.nextInt() and 0x7fffffff
        b.deco = if (prev != null && b.tier >= 1 && rng.nextFloat() < 0.14f) 1 else 0
        world.addLast(b)

        if (prev != null && (gap > reach * 0.85f || (gapKind == 1 && rng.nextFloat() < 0.5f))) addGapAnchors(prev, b, gap, anchors)
        if (prev != null) fillRoof(b, world, anchors)

        genX = b.x + b.w
        lastTop = t
        tier = b.tier
        lastB = b
    }

    // ---------------------------------------------------------------------------------------
    // Anchors over a gap. The taller side hosts the structure (crane mast / beam column), so the hook is
    // always at least `H` above BOTH roofs; a bot-driven sweep (see docs) lands the swing from every
    // gap size 100-300 px at 105-240 px/s. Gaps >= 190 get two hooks on one jib so swings chain.
    // ---------------------------------------------------------------------------------------
    private fun addGapAnchors(prev: Building, b: Building, gap: Float, anchors: ArrayList<Anchor>) {
        val tl = prev.top; val tr = b.top
        val base = min(tl, tr)
        val parentLeft = tl <= tr
        val leftEdge = prev.x + prev.w
        val rightEdge = b.x
        val n = if (gap < 190f) 1 else 2
        val h = 48f + 0.30f * gap * (if (n == 2) 0.75f else 1f) + rng.nextFloat() * 16f
        val ay = base - h

        if (n == 1 && gap <= 100f && rng.nextFloat() < 0.4f) {
            // steel beam out of a roof column, hook at its tip
            val a = obtainAnchor()
            a.kind = AK_BEAM; a.flags = 1
            a.bx = if (parentLeft) leftEdge - 4f else rightEdge + 4f
            a.by = base
            a.x = if (parentLeft) leftEdge + gap * 0.5f else rightEdge - gap * 0.5f
            a.y = ay
            a.len = abs(a.x - a.bx)
            anchors.add(a)
        } else {
            val a1 = obtainAnchor()
            a1.kind = AK_CRANE; a1.flags = 1
            a1.bx = if (parentLeft) leftEdge - 12f else rightEdge + 12f
            a1.by = base
            a1.y = ay
            var far: Float
            if (n == 1) {
                a1.x = leftEdge + gap * 0.5f
                far = abs(a1.x - a1.bx)
                anchors.add(a1)
            } else {
                a1.x = leftEdge + gap * 0.30f
                val a2 = obtainAnchor()
                a2.kind = AK_CRANE; a2.flags = 0
                a2.bx = a1.bx; a2.by = a1.by; a2.y = ay
                a2.x = leftEdge + gap * 0.72f
                far = max(abs(a1.x - a1.bx), abs(a2.x - a1.bx))
                a1.len = far; a2.len = far
                anchors.add(a1); anchors.add(a2)
            }
            a1.len = far
        }

        // a flag pole / outrigger on the exposed facade of the taller building gives a second route
        val drop = abs(tl - tr)
        if (drop >= 100f && gap >= 40f && rng.nextFloat() < 0.6f) {
            val tallerIsLeft = tl < tr
            val lowerTop = max(tl, tr)
            val len = 22f
            val pole = obtainAnchor()
            pole.kind = AK_POLE; pole.flags = 1; pole.len = len
            val y = base + 40f + rng.nextFloat() * (drop - 90f)
            pole.by = y; pole.y = y
            pole.bx = if (tallerIsLeft) leftEdge else rightEdge
            pole.x = if (tallerIsLeft) leftEdge + len else rightEdge - len
            if (y <= lowerTop - 40f) anchors.add(pole) else aPool.add(pole)
        }
    }

    // ---------------------------------------------------------------------------------------
    // Rooftop contents: one optional free-standing swing structure, 0-3 solid props, a few decor items.
    // Left 40 px and right 34 px of every roof stay clear: that is the landing / take-off zone.
    // ---------------------------------------------------------------------------------------
    private fun fillRoof(b: Building, world: ArrayDeque<Building>, anchors: ArrayList<Anchor>) {
        occN = 0
        val lo = b.x + EDGE_L
        val hi = b.x + b.w - EDGE_R
        addRoofAnchor(b, lo, hi, anchors)
        addProps(b, lo, hi, world)
        addDecor(b, lo, hi)
    }

    private fun addRoofAnchor(b: Building, lo: Float, hi: Float, anchors: ArrayList<Anchor>) {
        if (b.w < 200f || rng.nextFloat() > 0.45f) return
        val r = rng.nextInt(100)
        val construction = b.deco == 1
        val kind = when {
            construction -> if (r < 50) AK_CRANE else AK_SCAFF
            b.tier == 0 -> if (r < 40) AK_BOARD else if (r < 80) AK_TANK else AK_TOWER
            b.tier == 1 -> if (r < 30) AK_BOARD else if (r < 55) AK_TANK else if (r < 80) AK_TOWER else AK_SCAFF
            else -> if (r < 50) AK_TOWER else if (r < 75) AK_SCAFF else AK_BOARD
        }
        val half = when (kind) { AK_BOARD -> 19f; AK_TANK -> 13f; AK_SCAFF -> 13f; AK_CRANE -> 8f; else -> 7f }
        val span = hi - lo - 2f * half - 70f      // keep >= 70 px of free roof
        if (span < 10f) return
        val bx = lo + half + rng.nextFloat() * span
        val a = obtainAnchor()
        a.kind = kind; a.flags = 1
        a.bx = bx; a.by = b.top
        val h = when (kind) {
            AK_BOARD -> 46f + rng.nextFloat() * 16f
            AK_TANK -> 46f + rng.nextFloat() * 16f
            AK_SCAFF -> 60f + rng.nextFloat() * 50f
            AK_CRANE -> 64f + rng.nextFloat() * 46f
            else -> 70f + rng.nextFloat() * (40f + 30f * b.tier)
        }
        a.y = b.top - h
        if (kind == AK_CRANE) {
            a.x = bx + 46f + rng.nextFloat() * 40f           // jib reaches forward over its own roof
            a.len = a.x - bx
            occAdd(bx - 22f, bx + 6f)                        // mast + counter-jib footprint
        } else {
            a.x = bx
            occAdd(bx - half, bx + half)
        }
        anchors.add(a)
    }

    private fun addProps(b: Building, lo: Float, hi: Float, world: ArrayDeque<Building>) {
        if (hi - lo < 50f) return
        val count = if (rng.nextFloat() < 0.25f) 0 else 1 + rng.nextInt(3)      // a quarter of roofs stay bare
        var cursor = lo + rng.nextFloat() * 24f
        var placed = 0
        var lastTall = false
        while (placed < count) {
            val r = rng.nextInt(100)
            val type: Int = if (b.deco == 1 && rng.nextFloat() < 0.5f) PT_CRATES
            else if (r < 22) PT_AC else if (r < 36) PT_VENT else if (r < 48) PT_BOX
            else if (r < 56) (if (b.w >= 190f) PT_ROOM else PT_BOX)
            else if (r < 70) PT_BARRIER else if (r < 78) PT_PLATFORM
            else if (r < 86) (if (b.tier <= 1) PT_TANK else PT_AC) else PT_PIPES
            val pw: Float; val ph: Float
            when (type) {
                PT_AC -> { pw = 16f + rng.nextInt(11); ph = 9f + rng.nextInt(5) }
                PT_VENT -> { pw = 10f + rng.nextInt(7); ph = 7f + rng.nextInt(6) }
                PT_BOX -> { pw = 8f + rng.nextInt(5); ph = 8f + rng.nextInt(5) }
                PT_ROOM -> { pw = 34f + rng.nextInt(23); ph = 28f + rng.nextInt(7) }
                PT_BARRIER -> { pw = 12f + rng.nextInt(29); ph = 8f + rng.nextInt(4) }
                PT_PLATFORM -> { pw = 24f + rng.nextInt(21); ph = 12f + rng.nextInt(5) }
                PT_TANK -> { pw = 18f + rng.nextInt(5); ph = 24f + rng.nextInt(7) }
                PT_CRATES -> { pw = 14f + rng.nextInt(13); ph = 12f + rng.nextInt(9) }
                else -> { pw = 20f + rng.nextInt(11); ph = 14f + rng.nextInt(5) }
            }
            // slide right past anything already standing here (the swing structure)
            var moved = true
            while (moved) {
                moved = false
                var i = 0
                while (i < occN) {
                    if (cursor < occ[i + 1] + 10f && cursor + pw > occ[i] - 10f) { cursor = occ[i + 1] + 10f; moved = true }
                    i += 2
                }
            }
            if (cursor + pw > hi) break
            val p = obtain()
            p.kind = BK_PROP; p.ptype = type; p.parent = b; p.tier = b.tier; p.style = b.style
            p.x = cursor; p.w = pw; p.top = b.top - ph; p.h = ph
            p.seed = rng.nextInt() and 0x7fffffff
            world.addLast(p)
            occAdd(cursor, cursor + pw)
            lastTall = ph > 26f
            cursor += pw + (if (lastTall) 70f else 36f) + rng.nextFloat() * 70f
            placed++
        }
    }

    private fun addDecor(b: Building, lo: Float, hi: Float) {
        val n = 1 + rng.nextInt(if (b.tier >= 2) 4 else 3)
        for (k in 0 until n) {
            val r = rng.nextInt(100)
            val type: Int
            if (b.deco == 1) type = if (r < 55) DC_COLS else DC_PALLET
            else if (b.tier == 0) type = if (r < 20) DC_PIPE else if (r < 38) DC_CHIM else if (r < 52) DC_PLANT else if (r < 66) DC_DISH else if (r < 80) DC_ANT else if (r < 90) DC_STACK else DC_RAIL
            else if (b.tier == 1) type = if (r < 22) DC_DISH else if (r < 44) DC_ANT else if (r < 62) DC_SOLAR else if (r < 78) DC_PIPE else if (r < 90) DC_STACK else DC_RAIL
            else type = if (r < 35) DC_ANT else if (r < 55) DC_DISH else if (r < 72) DC_STACK else if (r < 88) DC_SOLAR else DC_PIPE
            val w: Float; val h: Float
            when (type) {
                DC_ANT -> { w = 7f; h = 18f + rng.nextInt(17) }
                DC_DISH -> { w = 12f; h = 10f + rng.nextInt(5) }
                DC_PIPE -> { w = 24f + rng.nextInt(21); h = 5f }
                DC_CHIM -> { w = 9f; h = 14f + rng.nextInt(7) }
                DC_PLANT -> { w = 26f; h = 13f }
                DC_RAIL -> { w = 33f; h = 7f }
                DC_SOLAR -> { w = 30f + rng.nextInt(15); h = 8f }
                DC_STACK -> { w = 7f; h = 14f + rng.nextInt(9) }
                DC_COLS -> { w = 22f + rng.nextInt(19); h = 16f + rng.nextInt(13) }
                else -> { w = 18f; h = 6f }
            }
            if (hi - lo < w + 4f) continue
            val x = lo + rng.nextFloat() * (hi - lo - w)
            if (occHit(x, x + w, 6f)) continue
            val d = obtainDecor()
            d.type = type; d.dx = x - b.x; d.w = w; d.h = h
            b.decor.add(d)
            occAdd(x, x + w)
        }
    }
}
