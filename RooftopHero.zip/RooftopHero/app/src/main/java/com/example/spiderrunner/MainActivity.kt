package com.example.spiderrunner

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.atan2
import kotlin.math.sqrt

class MainActivity : Activity() {
    private lateinit var view: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = GameView(this)
        setContentView(view)
        hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() {
        super.onPause()
        view.pauseGame()
    }

    override fun onDestroy() {
        super.onDestroy()
        view.release()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!view.onBack()) super.onBackPressed()
    }
}

private fun K(rgb: Int): Int = rgb or -0x1000000

private fun hash(a: Int): Int {
    var x = a * -1640531527
    x = x xor (x ushr 15)
    x *= 0x2c1b3c6d
    x = x xor (x ushr 12)
    return x and 0x7fffffff
}

class Item(val id: Int, val x: Float, val y: Float, val w: Float, val h: Float)

class GameView(private val ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback {

    companion object {
        const val LH = 216
        const val G = 1100f
        const val STEP = 1f / 120f
        const val JUMP_V = 335f
        const val HW = 4f               // half hitbox width: 8 px (~19 sprite px), matches the hero's torso + swing of the arms
        const val FIXED_SEED = 0        // set to a non-zero value to replay the exact same city every run (testing)
        const val STREET_Y = 288f
        const val DEATH_Y = 296f
        const val ZIP_RANGE = 310f
        const val PX_PER_M = 8f
        const val FW = 64
        const val PVX = 31
        const val PVY = 32
        const val BH = 512
        const val WS = BH / 216f

        const val ST_MENU = 0; const val ST_PLAY = 1; const val ST_PAUSE = 2
        const val ST_OVER = 3; const val ST_EDIT = 4

        const val P_RUN = 0; const val P_AIR = 1; const val P_SWING = 2
        const val P_ZIP = 3; const val P_WALL = 4; const val P_SLIDE = 5; const val P_CORNER = 6
        const val NB = 5
        const val IDLE0 = 10; const val IDLE_N = 10

        const val ID_PLAY = 1; const val ID_SUIT = 2; const val ID_GFX = 3; const val ID_FPS = 4
        const val ID_SND = 5; const val ID_CTRL = 6; const val ID_DIAG = 7; const val ID_EXIT = 8
        const val ID_RESUME = 9; const val ID_RESTART = 10; const val ID_MENU = 11
        const val ID_DONE = 12; const val ID_RESET = 13; const val ID_SIZEP = 14
        const val ID_SIZEM = 15; const val ID_OPAC = 16; const val ID_VOICE = 17

        // landing kinds (drives the landing animation + camera reaction)
        const val VAULT_MAX = 26f
        const val LK_NONE = 0; const val LK_SOFT = 1; const val LK_HERO = 2; const val LK_RUSH = 3; const val LK_ROLL = 4
    }

    private val SKY = IntArray(12)
    private val BASE = intArrayOf(K(0xB5553A), K(0x9C9C98), K(0x8CC3D8))
    private val DARK = intArrayOf(K(0x7A3A42), K(0x626474), K(0x4F86A8))
    private val LIGHT = intArrayOf(K(0xD97C4D), K(0xC9C3AF), K(0xD0EDEC))
    private val CREAM = K(0xEADFC4)
    private val INK = K(0x14202E)
    private val WHITE = K(0xFFFFFF)
    private val BRICKLINE = K(0xA04A33)
    private val WIN_DARK = K(0x34495E)
    private val WIN_LIT = K(0xF2D98B)
    private val WIN_GLASS = K(0xB5DCEC)
    private val WIN_GLASS_B = K(0x7FB5CC)
    private val SILL = K(0xD8CBB0)
    private val STEEL = K(0x59606B)
    private val WOOD = K(0x8B5A3C)
    private val WOOD_L = K(0xA9744F)
    private val WOOD_D = K(0x5E3B26)
    private val GRAYL = K(0xB4B7BB)
    private val GRAYD = K(0x7C8087)
    private val GREEN = K(0x4E9A4A)
    private val GREEN_D = K(0x2F6B33)
    private val RED = K(0xC62F2F)
    private val BLUE = K(0x2B4FA8)
    private val LIGHTB = K(0x5C80D6)
    private val SUIT_A = intArrayOf(K(0xD62828), K(0x23232E), K(0xF08A24))
    private val SUIT_B = intArrayOf(K(0x1D3F9E), K(0xB01E1E), K(0x6A2C91))
    private val SUIT_NAME = arrayOf("CLASSIC", "MIDNIGHT", "SUNRISE")
    private val SUIT_REQ = intArrayOf(0, 500, 1500)
    private val FPS_OPTS = intArrayOf(30, 45, 60, 90)
    private val GFX_NAME = arrayOf("LOW", "MED", "HIGH")

    private val lock = Any()
    private val prefs = ctx.getSharedPreferences("rooftop_hero", Context.MODE_PRIVATE)
    private var bmp: Bitmap? = null
    private var cv: Canvas? = null
    private var lw = 384
    private var scale = 1f
    private val p = Paint()
    private val srcR = Rect(); private val dstR = Rect(); private val blitP = Paint()
    private var loop: Loop? = null
    private var tone: ToneGenerator? = null
    private var lastSfx = 0L

    private var gfx = 1; private var fpsI = 2; private var snd = 2; private var diag = false
    private var suit = 0; private var best = 0; private var runs = 0; private var totalM = 0
    private var opac = 0.55f
    private val bx = FloatArray(NB); private val by = FloatArray(NB); private val bs = FloatArray(NB)
    private val defBx = floatArrayOf(0.90f, 0.10f, 0.76f, 0.94f, 0.62f)
    private val defBy = floatArrayOf(0.74f, 0.74f, 0.84f, 0.10f, 0.86f)
    private val defBs = floatArrayOf(46f, 40f, 36f, 20f, 34f)
    private val btnDown = BooleanArray(NB)
    private val ptr = IntArray(16) { -1 }
    private var sel = 0

    private var st = ST_MENU
    private var editFrom = ST_MENU
    private var time = 0f
    private var acc = 0f
    private var menuItems = arrayOf<Item>()
    private var pauseItems = arrayOf<Item>()
    private var overItems = arrayOf<Item>()
    private var editItems = arrayOf<Item>()

    private val world = ArrayDeque<Building>()
    private val anchors = ArrayList<Anchor>()
    private val gen = CityGenerator()
    private var runSeed = 1

    private var px = 0f; private var py = 150f; private var vx = 0f; private var vy = 0f
    private var ps = P_RUN
    private var airT = 0f; private var coyote = 0f; private var jumpBuf = 0f
    private var jumped = false; private var cut = false; private var canFlip = false
    private var landT = 0f; private var wallT = 0f; private var wallCd = 0f; private var startT = 0f
    private var shootT = 0f; private var zipCd = 0f; private var zipT = 0f
    private var runPhase = 0f
    private var wallHit = false
    private var hitB: Building? = null
    private var wallB: Building? = null
    private var jumpHeld = false; private var swingHeld = false
    private var swingPress = false; private var zipPress = false
    private var slideHeld = false; private var slidePress = false
    private var slideT = 0f; private var slideCd = 0f; private var slideBuf = 0f; private var slideDust = 0f
    private var rollT = 0f; private var kickT = 0f
    private var ropeMin = 40f; private var webWob = 0f
    private var zipHeld = false; private var comboPress = false
    private var tWeb = -10f; private var tZip = -10f
    private var boostT = 0f; private var boostFlyT = 0f; private var boostPreT = 0f
    private var boostDx = 1f; private var boostDy = 0f
    private var cornerT = 0f; private var zipV0 = 280f; private var zipCombo = false
    private var climbPhase = 0f
    private var shakeT = 0f; private var shakeMag = 0f; private var camLead = 0f
    private var bumpHint = false
    private var ax = 0f; private var ay = 0f; private var ropeL = 0f
    private var zTx = 0f; private var zTy = 0f
    private var cAx = 0f; private var cAy = 0f
    private var indT = 0f; private var indZip = false; private var indSwing = false
    private var iZx = 0f; private var iZy = 0f; private var iAx = 0f; private var iAy = 0f
    private var dist = 0.0
    private var lastMile = 0
    private var toast = ""; private var toastT = 0f

    private var camX = -100f; private var camY = 40f

    // ---- cinematic / animation / voice layer ----
    private val voice = VoiceDirector(ctx)
    private val cam = CineCam()
    private val sqz = Spring(200f, 12f)     // squash & stretch: + stretches tall, - crouches
    private val rotSp = Spring(230f, 13f)   // body wobble (degrees) for recoveries and flicks
    private var voiceOn = true
    private val VOICE_VOL = floatArrayOf(0f, 0.55f, 0.8f, 1f)
    private var landKind = LK_NONE
    private var fallT = 0f; private var longFallSaid = false; private var airLowY = 0f
    private var lastGroundB: Building? = null
    private var lastTrick = -1
    private var comboWindow = 0.12f           // max gap (s) between Swing and Zip taps to count as simultaneous
    private var vaultT = 0f; private var vaultVx = 0f
    private var stylePts = 0
    // explicit animation state machine (observes physics, never changes velocity)
    private val anim = AnimStateMachine().also { sm ->
        sm.onTrickComplete = { t ->
            val pts = if (t == AnimState.AIR_DOUBLEFLIP) 100 else 50
            stylePts += pts; toast = "STYLE +$pts"; toastT = 1f
        }
        sm.listener = { _, to ->
            when (to) {
                AnimState.SWING_RELEASE -> say(Cue.RELEASE)
                AnimState.AIR_TWIST, AnimState.AIR_DOUBLEFLIP -> say(Cue.NICE)
                AnimState.LAND_HEAVY -> say(Cue.ROUGH)
                else -> {}
            }
        }
    }
    private var bubbleText = ""; private var bubbleT = 0f

    // Hero sprite sheet: 3 suit rows x 10 frames (0 = idle, 1..9 = run cycle), 64x64 each, drawn 1:1
    private var heroSheet: Bitmap? = null
    private val spriteP = Paint()
    private val fSrc = Rect(); private val fDst = Rect()
    private var handSx = 0f; private var handSy = 0f

    private val MAXP = 40
    private val pxs = FloatArray(MAXP); private val pys = FloatArray(MAXP)
    private val pvx = FloatArray(MAXP); private val pvy = FloatArray(MAXP)
    private val plife = FloatArray(MAXP)

    private var fpsAvg = 60f; private var frameMs = 0f
    private var visB = 0; private var activeP = 0; private var memMb = 0L; private var memT = 0f

    init {
        holder.addCallback(this)
        p.isAntiAlias = false
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        blitP.isFilterBitmap = false
        blitP.isAntiAlias = false
        for (i in SKY.indices) {
            val t = i / (SKY.size - 1f)
            val r = (0x2F + (0xC8 - 0x2F) * t).toInt()
            val g = (0x8F + (0xEA - 0x8F) * t).toInt()
            val b = (0xE8 + (0xFB - 0xE8) * t).toInt()
            SKY[i] = K((r shl 16) or (g shl 8) or b)
        }
        spriteP.isFilterBitmap = false
        spriteP.isAntiAlias = false
        try {
            val o = BitmapFactory.Options(); o.inScaled = false
            ctx.assets.open("hero.png").use { heroSheet = BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Exception) { heroSheet = null }
        loadPrefs()
        resetWorld()
        camX = -100f; camY = 40f
    }

    private fun loadPrefs() {
        gfx = prefs.getInt("gfx", 1); fpsI = prefs.getInt("fps", 2); snd = prefs.getInt("snd", 2)
        diag = prefs.getBoolean("diag", false); suit = prefs.getInt("suit", 0)
        best = prefs.getInt("best", 0); runs = prefs.getInt("runs", 0); totalM = prefs.getInt("total", 0)
        opac = prefs.getFloat("opac", 0.55f)
        voiceOn = prefs.getBoolean("voice", true)
        resetControls()
        val s = prefs.getString("ctl", null)
        if (s != null) {
            try {
                val parts = s.split(";")
                for (i in 0 until min(parts.size, NB)) {
                    val v = parts[i].split(",")
                    bx[i] = v[0].toFloat(); by[i] = v[1].toFloat(); bs[i] = v[2].toFloat()
                }
            } catch (e: Exception) { resetControls() }
        }
        if (best < SUIT_REQ[suit]) suit = 0
    }

    private fun resetControls() {
        for (i in 0 until NB) { bx[i] = defBx[i]; by[i] = defBy[i]; bs[i] = defBs[i] }
    }

    private fun saveSettings() {
        prefs.edit().putInt("gfx", gfx).putInt("fps", fpsI).putInt("snd", snd)
            .putBoolean("diag", diag).putBoolean("voice", voiceOn).putInt("suit", suit).putFloat("opac", opac).apply()
    }

    private fun saveControls() {
        val sb = StringBuilder()
        for (i in 0 until NB) { sb.append(bx[i]).append(',').append(by[i]).append(',').append(bs[i]); if (i < NB - 1) sb.append(';') }
        prefs.edit().putString("ctl", sb.toString()).putFloat("opac", opac).apply()
    }

    private fun saveStats() {
        prefs.edit().putInt("best", best).putInt("runs", runs).putInt("total", totalM).apply()
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        makeTone()
        loop = Loop().also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        synchronized(lock) {
            scale = hh / LH.toFloat()
            val bw = max((320 * WS).roundToInt(), (w * BH.toFloat() / hh).roundToInt())
            lw = ceil(bw / WS).toInt()
            val b = Bitmap.createBitmap(bw, BH, Bitmap.Config.ARGB_8888)
            bmp = b; cv = Canvas(b)
            srcR.set(0, 0, bw, BH); dstR.set(0, 0, w, hh)
            buildLayouts()
        }
    }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        val l = loop
        l?.alive = false
        try { l?.join(800) } catch (e: Exception) { }
        loop = null
        tone?.release(); tone = null
    }

    fun pauseGame() {
        synchronized(lock) {
            if (st == ST_PLAY) { st = ST_PAUSE; releaseAll() }
            voice.stop()
            saveSettings(); saveControls(); saveStats()
        }
    }

    fun release() {
        voice.shutdown()
    }

    fun onBack(): Boolean {
        synchronized(lock) {
            when (st) {
                ST_PLAY -> { st = ST_PAUSE; releaseAll(); voice.stop(); return true }
                ST_PAUSE -> { st = ST_PLAY; return true }
                ST_EDIT -> { tapItem(ID_DONE); return true }
                ST_OVER -> { toMenu(); return true }
                else -> {}
            }
        }
        return false
    }

    private inner class Loop : Thread() {
        @Volatile var alive = true
        override fun run() {
            var last = System.nanoTime()
            while (alive) {
                val t0 = System.nanoTime()
                var dt = (t0 - last) / 1e9f
                last = t0
                if (dt > 0.1f) dt = 0.1f
                synchronized(lock) { update(dt); render() }
                blit()
                val spent = System.nanoTime() - t0
                val target = 1_000_000_000L / FPS_OPTS[fpsI]
                if (spent < target) {
                    try { sleep((target - spent) / 1_000_000L, ((target - spent) % 1_000_000L).toInt()) } catch (e: Exception) { }
                }
                val full = (System.nanoTime() - t0) / 1e9f
                if (full > 0f) fpsAvg = fpsAvg * 0.92f + (1f / full) * 0.08f
                frameMs = frameMs * 0.92f + (spent / 1e6f) * 0.08f
            }
        }
    }

    private fun blit() {
        val b = bmp ?: return
        val c = try { holder.lockCanvas() } catch (e: Exception) { null } ?: return
        c.drawBitmap(b, srcR, dstR, blitP)
        try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
    }

    private fun makeTone() {
        tone?.release()
        tone = if (snd > 0) try { ToneGenerator(AudioManager.STREAM_MUSIC, intArrayOf(0, 30, 60, 100)[snd]) } catch (e: Exception) { null } else null
    }

    private fun sfx(t: Int, ms: Int = 40) {
        if (snd == 0) return
        val now = System.nanoTime()
        if (now - lastSfx < 70_000_000L) return
        lastSfx = now
        try { tone?.startTone(t, ms) } catch (e: Exception) { }
    }

    private fun buildLayouts() {
        val cx = lw / 2f
        menuItems = arrayOf(
            Item(ID_PLAY, 24f, 78f, 120f, 30f), Item(ID_SUIT, 24f, 114f, 120f, 24f),
            Item(ID_CTRL, 24f, 144f, 120f, 24f), Item(ID_EXIT, 24f, 174f, 120f, 24f),
            Item(ID_GFX, 156f, 72f, 140f, 22f), Item(ID_FPS, 156f, 97f, 140f, 22f),
            Item(ID_SND, 156f, 122f, 140f, 22f), Item(ID_VOICE, 156f, 147f, 140f, 22f),
            Item(ID_DIAG, 156f, 172f, 140f, 22f))
        pauseItems = arrayOf(
            Item(ID_RESUME, cx - 60, 52f, 120f, 26f), Item(ID_RESTART, cx - 60, 84f, 120f, 26f),
            Item(ID_CTRL, cx - 60, 116f, 120f, 26f), Item(ID_MENU, cx - 60, 148f, 120f, 26f))
        overItems = arrayOf(
            Item(ID_RESTART, cx - 125, 150f, 120f, 28f), Item(ID_MENU, cx + 5, 150f, 120f, 28f))
        val x0 = cx - 158
        editItems = arrayOf(
            Item(ID_SIZEM, x0, 96f, 58f, 22f), Item(ID_SIZEP, x0 + 62, 96f, 58f, 22f),
            Item(ID_OPAC, x0 + 124, 96f, 58f, 22f), Item(ID_RESET, x0 + 186, 96f, 58f, 22f),
            Item(ID_DONE, x0 + 248, 96f, 68f, 22f))
    }

    private fun label(id: Int): String = when (id) {
        ID_PLAY -> "PLAY"
        ID_SUIT -> "SUIT " + SUIT_NAME[suit]
        ID_CTRL -> "CONTROLS"
        ID_EXIT -> "EXIT"
        ID_GFX -> "GRAPHICS " + GFX_NAME[gfx]
        ID_FPS -> "FPS " + FPS_OPTS[fpsI]
        ID_SND -> if (snd == 0) "SOUND OFF" else "SOUND " + snd
        ID_VOICE -> if (voiceOn) "VOICE ON" else "VOICE OFF"
        ID_DIAG -> if (diag) "STATS ON" else "STATS OFF"
        ID_RESUME -> "RESUME"
        ID_RESTART -> if (st == ST_OVER) "RETRY" else "RESTART"
        ID_MENU -> "MENU"
        ID_DONE -> "DONE"
        ID_RESET -> "RESET"
        ID_SIZEP -> "SIZE +"
        ID_SIZEM -> "SIZE -"
        ID_OPAC -> "OPAC " + (opac * 100).toInt()
        else -> ""
    }

    private fun tapItem(id: Int) {
        sfx(ToneGenerator.TONE_PROP_BEEP, 30)
        when (id) {
            ID_PLAY -> startRun()
            ID_SUIT -> {
                var s = suit
                for (i in 0 until 3) { s = (s + 1) % 3; if (best >= SUIT_REQ[s]) break }
                suit = s; saveSettings()
            }
            ID_GFX -> { gfx = (gfx + 1) % 3; saveSettings() }
            ID_FPS -> { fpsI = (fpsI + 1) % FPS_OPTS.size; saveSettings() }
            ID_SND -> { snd = (snd + 1) % 4; makeTone(); saveSettings() }
            ID_VOICE -> { voiceOn = !voiceOn; if (!voiceOn) voice.stop(); saveSettings() }
            ID_DIAG -> { diag = !diag; saveSettings() }
            ID_CTRL -> { editFrom = st; st = ST_EDIT; sel = 0 }
            ID_EXIT -> (ctx as? Activity)?.finish()
            ID_RESUME -> st = ST_PLAY
            ID_RESTART -> startRun()
            ID_MENU -> toMenu()
            ID_DONE -> { saveControls(); st = editFrom }
            ID_RESET -> { resetControls(); opac = 0.55f; saveControls() }
            ID_SIZEP -> bs[sel] = min(bs[sel] + 4f, 80f)
            ID_SIZEM -> bs[sel] = max(bs[sel] - 4f, 14f)
            ID_OPAC -> { opac += 0.15f; if (opac > 0.9f) opac = 0.25f }
        }
    }

    private fun toMenu() {
        st = ST_MENU
        dist = 0.0
        resetWorld()
        camX = -100f; camY = 40f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        synchronized(lock) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex
                    touchDown(e.getPointerId(i), e.getX(i) / scale, e.getY(i) / scale)
                }
                MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount)
                    touchMove(e.getPointerId(i), e.getX(i) / scale, e.getY(i) / scale)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> touchUp(e.getPointerId(e.actionIndex))
                MotionEvent.ACTION_CANCEL -> releaseAll()
                else -> {}
            }
        }
        return true
    }

    private fun hitItem(list: Array<Item>, x: Float, y: Float): Item? {
        for (m in list) if (x >= m.x && x <= m.x + m.w && y >= m.y && y <= m.y + m.h) return m
        return null
    }

    private fun hitButton(x: Float, y: Float): Int {
        for (k in NB - 1 downTo 0) {
            val r = bs[k] * 0.58f
            val cx = bx[k] * lw; val cy = by[k] * LH
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy <= r * r) return k
        }
        return -1
    }

    private fun touchDown(id: Int, x: Float, y: Float) {
        when (st) {
            ST_PLAY -> {
                val k = hitButton(x, y)
                if (k >= 0 && id < 16) { ptr[id] = k; press(k) }
            }
            ST_EDIT -> {
                val m = hitItem(editItems, x, y)
                if (m != null) tapItem(m.id)
                else { val k = hitButton(x, y); if (k >= 0 && id < 16) { sel = k; ptr[id] = k } }
            }
            else -> {
                val list = when (st) { ST_MENU -> menuItems; ST_PAUSE -> pauseItems; else -> overItems }
                val m = hitItem(list, x, y)
                if (m != null) tapItem(m.id)
            }
        }
    }

    private fun touchMove(id: Int, x: Float, y: Float) {
        if (st == ST_EDIT && id < 16 && ptr[id] >= 0) {
            val k = ptr[id]
            bx[k] = (x / lw).coerceIn(0.05f, 0.95f)
            by[k] = (y / LH).coerceIn(0.08f, 0.92f)
        }
    }

    private fun touchUp(id: Int) {
        if (id >= 16) return
        val k = ptr[id]
        if (k >= 0) {
            ptr[id] = -1
            if (st == ST_PLAY) release(k) else if (st == ST_EDIT) saveControls()
        }
    }

    private fun press(k: Int) {
        btnDown[k] = true
        when (k) {
            0 -> { jumpHeld = true; jumpBuf = 0.12f }
            1 -> { swingHeld = true; swingPress = true; tWeb = time; if (time - tZip < comboWindow) comboPress = true }
            2 -> { zipHeld = true; zipPress = true; tZip = time; if (time - tWeb < comboWindow) comboPress = true }
            3 -> { st = ST_PAUSE; releaseAll(); voice.stop() }
            4 -> { slideHeld = true; slidePress = true }
        }
    }

    private fun release(k: Int) {
        btnDown[k] = false
        when (k) { 0 -> jumpHeld = false; 1 -> swingHeld = false; 2 -> zipHeld = false; 4 -> slideHeld = false }
    }

    private fun releaseAll() {
        for (i in ptr.indices) ptr[i] = -1
        for (i in 0 until NB) btnDown[i] = false
        jumpHeld = false; swingHeld = false; swingPress = false; zipPress = false
        slideHeld = false; slidePress = false; zipHeld = false; comboPress = false
    }

    private fun diff(): Float = min(1f, (dist / PX_PER_M).toFloat() / 2000f)
    private fun targetSpeed(): Float = (105f + 135f * diff()) * (1f + 0.3f * min(1f, boostT))
    private fun meters(): Int = (dist / PX_PER_M).toInt()

    private fun resetWorld() {
        while (world.isNotEmpty()) gen.recycle(world.removeFirst())
        for (i in 0 until anchors.size) gen.recycleAnchor(anchors[i])
        anchors.clear()
        gen.reset(runSeed.toLong(), -120f)
        ensureWorld(lw + 800f)
    }

    private fun ensureWorld(upTo: Float) {
        while (gen.genX < upTo) gen.spawn(world, anchors, diff(), targetSpeed())
    }

    private fun cullWorld(behind: Float) {
        while (world.size > 3 && world.first().x + world.first().w < behind) gen.recycle(world.removeFirst())
        var i = 0
        while (i < anchors.size) {
            val a = anchors[i]
            if (max(a.x, a.bx) < behind) { gen.recycleAnchor(a); anchors.removeAt(i) } else i++
        }
    }

    private fun rebase(shift: Float) {
        for (i in 0 until world.size) world[i].x -= shift
        for (i in 0 until anchors.size) { val a = anchors[i]; a.x -= shift; a.bx -= shift }
        gen.shift(shift)
        px -= shift; camX -= shift; ax -= shift; zTx -= shift
        for (i in 0 until MAXP) plife[i] = 0f
    }

    private fun startRun() {
        runSeed = if (FIXED_SEED != 0) FIXED_SEED else (System.nanoTime() and 0x7fffffff).toInt()
        dist = 0.0
        resetWorld()
        px = 0f; py = 150f; vx = 0f; vy = 0f; ps = P_RUN
        anim.reset(); stylePts = 0; vaultT = 0f
        startT = 0.7f; landT = 0f; wallCd = 0f; zipCd = 0f; jumpBuf = 0f; coyote = 0f
        jumped = false; canFlip = false; wallB = null
        slideT = 0f; slideCd = 0f; slideBuf = 0f; rollT = 0f; kickT = 0f; webWob = 0f
        boostT = 0f; boostFlyT = 0f; boostPreT = 0f; cornerT = 0f; shakeT = 0f; camLead = 0f; climbPhase = 0f
        releaseAll()
        for (i in 0 until MAXP) plife[i] = 0f
        lastMile = 0; toast = ""; toastT = 0f
        camX = px - lw * 0.3f; camY = py - LH * 0.64f
        acc = 0f
        sqz.reset(); rotSp.reset(); cam.reset(); voice.stop()
        landKind = LK_NONE; fallT = 0f; longFallSaid = false; airLowY = 0f; lastTrick = -1
        bubbleT = 0f; rotS = 0f
        lastGroundB = groundBuilding()
        st = ST_PLAY
    }

    private fun die() {
        st = ST_OVER
        cam.reset()
        val m = meters()
        runs++; totalM += m
        if (m > best) best = m
        saveStats()
        releaseAll()
    }

    private fun update(dt: Float) {
        time += dt
        if (toastT > 0f) toastT -= dt
        if (shakeT > 0f) shakeT -= dt
        if (bubbleT > 0f) bubbleT -= dt
        when (st) {
            ST_PLAY -> {
                acc += dt
                var n = 0
                while (acc >= STEP && n < 8) { physics(STEP); acc -= STEP; n++ }
                if (n == 8) acc = 0f
                if (st == ST_PLAY) camera(dt)
            }
            ST_MENU -> menuScroll(dt)
            ST_EDIT -> if (editFrom == ST_MENU) menuScroll(dt)
        }
        if (diag) {
            memT -= dt
            if (memT <= 0f) { memT = 1f; val rt = Runtime.getRuntime(); memMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L }
        }
    }

    private fun menuScroll(dt: Float) {
        camX += 40f * dt
        ensureWorld(camX + lw + 300f)
        cullWorld(camX - 200f)
    }

    private fun camera(dt: Float) {
        val spd = sqrt(vx * vx + vy * vy)
        var camTgt = if (ps == P_ZIP || boostFlyT > 0f) 45f else 0f
        camTgt += ((spd - 240f) * 0.12f).coerceIn(0f, 22f)   // look further ahead at speed
        camLead += (camTgt - camLead) * min(1f, 5f * dt)
        val tx = px - lw * 0.30f + vx * 0.2f + camLead
        camX += (tx - camX) * min(1f, 7f * dt)
        camX = camX.coerceIn(px - lw * 0.62f, px - 70f)
        var ty = py - LH * 0.64f
        if (ps == P_SWING) ty = (py * 0.7f + ay * 0.3f) - LH * 0.62f
        ty += (vy * 0.09f).coerceIn(-12f, 22f)               // look where we are falling / rising
        camY += (ty - camY) * min(1f, 4f * dt)
        camY = camY.coerceIn(py - (LH - 52f), py - 45f)
        cam.update(dt)
    }

    private fun physics(dt: Float) {
        coyote -= dt; jumpBuf -= dt; zipCd -= dt; landT -= dt; wallCd -= dt; shootT -= dt; airT += dt
        slideCd -= dt; rollT -= dt; kickT -= dt; slideBuf -= dt; boostFlyT -= dt; vaultT -= dt
        if (ps == P_SWING || ps == P_ZIP) boostT = 5f else boostT = max(0f, boostT - dt)
        webWob = max(0f, webWob - 9f * dt)
        sqz.step(dt); rotSp.step(dt)
        if (ps == P_AIR) airLowY = max(airLowY, py)
        else if (ps == P_RUN || ps == P_SLIDE || ps == P_CORNER) airLowY = 0f
        if (ps != P_AIR) { fallT = 0f; longFallSaid = false }
        val prevX = px
        if (comboPress) {
            comboPress = false
            // WEB + ZIP together in the air: zip to a building corner
            if (startT <= 0f && zipCd <= 0f && (ps == P_AIR || ps == P_SWING) && findZip(ZIP_RANGE * 1.3f)) {
                swingPress = false; zipPress = false
                tryZip(true)
            }
        }
        if (swingPress) { swingPress = false; if (ps != P_SWING && startT <= 0f) trySwing() }
        if (zipPress) {
            zipPress = false
            if (startT <= 0f && zipCd <= 0f && (ps == P_AIR || ps == P_SWING)) tryZip()
        }
        if (slidePress) {
            slidePress = false
            if (startT <= 0f) {
                if (ps == P_RUN && slideCd <= 0f) startSlide()
                else if (ps == P_AIR) { vy = max(vy, 520f); slideBuf = 0.7f }
            }
        }
        if (!swingHeld && ps == P_SWING) releaseSwing()
        val ts = targetSpeed()

        when (ps) {
            P_RUN -> {
                if (startT > 0f) { startT -= dt; vx = 0f }
                else {
                    vx += (ts - vx) * min(1f, 7f * dt)
                    if (jumpBuf > 0f) doJump()
                    else {
                        runPhase += vx * dt * 0.06f
                        moveX(vx * dt)
                        if (ps == P_RUN && !supported()) {
                            ps = P_AIR; coyote = 0.1f; airT = 0f; canFlip = false; jumped = false; cut = true
                        }
                    }
                }
            }
            P_AIR -> {
                if (vaultT > 0f) vx = max(vx, vaultVx)
                if (vx < ts) vx += 160f * dt
                else if (vx > ts + 40f) vx -= (vx - ts) * 0.5f * dt
                vy = min(vy + G * dt * (if (boostFlyT > 0f) 0.45f else 1f), 720f)
                if (vy > 460f) {
                    fallT += dt
                    if (fallT > 0.25f && !longFallSaid && py > 195f) { longFallSaid = true; animEvent(EV_LONG_FALL) }
                } else if (vy < 300f) fallT = 0f
                if (!jumpHeld && jumped && !cut && vy < -150f) { vy *= 0.45f; cut = true }
                moveX(vx * dt)
                if (ps == P_AIR) { moveY(vy * dt); if (ps == P_AIR) unstick() }
                if (ps == P_AIR && jumpBuf > 0f && coyote > 0f) doJump()
            }
            P_SLIDE -> {
                slideT -= dt
                if (jumpBuf > 0f) {
                    doJump(); jumpStyle = 3
                    vx = min(vx * 1.05f, 400f)
                } else {
                    vx += (ts * 0.85f - vx) * min(1f, 2.2f * dt)
                    runPhase += vx * dt * 0.03f
                    slideDust -= dt
                    if (slideDust <= 0f) { slideDust = 0.08f; spawnDust() }
                    moveX(vx * dt)
                    if (ps == P_SLIDE) {
                        if (!supported()) {
                            ps = P_AIR; coyote = 0.1f; airT = 0f; canFlip = false; jumped = false; cut = true
                        } else if (slideT <= 0f || (!slideHeld && slideT < 0.45f)) ps = P_RUN
                    }
                }
            }
            P_WALL -> {
                if (jumpBuf > 0f) {
                    vy = -300f; vx = -70f; ps = P_AIR; wallCd = 0.3f; airT = 0f; kickT = 0.35f
                    jumped = false; cut = true; canFlip = false; jumpBuf = 0f
                    sfx(ToneGenerator.TONE_DTMF_3)
                    animEvent(EV_KICK)
                } else {
                    // zip held = fast wall run, otherwise a slower hand-over-hand climb
                    val fastWall = zipHeld
                    vy = if (fastWall) -170f else -70f
                    climbPhase += (if (fastWall) 9f else 6f) * dt
                    py += vy * dt
                    val wb = wallB
                    if (wb == null) { ps = P_AIR; airT = 0f }
                    else if (py <= wb.top) {
                        px = wb.x + HW + 1f; py = wb.top; vy = 0f; vx = ts * 0.7f
                        ps = P_RUN; landT = 0.12f
                        lastGroundB = wb; landKind = LK_SOFT
                        animEvent(EV_TOPOUT)
                    } else {
                        vx = 0f
                        moveX(40f * dt)
                        if (!wallHit && ps == P_WALL) { ps = P_AIR; airT = 0f; canFlip = false }
                    }
                }
            }
            P_SWING -> {
                if (blocked(px, py - 11f, ax, ay) || ax < camX - 40f) releaseSwing()
                else {
                    val oxp = px; val oyp = py - 11f
                    vy = min(vy + G * dt, 720f)
                    val sp0 = sqrt(vx * vx + vy * vy)
                    if (sp0 < 260f) vx += 55f * dt
                    val dg = 0.00025f * sp0 * dt
                    vx -= vx * dg; vy -= vy * dg
                    if (py - 11f > ay + 24f) ropeL = max(ropeMin, ropeL - 14f * dt)
                    moveX(vx * dt)
                    if (ps == P_SWING) {
                        moveY(vy * dt)
                        if (ps == P_SWING) {
                            val ddx = px - ax; val ddy = (py - 11f) - ay
                            val d = sqrt(ddx * ddx + ddy * ddy)
                            if (d > ropeL) {
                                val k = ropeL / d
                                px = ax + ddx * k; py = ay + ddy * k + 11f
                                vx = (px - oxp) / dt; vy = (py - 11f - oyp) / dt
                            }
                            val sp = sqrt(vx * vx + vy * vy)
                            if (sp > 430f) { vx *= 430f / sp; vy *= 430f / sp }
                            unstick()
                        }
                    }
                }
            }
            P_ZIP -> {
                zipT += dt
                val dxz = zTx - px; val dyz = zTy - py
                val d = sqrt(dxz * dxz + dyz * dyz)
                if (boostPreT > 0f) {
                    // anticipation: gather the stored zip momentum
                    boostPreT -= dt
                    vx *= 0.9f; vy *= 0.9f
                    px += vx * dt; py += vy * dt
                    if (boostPreT <= 0f) doBoost()
                } else if (jumpBuf > 0f && zipT > 0.06f && d > 14f) {
                    boostPreT = 0.09f; jumpBuf = 0f
                    val m = max(1f, sqrt(vx * vx + vy * vy))
                    boostDx = vx / m; boostDy = vy / m
                    sfx(ToneGenerator.TONE_DTMF_1)
                } else if (d < 10f) {
                    arriveCorner()
                } else {
                    val ramp = min(zipV0 + zipT * (if (zipCombo) 4200f else 3200f), if (zipCombo) 820f else 720f)
                    val sp = min(ramp, 150f + d * 9f)
                    val ndx = dxz / d; val ndy = dyz / d
                    if (zipT > 1.2f || (d > 24f && blocked(px, py - 11f, px + ndx * 14f, py - 11f + ndy * 14f))) {
                        ps = P_AIR; airT = 0f; canFlip = false; jumped = false; cut = true
                    } else {
                        vx = ndx * sp; vy = ndy * sp
                        px += vx * dt; py += vy * dt
                    }
                }
            }
            P_CORNER -> {
                cornerT -= dt
                vx = 0f; vy = 0f
                if (jumpBuf > 0f) {
                    // corner launch
                    vy = -JUMP_V * 1.12f; vx = max(ts * 1.3f, 260f)
                    ps = P_AIR; airT = 0f; jumped = true; cut = false; canFlip = true
                    pickStyle(true)
                    jumpBuf = 0f; boostT = 5f; shakeT = 0.1f; shakeMag = 1f
                    sfx(ToneGenerator.TONE_DTMF_5); spawnDust()
                    animEvent(EV_BIGJUMP)
                } else if (cornerT <= 0f) {
                    ps = P_RUN; vx = ts * 0.55f; zipCd = 0.3f
                }
            }
        }

        for (i in 0 until MAXP) if (plife[i] > 0f) {
            plife[i] -= dt; pxs[i] += pvx[i] * dt; pys[i] += pvy[i] * dt; pvy[i] += 300f * dt
        }
        if (px > prevX) dist += (px - prevX).toDouble()
        val m = meters()
        if (m / 500 > lastMile) { lastMile = m / 500; toast = "${lastMile * 500} M!"; toastT = 2f; if (m > best) best = m }
        syncAnim(dt)
        indicators(dt)
        ensureWorld(px + lw + 700f)
        cullWorld(min(camX, px) - 200f)
        if (px > 150000f) rebase(100000f)
        if (py > DEATH_Y) die()
    }

    private fun syncAnim(dt: Float) {
        val i = anim.input()
        i.mode = ps; i.vx = vx; i.vy = vy
        i.grounded = ps == P_RUN || ps == P_SLIDE || ps == P_CORNER
        i.airT = airT; i.jumped = jumped; i.startT = startT; i.landT = landT; i.shootT = shootT
        i.boostPreT = boostPreT; i.boostFlyT = boostFlyT; i.kickT = kickT; i.zipHeld = zipHeld
        i.ropeFrac = if (ps == P_SWING && ropeL > 1f) sqrt((px - ax) * (px - ax) + (py - 11f - ay) * (py - 11f - ay)) / ropeL else 0f
        i.zipDist = if (ps == P_ZIP) sqrt((zTx - px) * (zTx - px) + (zTy - py) * (zTy - py)) else 999f
        anim.update(dt)
    }

    private fun doJump() {
        vy = -JUMP_V; ps = P_AIR; jumpBuf = 0f; coyote = 0f; airT = 0f
        jumped = true; cut = false; canFlip = true
        jumpStyle = -1
        sfx(ToneGenerator.TONE_DTMF_5)
        spawnDust()
        animEvent(EV_JUMP)
    }

    private fun startSlide() {
        ps = P_SLIDE; slideT = 0.65f; slideCd = 0.45f; slideDust = 0f
        vx = min(max(vx, targetSpeed()) * 1.18f, 380f)
        spawnDust()
        sfx(ToneGenerator.TONE_DTMF_6)
    }

    private fun landed() {
        val impact = vy
        vy = 0f
        if (slideBuf > 0f && impact > 250f) {
            // dive lands straight into a slide
            ps = P_SLIDE; slideT = 0.55f; slideCd = 0.3f; slideBuf = 0f; slideDust = 0f
            vx = min(max(vx, targetSpeed()) * 1.25f, 400f)
            canFlip = false
            spawnDust()
            sfx(ToneGenerator.TONE_DTMF_0)
            return
        }
        if (ps != P_RUN) {
            val airTime = airT
            ps = P_RUN
            // Landing type depends on how hard and how fast we arrive:
            //  high fall + slow  -> superhero three-point pose
            //  high fall + fast  -> tuck and roll, keeps momentum
            //  fast approach     -> low rushing skid-lean
            //  anything else     -> soft crouch
            landKind = when {
                impact > 480f && vx >= 230f -> LK_ROLL
                impact > 480f -> LK_HERO
                vx > 300f && impact > 150f -> LK_RUSH
                else -> LK_SOFT
            }
            landT = when (landKind) {
                LK_HERO -> 0.5f
                LK_RUSH -> 0.2f
                else -> if (impact > 320f) 0.25f else 0.13f
            }
            if (landKind == LK_ROLL) rollT = 0.34f
            spawnDust()
            if (landKind == LK_HERO) spawnDust()
            sfx(ToneGenerator.TONE_DTMF_0)
            val nb = groundBuilding()
            val crossed = nb != null && lastGroundB != null && nb !== lastGroundB
            if (nb != null) lastGroundB = nb
            animEvent(EV_LAND, impact, airTime, crossed)
        }
        canFlip = false
    }

    private fun moveX(dx: Float) {
        var nx = px + dx
        wallHit = false
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW + abs(dx) + 4f) break
            if (b.x + b.w < px - HW - 4f) continue
            if (py > b.top + 2f) {
                if (dx > 0f && px + HW <= b.x + 0.5f && nx + HW > b.x) { nx = b.x - HW; wallHit = true; hitB = b }
                else if (dx < 0f && px - HW >= b.x + b.w - 0.5f && nx - HW < b.x + b.w) nx = b.x + b.w + HW
            }
        }
        px = nx
        if (wallHit && ps != P_WALL) {
            val vIn = vx
            if (ps == P_SWING) { ps = P_AIR; animEvent(EV_KICK) }
            vx = 0f
            if (ps == P_AIR) {
                // only latch on when you jump or swing into a wall
                val hb2 = hitB
                if (wallCd <= 0f && hb2 != null && vIn > 120f && py - hb2.top <= VAULT_MAX && py - hb2.top > 2f) {
                    startVault(hb2, vIn)            // clip a low roofline: pop over it, keep momentum
                } else if (wallCd <= 0f) {
                    ps = P_WALL; wallB = hitB; wallT = 0.7f; vy = -70f; jumped = false; canFlip = false; climbPhase = 0f
                    animEvent(EV_LATCH)
                }
            } else {
                val hb = hitB
                if (ps == P_RUN && hb != null && vIn > 60f && py - hb.top <= VAULT_MAX && py - hb.top > 2f) {
                    startVault(hb, vIn)
                } else {
                    if (ps == P_SLIDE) ps = P_RUN
                    if (!bumpHint) { bumpHint = true; toast = "JUMP INTO WALLS TO CLIMB"; toastT = 1.8f }
                }
            }
        }
    }

    // Low obstacle: a short, collision-safe hop. Real physics (impulse + gravity), not a teleport.
    private fun startVault(hb: Building, vIn: Float) {
        val h = py - hb.top
        vy = -sqrt(2f * G * (h + 9f)); vx = vIn; vaultVx = vIn
        ps = P_AIR; airT = 0f; coyote = 0f; jumped = false; cut = true; canFlip = false
        wallCd = 0.4f; vaultT = 0.3f
        spawnDust(); sfx(ToneGenerator.TONE_DTMF_4, 30)
        animEvent(EV_VAULT)
    }

    private fun moveY(dy: Float) {
        val pf = py
        py += dy
        if (dy >= 0f) {
            for (i in 0 until world.size) {
                val b = world[i]
                if (b.x > px + HW) break
                if (b.x + b.w < px - HW) continue
                if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && pf <= b.top + 0.01f && py >= b.top) {
                    py = b.top; landed(); return
                }
            }
        }
    }

    private fun supported(): Boolean {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && abs(py - b.top) < 2f) return true
        }
        return false
    }

    private fun unstick() {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (px + HW - 1f > b.x && px - HW + 1f < b.x + b.w && py > b.top + 2f) {
                if (py - b.top < 8f) { py = b.top; landed() }
                else { px = b.x - HW; if (vx > 0f) vx = 0f }
            }
        }
    }

    private fun blocked(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        for (s in 1..7) {
            val t = s / 8f
            val sx = x1 + (x2 - x1) * t; val sy = y1 + (y2 - y1) * t
            for (i in 0 until world.size) {
                val b = world[i]
                if (b.x > sx) break
                if (b.kind != BK_BUILDING) continue          // webs pass over low rooftop props
                if (sx <= b.x + b.w && sy > b.top) return true
            }
        }
        return false
    }

    // Web targets are the anchors only (cranes, towers, billboard / tank frames, scaffolds, beams, poles).
    // Prefers a comfortable rope length (~140 px) and targets ahead of the hero, so continuous swinging
    // picks the next useful anchor instead of the closest one.
    private fun findAnchor(): Boolean {
        var bs = 1e9f; var found = false
        val cy = py - 11f
        for (i in 0 until anchors.size) {
            val a = anchors[i]
            if (a.x < px + 8f || a.x > px + 600f) continue
            val dx = a.x - px; val dy = a.y - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d > 300f || d < 40f || a.y > py - 35f) continue
            val score = abs(d - 140f) - dx * 0.15f
            if (score >= bs) continue
            if (blocked(px, cy, a.x, a.y)) continue
            bs = score; cAx = a.x; cAy = a.y; found = true
        }
        return found
    }

    private fun trySwing() {
        if (ps == P_ZIP) return
        if (findAnchor()) {
            ax = cAx; ay = cAy
            val dx = ax - px; val dy = ay - (py - 11f)
            ropeL = sqrt(dx * dx + dy * dy)
            ropeMin = ropeL * 0.6f; webWob = 5f
            ps = P_SWING; shootT = 0.15f; jumped = false; canFlip = false
            sfx(ToneGenerator.TONE_DTMF_8)
            animEvent(EV_SWING)
        }
    }

    private fun releaseSwing() {
        val spr = sqrt(vx * vx + vy * vy)
        if (spr > 60f) { vx *= 1.05f; vy *= 1.05f; if (vy < 0f) vy -= 25f }
        webWob = 4f
        ps = P_AIR; airT = 0f; canFlip = true; jumped = false; cut = true
        anim.noteRelease()
        pickStyle(true)
        sfx(ToneGenerator.TONE_DTMF_2)
    }

    private fun findZip(range: Float = ZIP_RANGE): Boolean {
        var bd = 1e9f; var found = false
        val cy = py - 11f
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x - px > range) break
            if (b.kind != BK_BUILDING) continue              // zip corners are building corners, not props
            val tx = b.x + min(HW + 1f, b.w * 0.5f)
            if (tx < px + 30f) continue
            val dx = tx - px; val dy = (b.top - 6f) - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d > range || d < 30f || b.top < py - 150f) continue
            if (blocked(px, cy, tx, b.top - 8f)) continue
            if (d < bd) { bd = d; zTx = tx; zTy = b.top; found = true }
        }
        return found
    }

    private fun arriveCorner() {
        px = zTx; py = zTy
        vx = 0f; vy = 0f; jumpBuf = 0f
        ps = P_CORNER; cornerT = 0.38f; zipCd = 0.35f
        boostT = 5f
        shakeT = 0.12f; shakeMag = 1.5f
        spawnDust()
        sfx(ToneGenerator.TONE_DTMF_0)
        toast = "SPEED BOOST!"; toastT = 1f
        animEvent(EV_CORNER)
    }

    private fun doBoost() {
        var dx = boostDx; val dy = boostDy - 0.55f
        if (dx < 0.35f) dx = 0.35f
        val m = sqrt(dx * dx + dy * dy)
        vx = dx / m * 560f; vy = dy / m * 560f
        if (vy > -140f) vy = -140f
        ps = P_AIR; airT = 0f; canFlip = false; jumped = false; cut = true; jumpBuf = 0f
        boostFlyT = 0.55f; boostT = 5f; zipCd = 0.3f
        shakeT = 0.18f; shakeMag = 2.2f
        sfx(ToneGenerator.TONE_DTMF_7, 70)
        spawnDust()
        animEvent(EV_BOOST)
    }

    private fun tryZip(combo: Boolean = false) {
        if (findZip(if (combo) ZIP_RANGE * 1.3f else ZIP_RANGE)) {
            // sharp turn toward the target = "Whoa!"
            val sp0 = sqrt(vx * vx + vy * vy)
            val dzx = zTx - px; val dzy = zTy - py
            val dz0 = max(1f, sqrt(dzx * dzx + dzy * dzy))
            val turnCos = if (sp0 > 170f) (vx * dzx + vy * dzy) / (sp0 * dz0) else 1f
            animEvent(EV_ZIP, turnCos)
            zipV0 = max(sqrt(vx * vx + vy * vy), 280f); zipCombo = combo; boostPreT = 0f
            jumpBuf = 0f     // a stale buffered jump must not trigger an instant boost
            if (combo) { shakeT = 0.1f; shakeMag = 1.2f }
            ps = P_ZIP; zipT = 0f; shootT = 0.15f; zipCd = 0.5f; canFlip = false
            sfx(ToneGenerator.TONE_DTMF_9, 60)
        }
    }

    private fun indicators(dt: Float) {
        indT -= dt
        if (indT > 0f) return
        indT = 0.08f
        indZip = false; indSwing = false
        if (ps == P_AIR || ps == P_SWING) {
            if (zipCd <= 0f && findZip()) { indZip = true; iZx = zTx; iZy = zTy }
        }
        if (ps == P_AIR || ps == P_RUN) {
            if (findAnchor()) { indSwing = true; iAx = cAx; iAy = cAy }
        }
    }

    private fun spawnDust() {
        val n = if (gfx == 0) 2 else if (gfx == 1) 4 else 8
        var made = 0
        for (i in 0 until MAXP) {
            if (made >= n) break
            if (plife[i] <= 0f) {
                plife[i] = 0.35f; pxs[i] = px + (made - n / 2f); pys[i] = py - 1f
                pvx[i] = -30f + (made % 3) * 25f - vx * 0.15f; pvy[i] = -30f - (made % 2) * 25f
                made++
            }
        }
    }

    private fun rc(c: Canvas, x: Int, y: Int, w: Int, h: Int, col: Int) {
        p.color = col
        c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), p)
    }

    private fun rf(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int) {
        p.color = col
        c.drawRect(x, y, x + w, y + h, p)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, center: Boolean = false) {
        p.textSize = size
        p.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        p.color = INK; c.drawText(s, x + 1f, y + 1f, p)
        p.color = col; c.drawText(s, x, y, p)
    }

    private fun render() {
        val c = cv ?: return
        c.save()
        c.scale(WS, WS)
        val shk = if (shakeT > 0f) shakeMag * min(1f, shakeT / 0.1f) else 0f
        val cineOn = st == ST_PLAY || st == ST_PAUSE
        val ox = floor(camX + (if (cineOn) cam.offX.x else 0f)).toInt() + (sin(time * 97f) * shk).roundToInt()
        val oy = floor(camY + (if (cineOn) cam.offY.x else 0f)).toInt() + (cos(time * 83f) * shk).roundToInt()
        val zoomed = cineOn && cam.zoom > 1.001f
        if (zoomed) {
            // punch-in around the hero; zoom is always >= 1 so no world edge is ever exposed
            val zx = px - ox; val zy = py - 14f - oy
            c.save(); c.translate(zx, zy); c.scale(cam.zoom, cam.zoom); c.translate(-zx, -zy)
        }
        mood = moodVal()
        litMod = (9f - 5f * (mood - 0.5f).coerceIn(0f, 1f)).toInt()
        nightGlow = gfx >= 2 && mood > 1f
        drawBackground(c, ox, oy)
        drawWorld(c, ox, oy)
        val showPlayer = st == ST_PLAY || st == ST_PAUSE || st == ST_OVER || (st == ST_EDIT && editFrom != ST_MENU)
        if (showPlayer) drawPlayer(c, ox, oy)
        if (showPlayer && gfx >= 1) drawSpeedLines(c, ox, oy)
        drawParticles(c, ox, oy)
        if (showPlayer) drawWebs(c, ox, oy)
        if (zoomed) c.restore()
        if (gfx >= 2) drawForeground(c)
        drawAtmosphere(c)
        if (cineOn && cam.bars > 0f) {
            val bh = cam.bars * 6f
            rf(c, 0f, 0f, lw.toFloat(), bh, INK); rf(c, 0f, LH - bh, lw.toFloat(), bh, INK)
        }
        if (st == ST_PLAY && bubbleT > 0f) drawBubble(c, px - ox, py - oy)

        when (st) {
            ST_PLAY -> { drawHud(c); drawButtons(c) }
            ST_MENU -> drawMenu(c)
            ST_PAUSE -> { dim(c); text(c, "PAUSED", lw / 2f, 40f, 20f, WHITE, true); for (m in pauseItems) drawItem(c, m) }
            ST_OVER -> drawOver(c)
            ST_EDIT -> {
                drawButtons(c)
                text(c, "DRAG BUTTONS TO MOVE  -  TAP ONE, THEN SIZE", lw / 2f, 60f, 9f, WHITE, true)
                text(c, "SELECTED: " + arrayOf("JUMP", "WEB", "ZIP", "PAUSE", "SLIDE")[sel], lw / 2f, 76f, 9f, K(0xFFE27A), true)
                for (m in editItems) drawItem(c, m)
            }
        }
        if (diag) drawDiag(c)
        c.restore()
    }

    // comic-style caption for the current voice line (also shows if no TTS engine is installed)
    private fun drawBubble(c: Canvas, sx: Float, sy: Float) {
        p.textSize = 8f
        val w = p.measureText(bubbleText) + 8f
        val pop = min(1f, (1.4f - bubbleT) * 9f)            // quick pop-in
        var bx0 = sx - w / 2f
        bx0 = bx0.coerceIn(2f, lw - w - 2f)
        val by0 = sy - 62f - 4f * (1f - pop)
        rf(c, bx0 - 1f, by0 - 1f, w + 2f, 15f, INK)
        rf(c, bx0, by0, w, 13f, WHITE)
        rf(c, sx - 2f, by0 + 13f, 5f, 3f, INK)
        rf(c, sx - 1f, by0 + 13f, 3f, 2f, WHITE)
        text(c, bubbleText, bx0 + w / 2f, by0 + 10f, 8f, INK, true)
    }

    private fun dim(c: Canvas) {
        p.color = (0x99 shl 24) or 0x0B1626
        c.drawRect(0f, 0f, lw.toFloat(), LH.toFloat(), p)
    }

    private fun drawBackground(c: Canvas, ox: Int, oy: Int) {
        val bandH = LH / SKY.size + 1
        for (i in SKY.indices) rc(c, 0, i * LH / SKY.size, lw, bandH, SKY[i])

        if (mood > 1.2f) {                       // night: twinkling stars
            val sa = (min(1f, (mood - 1.2f) * 2f) * 210f).toInt()
            for (i in 0 until 28) {
                if (((time * 1.6f).toInt() + i) % 5 == 0) continue
                rc(c, hash(i * 13 + 5) % lw, hash(i * 29 + 7) % 92, 1, 1, argb(sa, 0xFFFFFF))
            }
        }
        if (gfx >= 2 && mood < 1.5f) {           // soft light shafts fanning from the sun
            val sx = lw * 0.80f
            for (k in 0 until 3) {
                shaft.rewind()
                shaft.moveTo(sx - 5f, 40f); shaft.lineTo(sx + 5f, 40f)
                shaft.lineTo(sx - 120f - k * 70f, LH.toFloat()); shaft.lineTo(sx - 190f - k * 70f, LH.toFloat())
                shaft.close()
                p.color = argb(0x12, 0xFFF3C8)
                c.drawPath(shaft, p)
            }
        }
        p.color = K(0xFFF3B0)
        c.drawCircle(lw * 0.80f, 38f, 11f, p)

        val n = if (gfx == 0) 3 else if (gfx == 1) 5 else 7
        val span = (lw + 200).toFloat()
        for (i in 0 until n) {
            var sx = ((i * 151 + 40) - camX * 0.05f - (if (gfx == 0) 0f else time * (2f + i))) % span
            if (sx < 0f) sx += span
            sx -= 100f
            val cy = 14f + ((i * 29) % 70) - camY * 0.02f
            val w = (38 + (i * 13) % 30).toFloat()
            rf(c, sx + 6f, cy, w - 12f, 8f, WHITE)
            rf(c, sx, cy + 4f, w, 8f, WHITE)
            rf(c, sx + w * 0.3f, cy - 4f, w * 0.35f, 8f, WHITE)
            rf(c, sx, cy + 10f, w, 2f, K(0xD3E6F4))
        }
        if (gfx >= 2) cityLayer(c, 0.06f, K(0xBFD9EC), 134f, 60, 140, 24, 5, false)
        cityLayer(c, 0.12f, K(0xA9CDE8), 150f, 40, 100, 28, 11, false)
        if (gfx >= 1) haze(c, 96)
        if (gfx >= 2) drawBirds(c)
        if (gfx >= 1) cityLayer(c, 0.25f, K(0x8DB6D8), 176f, 28, 80, 34, 77, gfx >= 2)
        if (gfx >= 2) { haze(c, 124); cityLayer(c, 0.42f, K(0x7098C2), 196f, 20, 60, 40, 303, true) }
    }

    // ---- mood / atmosphere (inspired by layered, tinted, vignetted side-scroller scenes) ----
    private var mood = 0f                       // 0 day, 1 dusk, 2 night; cycles with distance
    private val shaft = android.graphics.Path()
    private val vigP = Paint()
    private var vigLw = -1
    private var litMod = 9
    private var nightGlow = false

    private fun moodVal(): Float {
        val t = (meters() % 3000) / 3000f
        return when {
            t < 0.30f -> 0f
            t < 0.45f -> (t - 0.30f) / 0.15f
            t < 0.60f -> 1f + (t - 0.45f) / 0.15f
            t < 0.80f -> 2f
            else -> 2f - 2f * (t - 0.80f) / 0.20f
        }
    }

    private fun chLerp(a: Int, b: Int, sh: Int, k: Float): Int {
        val x = (a ushr sh) and 255; val y = (b ushr sh) and 255
        return (x + (y - x) * k).toInt().coerceIn(0, 255)
    }
    private fun lerpArgb(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return (chLerp(a, b, 24, k) shl 24) or (chLerp(a, b, 16, k) shl 16) or (chLerp(a, b, 8, k) shl 8) or chLerp(a, b, 0, k)
    }

    // three stacked translucent bands, so distant layers fade toward the horizon in pixel-friendly steps
    private fun haze(c: Canvas, y0: Int) {
        val col = argb(0x1C, 0xE6F2FA)
        for (i in 0..2) { val yy = y0 + i * 26; if (yy < LH) rc(c, 0, yy, lw, LH - yy, col) }
    }

    // dark overhead gantries in front of the action (parallax > 1) frame the scene and add depth
    private fun drawForeground(c: Canvas) {
        val S = 240
        val span = S * 3
        val fg = argb(0x7A, 0x14172B)
        val glow = if (mood > 1f) min(1f, mood - 1f) else 0f
        for (k in 0 until 3) {
            val x = ((((k * S) - camX * 1.4f) % span) + span) % span - S
            val xi = x.toInt()
            if (xi < -S || xi > lw + S) continue
            rc(c, xi, 0, 3, 34, fg)
            rc(c, xi - 6, 6, 15, 2, fg)
            rc(c, xi - 6, 8, 1, 5, fg)
            rc(c, xi - 8, 13, 5, 6, fg)
            if (glow > 0f) rc(c, xi - 7, 15, 3, 3, argb((glow * 200f).toInt(), 0xFFD27A))
            var xx = xi + 3
            while (xx < xi + S) {
                val u = (xx - xi - S / 2f) / (S / 2f)
                rc(c, xx, 7 + (10f * (1f - u * u)).toInt(), 4, 1, fg)
                xx += 4
            }
        }
    }

    // colour grade by time of day + soft vignette
    private fun drawAtmosphere(c: Canvas) {
        if (gfx < 1) return
        val col = if (mood <= 1f) lerpArgb(0x00FFB07A, 0x2EFF8A4A, mood) else lerpArgb(0x2EFF8A4A, 0x5C101C48, mood - 1f)
        if ((col ushr 24) > 0) rf(c, 0f, 0f, lw.toFloat(), LH.toFloat(), col)
        if (vigLw != lw) {
            vigP.shader = android.graphics.RadialGradient(
                lw / 2f, LH * 0.55f, lw * 0.62f,
                intArrayOf(0x00101828, 0x00101828, 0x66101828), floatArrayOf(0f, 0.55f, 1f),
                android.graphics.Shader.TileMode.CLAMP)
            vigLw = lw
        }
        c.drawRect(0f, 0f, lw.toFloat(), LH.toFloat(), vigP)
    }

    private fun bgBox(c: Canvas, x: Int, top: Int, w: Int, col: Int, hi: Int) {
        rc(c, x, top, w, LH - top, col); rc(c, x, top, w, 1, hi)
    }

    // One parallax layer of the distant city: varied slabs, stepped towers, pitched-roof apartments, unfinished
    // buildings with cranes, slender antenna towers. Purely decorative (never a web target); everything is derived
    // from the column index, so it needs no memory and no per-frame allocation.
    private fun cityLayer(c: Canvas, par: Float, col: Int, base0: Float, minH: Int, maxH: Int, cell: Int, seed: Int, windows: Boolean) {
        val hi = shade(col, 1.12f)
        val off = camX * par
        val base = (base0 - (camY - 20f) * par * 0.8f).toInt()
        val first = floor(off / cell).toInt() - 1
        val n = lw / cell + 3
        val win = if (mood > 1f) K(0xF2D98B) else shade(col, 1.22f)
        for (k in 0..n) {
            val idx = first + k
            val h0 = hash(idx * 7 + seed)
            val bw = cell * (60 + (h0 shr 3) % 90) / 100
            val bx = (idx * cell - off).toInt() + (h0 shr 6) % (cell / 2 + 1)
            val hh = minH + (h0 shr 9) % max(1, maxH - minH)
            val top = base - hh
            if (top > LH || bx > lw || bx + bw < 0) continue
            when ((h0 shr 14) % 10) {
                0, 1 -> {                                   // office slab + roof plant
                    bgBox(c, bx, top, bw, col, hi)
                    if (((h0 shr 20) and 1) == 0) rc(c, bx + bw / 3, top - 3, 6, 3, col) else { rc(c, bx + bw / 2 - 3, top - 6, 7, 4, col); rc(c, bx + bw / 2 - 2, top - 2, 1, 2, col); rc(c, bx + bw / 2 + 2, top - 2, 1, 2, col) }
                }
                2, 3 -> {                                   // stepped tower with spire
                    bgBox(c, bx, top + hh / 4, bw, col, hi)
                    bgBox(c, bx + bw / 5, top, bw * 3 / 5, col, hi)
                    rc(c, bx + bw / 2, top - 10, 1, 10, col)
                }
                4 -> {                                      // apartment block, pitched roof
                    bgBox(c, bx, top, bw, col, hi)
                    var r = 0
                    while (r < 5 && bw - r * 4 - 2 > 2) { rc(c, bx + r * 2 + 1, top - r - 1, bw - r * 4 - 2, 1, col); r++ }
                }
                5 -> {                                      // unfinished building + tower crane
                    bgBox(c, bx, top + 10, bw, col, hi)
                    var cx = bx
                    while (cx < bx + bw) { rc(c, cx, top - 6, 1, 16, col); cx += 6 }
                    rc(c, bx, top - 6, bw, 1, col)
                    val mx = bx + bw - 5
                    rc(c, mx, top - 36, 2, 42, col); rc(c, mx - 30, top - 36, 40, 1, col); rc(c, mx - 26, top - 35, 1, 12, col)
                    rc(c, mx + 6, top - 36, 5, 4, col)
                }
                6 -> {                                      // slender comm tower
                    bgBox(c, bx + bw / 3, top, max(4, bw / 3), col, hi)
                    rc(c, bx + bw / 2, top - 20, 1, 20, col); rc(c, bx + bw / 2 - 2, top - 12, 5, 1, col)
                }
                else -> {                                   // office with crown notch
                    bgBox(c, bx, top, bw, col, hi)
                    rc(c, bx + bw / 4, top - 4, bw / 2, 4, col)
                    if (((h0 shr 21) and 3) == 0) { rc(c, bx + bw / 2, top - 14, 1, 10, col) }
                }
            }
            if (windows) {
                var wy = max(top + 4, 2)
                var row = 0
                while (wy < LH && wy < base) {
                    val bits = hash(idx * 31 + (wy - top) * 17 + seed)
                    var cc = 0; var wx = bx + 2
                    while (wx < bx + bw - 2 && cc < 15) { if (((bits shr (cc * 2)) and 3) == 0) rc(c, wx, wy, 1, 2, win); wx += 4; cc++ }
                    wy += 5; row++
                }
            }
        }
    }

    private fun drawBirds(c: Canvas) {
        for (i in 0 until 3) {
            val sx = ((time * 26f + i * 170f) % (lw + 60f)) - 30f
            val sy = 40f + i * 20f + sin(time * 2f + i) * 4f
            val up = ((time * 6f + i).toInt() and 1) == 0
            p.color = INK
            if (up) { c.drawRect(sx, sy, sx + 2f, sy + 1f, p); c.drawRect(sx + 3f, sy - 1f, sx + 5f, sy, p) }
            else { c.drawRect(sx, sy - 1f, sx + 2f, sy, p); c.drawRect(sx + 3f, sy, sx + 5f, sy + 1f, p) }
        }
    }

    private fun drawWorld(c: Canvas, ox: Int, oy: Int) {
        val sy = floor(STREET_Y).toInt() - oy
        if (sy < LH) { rc(c, 0, sy, lw, LH - sy + 2, K(0x6B6B72)); rc(c, 0, sy, lw, 2, K(0x8A8A92)) }
        visB = 0
        for (i in 0 until world.size) {
            val b = world[i]
            val sx = floor(b.x).toInt() - ox
            if (sx > lw + 20) break
            if (sx + b.w < -20f || b.top - oy > LH) continue
            visB++
            if (b.kind == BK_PROP) drawProp(c, b, ox, oy) else drawBuilding(c, b, ox, oy)
        }

        for (i in 0 until anchors.size) drawAnchor(c, anchors[i], ox, oy)

        if (st == ST_PLAY) {
            if (indSwing) {
                val sx = floor(iAx).toInt() - ox; val sy2 = floor(iAy).toInt() - oy
                rc(c, sx - 6, sy2 - 4, 13, 1, WHITE); rc(c, sx - 6, sy2 + 14, 13, 1, WHITE)
            }
            if (indZip) {
                val sx = floor(iZx).toInt() - ox; val sy2 = floor(iZy).toInt() - oy
                val pu = (time * 6f).toInt() % 2
                rc(c, sx - 7, sy2, 6, 1, WHITE); rc(c, sx - 7, sy2, 1, 6, WHITE)
                rc(c, sx - 3, sy2 - 12 - pu, 7, 1, WHITE); rc(c, sx, sy2 - 12 - pu, 1, 4, WHITE)
            }
        }
    }

    private fun shade(col: Int, f: Float): Int {
        val r = (((col shr 16) and 255) * f).toInt().coerceIn(0, 255)
        val g = (((col shr 8) and 255) * f).toInt().coerceIn(0, 255)
        val bl = ((col and 255) * f).toInt().coerceIn(0, 255)
        return K((r shl 16) or (g shl 8) or bl)
    }

    private val WIN_HI = K(0x5D7A96)
    private val GLASS_HI = K(0xE3F5FB)
    private val GLASS_MID = K(0xA3CFE2)
    private val CHIM = K(0x3A3A40)
    private val CRANE_Y = K(0xE8B52E)
    private val CRANE_D = K(0xB98A12)
    private val RUSTC = K(0x8C4B2F)
    private val CONC = K(0x9A9A9E)

    // Tiling material textures. One BitmapShader per material, so a whole wall is a single draw call.
    private var brickShader: android.graphics.BitmapShader? = null
    private var concShader: android.graphics.BitmapShader? = null
    private val texP = Paint()
    private val texM = android.graphics.Matrix()
    private val OUTLINE = K(0x2A2B45)      // selective outline: deep blue-violet, never pure black

    private fun argb(a: Int, rgb: Int): Int = (a shl 24) or (rgb and 0xFFFFFF)

    private fun tileShader(w: Int, h: Int, px: IntArray): android.graphics.BitmapShader {
        val bm = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        return android.graphics.BitmapShader(bm, android.graphics.Shader.TileMode.REPEAT, android.graphics.Shader.TileMode.REPEAT)
    }

    private fun buildTextures() {
        // running-bond brick, 16x8: cool translucent mortar, warm highlight on each brick's top-left
        val bw = 16; val bh = 8
        val b = IntArray(bw * bh)
        val mortar = argb(0x40, 0x2A1A33); val hi = argb(0x34, 0xFFD9A0)
        for (x in 0 until bw) { b[x] = mortar; b[4 * bw + x] = mortar }
        for (y in 1..3) { b[y * bw] = mortar; b[y * bw + 8] = mortar }
        for (y in 5..7) { b[y * bw + 4] = mortar; b[y * bw + 12] = mortar }
        for (x in 1..3) { b[bw + x] = hi; b[bw + 8 + x] = hi }
        for (x in 5..7) { b[5 * bw + x] = hi; b[5 * bw + 8 + x] = hi }
        brickShader = tileShader(bw, bh, b)
        // poured concrete, 16x18: one panel joint per bay plus a few sparse speckles (single dither style)
        val cw = 16; val ch = 18
        val c = IntArray(cw * ch)
        val joint = argb(0x30, 0x2A2B45); val spk = argb(0x28, 0xFFFFFF); val spd = argb(0x28, 0x2A2B45)
        for (y in 0 until ch) c[y * cw] = joint
        c[2 * cw + 5] = spk; c[6 * cw + 12] = spd; c[11 * cw + 7] = spk; c[14 * cw + 13] = spd; c[9 * cw + 3] = spd
        concShader = tileShader(cw, ch, c)
    }

    // Buildings are laid out on a strict grid: windows are centred in evenly spaced bays,
    // rows share one pitch, and every style has the same cornice so rooflines read cleanly.
    private fun drawBuilding(c: Canvas, b: Building, ox: Int, oy: Int) {
        val x = floor(b.x).toInt() - ox
        val w = ceil(b.w).toInt()
        val y = floor(b.top).toInt() - oy
        val s = b.style
        val bot = LH + 2
        val top = max(y, -2)
        val body = BASE[s]; val dark = DARK[s]; val light = LIGHT[s]
        val soft = shade(body, 0.9f)

        rc(c, x, top, w, bot - top, body)
        rc(c, x, top, 2, bot - top, dark)                 // shaded left edge
        rc(c, x + w - 1, top, 1, bot - top, light)        // lit right edge
        rc(c, x - 1, y, w + 2, 1, CREAM)                  // cornice: highlight, band, shadow line
        rc(c, x - 1, y + 1, w + 2, 2, light)
        rc(c, x, y + 3, w, 1, dark)
        if (gfx >= 1) {
            rc(c, x + 2, y + 4, w - 3, 2, soft)
            // selective outline: silhouette edges against the sky
            rc(c, x - 1, y - 1, w + 2, 1, OUTLINE); rc(c, x - 1, top, 1, bot - top, OUTLINE); rc(c, x + w, top, 1, bot - top, OUTLINE)
        }
        if (gfx >= 2) {   // checkerboard dither softens the cornice shadow into the wall
            var dx = x + 2
            while (dx < x + w - 1) { rc(c, dx, y + 6, 1, 1, soft); dx += 2 }
        }

        val pitch = if (s == 2) 8 else 16
        val n = max(1, (w - 8) / pitch)
        val x0 = x + (w - n * pitch) / 2
        val ww = when (s) { 0 -> 9; 1 -> 11; else -> 7 }
        val wh = when (s) { 0 -> 11; 1 -> 8; else -> 9 }
        val rowH = when (s) { 0 -> 20; 1 -> 18; else -> 10 }
        val firstY = if (s == 2) y + 9 else y + 12
        val inset = (pitch - ww) / 2

        if (gfx >= 2 && s != 2) {
            if (brickShader == null) buildTextures()
            texP.shader = if (s == 0) brickShader else concShader
            texM.setTranslate(if (s == 0) x.toFloat() else x0.toFloat(), if (s == 0) (y + 6).toFloat() else firstY.toFloat())
            texP.shader.setLocalMatrix(texM)
            c.drawRect((x + 2).toFloat(), (y + 7).toFloat(), (x + w - 1).toFloat(), bot.toFloat(), texP)
        }
        if (s == 2) rc(c, x0 - 1, firstY - 1, n * pitch + 1, bot - (firstY - 1), dark)   // curtain-wall mullions

        var row = 0
        var wy = firstY
        if (firstY < -rowH) { val skip = (-firstY) / rowH; wy += skip * rowH; row += skip }   // tall walls: start at the first visible floor
        while (wy < LH) {
            if (wy + wh > 0 && !(gfx == 0 && row >= 3)) {
                for (col in 0 until n) {
                    val wx = x0 + col * pitch + inset
                    if (wx + ww < 0 || wx > lw) continue
                    val hh = hash(b.seed + row * 31 + col * 7)
                    when (s) {
                        0 -> {
                            val lit = hh % litMod == 0
                            if (lit && nightGlow) rc(c, wx - 2, wy - 2, ww + 4, wh + 4, argb(0x28, 0xF2D98B))
                            rc(c, wx, wy, ww, wh, dark)
                            rc(c, wx + 1, wy + 1, ww - 2, wh - 2, if (lit) WIN_LIT else WIN_DARK)
                            rc(c, wx + ww / 2, wy + 1, 1, wh - 2, dark)
                            rc(c, wx + 1, wy + wh / 2, ww - 2, 1, dark)
                            if (gfx >= 2 && !lit) rc(c, wx + 1, wy + 1, 2, 1, WIN_HI)
                            if (gfx >= 1) {
                                rc(c, wx - 1, wy - 1, ww + 2, 1, light)
                                rc(c, wx - 1, wy + wh, ww + 2, 1, CREAM)
                                rc(c, wx - 1, wy + wh + 1, ww + 2, 1, dark)
                            }
                        }
                        1 -> {
                            val lit = hh % litMod == 0
                            if (lit && nightGlow) rc(c, wx - 2, wy - 2, ww + 4, wh + 4, argb(0x28, 0xF2D98B))
                            rc(c, wx, wy, ww, wh, dark)
                            rc(c, wx + 1, wy + 1, ww - 2, wh - 2, if (lit) WIN_LIT else WIN_DARK)
                            rc(c, wx + ww / 2, wy + 1, 1, wh - 2, dark)
                            if (gfx >= 2 && !lit) rc(c, wx + 1, wy + 1, 2, 1, WIN_HI)
                            if (gfx >= 1) rc(c, wx - 1, wy + wh, ww + 2, 1, light)
                        }
                        else -> {
                            val dg = ((col - row) % 6 + 6) % 6
                            val color = if (dg == 0) GLASS_HI else if ((row and 1) == 0) WIN_GLASS else GLASS_MID
                            rc(c, wx, wy, 7, 9, color)
                        }
                    }
                }
                if (s != 2 && gfx >= 1) rc(c, x + 2, wy + rowH - 3, w - 3, 1, dark)   // floor band
            }
            wy += rowH; row++
        }
        if (gfx >= 2 && s == 0 && n >= 3) drawFireEscape(c, x0 + (n - 1) * pitch + inset - 3, firstY + wh, ww + 6, rowH)
        if (b.deco == 1 && gfx >= 1) {   // building under construction: safety netting on the top floors
            rc(c, x + 2, y + 6, w - 3, 12, argb(0x66, 0xE8913A)); rc(c, x + 2, y + 6, w - 3, 1, argb(0xB0, 0xE8913A))
        }
        if (gfx >= 1) drawDecor(c, b, x, y)
    }

    // Fire escape: decks line up with window sills, one clean stair run per floor.
    private fun drawFireEscape(c: Canvas, x: Int, y0: Int, wd: Int, pitchY: Int) {
        var y = y0
        val steps = pitchY / 2
        while (y < LH) {
            rc(c, x, y, wd, 2, INK)
            rc(c, x, y - 6, 1, 6, INK); rc(c, x + wd - 1, y - 6, 1, 6, INK)
            rc(c, x, y - 6, wd, 1, INK)
            for (k in 0 until steps) rc(c, x + 2 + k * (wd - 8) / steps, y + 2 + k * 2, 3, 1, INK)
            y += pitchY
        }
    }

    // Draw-only roof clutter: no collision, no web target.
    private fun drawDecor(c: Canvas, b: Building, x: Int, y: Int) {
        for (i in 0 until b.decor.size) {
            val d = b.decor[i]
            val dx0 = x + d.dx.toInt()
            val dw = d.w.toInt(); val h = d.h.toInt()
            if (dx0 > lw + 4 || dx0 + dw < -4) continue
            when (d.type) {
                DC_ANT -> {
                    rc(c, dx0 + 1, y - 2, 5, 2, GRAYD)
                    rc(c, dx0 + 3, y - h, 1, h - 2, STEEL); rc(c, dx0, y - h + 4, 7, 1, STEEL); rc(c, dx0 + 1, y - h + 10, 5, 1, STEEL)
                    if (((time * 1.5f).toInt() and 1) == 0) rc(c, dx0 + 2, y - h - 2, 3, 2, RED)
                }
                DC_DISH -> {
                    rc(c, dx0 + 5, y - 6, 2, 6, STEEL)
                    rc(c, dx0 + 1, y - h, 10, 3, GRAYL); rc(c, dx0 + 3, y - h + 3, 6, 2, GRAYL); rc(c, dx0 + 1, y - h, 10, 1, WHITE)
                    rc(c, dx0 + 6, y - h - 3, 1, 4, GRAYD)
                }
                DC_PIPE -> {
                    rc(c, dx0, y - 4, dw, 3, GRAYD); rc(c, dx0, y - 4, dw, 1, GRAYL)
                    var k = 3; while (k < dw - 2) { rc(c, dx0 + k, y - 1, 2, 1, STEEL); k += 12 }
                }
                DC_CHIM -> {
                    rc(c, dx0, y - h, 7, h, DARK[0]); rc(c, dx0, y - h, 2, h, shade(DARK[0], 0.8f))
                    rc(c, dx0, y - h + 4, 7, 1, BRICKLINE); rc(c, dx0, y - h + 9, 7, 1, BRICKLINE)
                    rc(c, dx0 - 1, y - h - 3, 9, 3, CHIM); rc(c, dx0 - 1, y - h - 3, 9, 1, STEEL)
                }
                DC_PLANT -> if (gfx >= 2) {
                    rc(c, dx0, y - 5, 26, 5, WOOD_D); rc(c, dx0, y - 5, 26, 1, WOOD)
                    rc(c, dx0 + 1, y - 10, 8, 5, GREEN); rc(c, dx0 + 10, y - 13, 9, 8, GREEN_D); rc(c, dx0 + 19, y - 9, 6, 4, GREEN)
                }
                DC_RAIL -> {
                    for (k in 0..4) rc(c, dx0 + k * 8, y - 7, 1, 7, STEEL)
                    rc(c, dx0, y - 7, 33, 1, STEEL); rc(c, dx0, y - 3, 33, 1, GRAYD)
                }
                DC_SOLAR -> {
                    var k = 0
                    while (k + 10 <= dw) {
                        rc(c, dx0 + k, y - 6, 10, 4, BLUE); rc(c, dx0 + k, y - 6, 10, 1, LIGHTB); rc(c, dx0 + k + 5, y - 6, 1, 4, WIN_DARK)
                        rc(c, dx0 + k + 2, y - 2, 1, 2, STEEL); rc(c, dx0 + k + 7, y - 2, 1, 2, STEEL)
                        k += 11
                    }
                }
                DC_STACK -> {
                    rc(c, dx0 + 2, y - h, 3, h, STEEL); rc(c, dx0 + 1, y - h - 1, 5, 1, GRAYD); rc(c, dx0 + 1, y - 2, 5, 2, GRAYD)
                    if (gfx >= 2) rc(c, dx0 + 3, y - h - 4 - ((time * 8f).toInt() % 4), 2, 2, argb(0x66, 0xFFFFFF))
                }
                DC_COLS -> {
                    val hh = hash(b.seed + i * 5)
                    var k = 0
                    while (k < dw - 1) {
                        val ch = h - (hh shr k) % 5
                        rc(c, dx0 + k, y - ch, 2, ch, CONC); rc(c, dx0 + k, y - ch - 3, 1, 3, RUSTC)
                        k += 8
                    }
                    rc(c, dx0, y - h * 2 / 3, dw, 1, WOOD)
                }
                else -> {   // pallet of bags
                    rc(c, dx0, y - 3, 18, 3, WOOD); rc(c, dx0 + 1, y - 8, 8, 5, GRAYL); rc(c, dx0 + 9, y - 7, 7, 4, GRAYD)
                }
            }
        }
    }

    // Solid rooftop prop (same rectangle the physics uses).
    private fun drawProp(c: Canvas, b: Building, ox: Int, oy: Int) {
        val x = floor(b.x).toInt() - ox
        val y = floor(b.top).toInt() - oy
        val w = ceil(b.w).toInt()
        val h = b.h.toInt()
        if (y > LH || y + h < 0) return
        val s = b.style
        when (b.ptype) {
            PT_AC -> {
                rc(c, x, y, w, h, GRAYL); rc(c, x, y, w, 1, WHITE); rc(c, x + w - 2, y + 1, 2, h - 1, GRAYD)
                var ly = y + 3; while (ly < y + h - 2) { rc(c, x + 2, ly, w - 6, 1, GRAYD); ly += 2 }
                rc(c, x, y + h - 1, w, 1, GRAYD)
            }
            PT_VENT -> {
                rc(c, x, y + 2, w, h - 2, GRAYD); rc(c, x - 1, y, w + 2, 2, STEEL); rc(c, x + 1, y + 3, w - 2, 1, GRAYL)
                rc(c, x + w / 2 - 1, y + 5, 2, max(1, h - 6), STEEL)
            }
            PT_BOX -> {
                rc(c, x, y, w, h, K(0x6E8B74)); rc(c, x, y, w, 1, K(0x9FB8A4)); rc(c, x + w - 1, y, 1, h, K(0x4B6350))
                rc(c, x + 1, y + 2, w - 2, 1, K(0xE8C23A)); rc(c, x + w / 2, y + 4, 1, max(1, h - 5), K(0x4B6350))
            }
            PT_ROOM -> {
                rc(c, x, y + 2, w, h - 2, shade(BASE[s], 1.05f)); rc(c, x - 1, y, w + 2, 2, GRAYD); rc(c, x - 1, y, w + 2, 1, GRAYL)
                rc(c, x, y + 2, 2, h - 2, DARK[s]); rc(c, x + w - 1, y + 2, 1, h - 2, LIGHT[s])
                val dxx = x + w / 2 - 3
                rc(c, dxx, y + h - 14, 7, 14, WIN_DARK); rc(c, dxx + 3, y + h - 14, 1, 14, DARK[s]); rc(c, dxx + 5, y + h - 8, 1, 2, WIN_LIT)
                rc(c, dxx + 1, y + h - 17, 5, 2, WIN_LIT)
                if (w >= 44) { rc(c, x + 5, y + 8, 6, 5, WIN_DARK); rc(c, x + 6, y + 9, 4, 3, WIN_GLASS) }
            }
            PT_BARRIER -> {
                rc(c, x, y, w, h, GRAYL); rc(c, x, y, w, 2, CREAM); rc(c, x, y + h - 1, w, 1, GRAYD)
                var k = 0; while (k + 3 < w) { rc(c, x + k, y + 4, 3, 2, if ((k / 6) % 2 == 0) RED else WHITE); k += 3 }
            }
            PT_PLATFORM -> {
                rc(c, x + 3, y + 2, w - 6, h - 2, K(0x2F3640))
                rc(c, x + 1, y + 2, 2, h - 2, GRAYD); rc(c, x + w - 3, y + 2, 2, h - 2, GRAYD)
                var k = 0; while (k < h - 2 && k < w - 8) { rc(c, x + 3 + k, y + 2 + k, 1, 1, GRAYD); rc(c, x + w - 4 - k, y + 2 + k, 1, 1, GRAYD); k++ }
                rc(c, x, y, w, 2, STEEL); rc(c, x, y, w, 1, GRAYL)
                rc(c, x + 1, y - 5, 1, 5, STEEL); rc(c, x + w - 2, y - 5, 1, 5, STEEL); rc(c, x + 1, y - 5, w - 2, 1, STEEL)
            }
            PT_TANK -> {
                rc(c, x + 2, y + h - 5, 2, 5, STEEL); rc(c, x + w - 4, y + h - 5, 2, 5, STEEL)
                rc(c, x, y + 4, w, h - 9, WOOD); rc(c, x, y + 4, 2, h - 9, WOOD_L); rc(c, x + w - 2, y + 4, 2, h - 9, WOOD_D)
                rc(c, x, y + 8, w, 1, WOOD_D); rc(c, x, y + h - 9, w, 1, WOOD_D)
                rc(c, x + 1, y + 2, w - 2, 2, WOOD_D); rc(c, x + 4, y, max(2, w - 8), 2, WOOD_D)
            }
            PT_CRATES -> {
                rc(c, x, y, w, h, WOOD); rc(c, x, y, w, 1, WOOD_L); rc(c, x, y + h - 1, w, 1, WOOD_D)
                rc(c, x, y, 1, h, WOOD_D); rc(c, x + w - 1, y, 1, h, WOOD_D)
                if (h >= 18) rc(c, x, y + h / 2, w, 1, WOOD_D)
                var k = 0; while (k < min(w, h) - 2) { rc(c, x + 1 + k, y + 1 + k, 1, 1, WOOD_D); k++ }
            }
            else -> {   // pipe stack / chiller
                var yy = y
                while (yy + 4 <= y + h) { rc(c, x, yy, w, 4, GRAYL); rc(c, x, yy, w, 1, WHITE); rc(c, x, yy + 3, w, 1, GRAYD); yy += 5 }
                rc(c, x + 3, y, 2, h, STEEL); rc(c, x + w - 5, y, 2, h, STEEL)
            }
        }
        if (gfx >= 1) rc(c, x - 1, y - 1, w + 2, 1, OUTLINE)
    }

    // Swing structures. The hook / tip / frame top is exactly the point the web attaches to (a.x, a.y).
    private fun drawAnchor(c: Canvas, a: Anchor, ox: Int, oy: Int) {
        val hx = floor(a.x).toInt() - ox
        val hy = floor(a.y).toInt() - oy
        val bx = floor(a.bx).toInt() - ox
        val by = floor(a.by).toInt() - oy
        if (min(hx, bx) > lw + 24 || max(hx, bx) < -24 || by < -24 || hy > LH + 24) return
        val dir = if (a.x >= a.bx) 1 else -1
        when (a.kind) {
            AK_CRANE -> {
                val jy = hy - 8
                if ((a.flags and 1) != 0) {
                    val yt = max(jy - 6, -8); val yb = min(by, LH + 8)
                    if (yb > yt) {
                        rc(c, bx - 2, yt, 1, yb - yt, CRANE_Y); rc(c, bx + 2, yt, 1, yb - yt, CRANE_Y)
                        var yy = by - 4
                        while (yy > yt) { if (yy < yb) rc(c, bx - 1, yy, 3, 1, CRANE_D); yy -= 6 }
                    }
                    val cj = bx - dir * 24
                    rc(c, min(bx, cj), jy - 1, abs(cj - bx), 2, CRANE_Y); rc(c, cj - 3, jy - 1, 7, 6, GRAYD)
                    rc(c, bx - 3, jy - 5, 6, 4, GRAYL); rc(c, bx - 2, jy - 4, 3, 2, WIN_GLASS)
                    val tipX = bx + dir * (a.len.toInt() + 10)
                    rc(c, min(bx, tipX), jy - 1, abs(tipX - bx) + 1, 3, CRANE_Y); rc(c, min(bx, tipX), jy + 1, abs(tipX - bx) + 1, 1, CRANE_D)
                    var xx = bx
                    while ((dir > 0 && xx < tipX) || (dir < 0 && xx > tipX)) { if (xx > -8 && xx < lw + 8) rc(c, xx, jy, 1, 2, CRANE_D); xx += dir * 6 }
                    p.color = GRAYD; p.strokeWidth = 1f
                    c.drawLine(bx + 0.5f, (jy - 12).toFloat(), (bx + dir * (a.len.toInt() / 2)).toFloat(), (jy - 1).toFloat(), p)
                    rc(c, bx, jy - 12, 1, 7, CRANE_D)
                }
                rc(c, hx - 2, jy + 2, 5, 2, GRAYD); rc(c, hx, jy + 4, 1, max(0, hy - jy - 4), INK); rc(c, hx - 1, hy - 1, 3, 3, K(0xD9423A))
            }
            AK_TOWER -> {
                val span = max(1, by - hy)
                rc(c, bx, hy, 1, span, STEEL); rc(c, bx - 5, by - 2, 11, 2, GRAYD)
                var yy = by
                while (yy > hy) {
                    val half = (4f - 3f * (by - yy).toFloat() / span).toInt()
                    if (yy > -6 && yy < LH + 6) { rc(c, bx - half, yy - 4, 1, 4, STEEL); rc(c, bx + half, yy - 4, 1, 4, STEEL); rc(c, bx - half, yy - 4, 2 * half + 1, 1, GRAYD) }
                    yy -= 5
                }
                rc(c, bx + 2, by - span * 6 / 10, 5, 4, GRAYL); rc(c, bx + 3, by - span * 6 / 10 - 2, 1, 2, GRAYD)
                if (((time * 1.5f).toInt() and 1) == 0) rc(c, hx - 1, hy - 2, 3, 2, RED)
            }
            AK_BOARD -> {
                val x0 = bx - 17
                rc(c, bx - 13, hy + 16, 2, max(0, by - hy - 16), STEEL); rc(c, bx + 11, hy + 16, 2, max(0, by - hy - 16), STEEL)
                rc(c, bx - 13, hy + 16 + (by - hy - 16) / 2, 26, 1, GRAYD)
                rc(c, x0, hy, 34, 17, STEEL); rc(c, x0 + 1, hy + 1, 32, 14, CREAM)
                val col = when (a.seed % 3) { 0 -> RED; 1 -> BLUE; else -> GREEN_D }
                rc(c, x0 + 1, hy + 1, 32, 3, col); rc(c, x0 + 4, hy + 7, 18, 2, col); rc(c, x0 + 4, hy + 11, 12, 1, GRAYD); rc(c, x0 + 25, hy + 6, 6, 7, col)
                rc(c, x0, hy + 17, 34, 1, GRAYD)
            }
            AK_TANK -> {
                val tx = bx - 10
                rc(c, tx + 1, hy + 18, 2, max(0, by - hy - 18), STEEL); rc(c, tx + 17, hy + 18, 2, max(0, by - hy - 18), STEEL)
                var yy = hy + 26; while (yy < by) { rc(c, tx + 1, yy, 18, 1, GRAYD); yy += 14 }
                rc(c, tx, hy + 4, 20, 14, WOOD); rc(c, tx, hy + 4, 2, 14, WOOD_L); rc(c, tx + 18, hy + 4, 2, 14, WOOD_D)
                rc(c, tx, hy + 8, 20, 1, WOOD_D); rc(c, tx, hy + 13, 20, 1, WOOD_D)
                rc(c, tx + 1, hy + 2, 18, 2, WOOD_D); rc(c, tx + 5, hy, 10, 2, WOOD_D)
            }
            AK_SCAFF -> {
                val sx0 = bx - 10; val sw = 21
                val sp = max(0, by - hy)
                if (gfx >= 2) rc(c, sx0 + 1, hy + 2, sw - 2, max(0, sp - 2), argb(0x30, 0x4E9A4A))
                rc(c, sx0, hy, 1, sp, STEEL); rc(c, sx0 + sw - 1, hy, 1, sp, STEEL); rc(c, bx, hy, 1, sp, GRAYD)
                p.color = GRAYD; p.strokeWidth = 1f
                var yy = by - 14
                while (yy > hy) {
                    rc(c, sx0 - 2, yy, sw + 4, 2, WOOD); rc(c, sx0 - 2, yy, sw + 4, 1, WOOD_L)
                    if (yy - 14 > hy && yy < LH + 14 && yy > -14) c.drawLine((sx0 + 1).toFloat(), (yy).toFloat(), (sx0 + sw - 1).toFloat(), (yy - 14).toFloat(), p)
                    yy -= 16
                }
                rc(c, sx0 - 3, hy, sw + 6, 2, STEEL); rc(c, sx0 - 3, hy, sw + 6, 1, GRAYL)
            }
            AK_BEAM -> {
                rc(c, bx - 1, hy, 3, max(0, by - hy), STEEL); rc(c, bx, hy, 1, max(0, by - hy), GRAYL)
                val x0 = min(bx, hx); val l = abs(hx - bx)
                rc(c, x0, hy - 2, l + 1, 3, STEEL); rc(c, x0, hy - 2, l + 1, 1, GRAYL)
                var k = 4; while (k < l) { rc(c, x0 + k, hy - 1, 1, 1, GRAYD); k += 6 }
                rc(c, hx - 1, hy + 1, 3, 3, K(0xD9423A))
            }
            else -> {   // AK_POLE
                val dp = if (hx >= bx) 1 else -1
                rc(c, min(bx, hx), hy - 1, abs(hx - bx) + 1, 2, STEEL)
                for (k in 0 until 8) rc(c, bx + dp * k, hy + 1 + k, 1, 1, GRAYD)
                val fx = if (dp > 0) hx - 5 else hx + 1
                rc(c, fx, hy + 1, 5, 4, RED); rc(c, fx, hy + 1, 5, 1, K(0xE8645A))
            }
        }
    }

    // Streaks trailing behind the hero during zips, boosts and fast falls. They start 16 px behind the
    // body, so they never cover the character or the target indicators.
    private fun drawSpeedLines(c: Canvas, ox: Int, oy: Int) {
        val sp = sqrt(vx * vx + vy * vy)
        val fastFall = ps == P_AIR && vy > 460f
        if (!(ps == P_ZIP || boostFlyT > 0f || fastFall) || sp < 200f) return
        val dx = -vx / sp; val dy = -vy / sp
        val sx = px - ox; val sy = py - 11f - oy
        val n = if (gfx >= 2) 5 else 3
        p.strokeWidth = 1f
        for (k in 0 until n) {
            val off = (k - n / 2) * 5f
            val x0 = sx + dx * (16f + k * 5f) - dy * off
            val y0 = sy + dy * (16f + k * 5f) + dx * off
            p.color = argb(0x90 - k * 0x18, 0xFFFFFF)
            c.drawLine(x0, y0, x0 + dx * 9f, y0 + dy * 9f, p)
        }
    }

    private fun drawParticles(c: Canvas, ox: Int, oy: Int) {
        var n = 0
        p.color = CREAM
        for (i in 0 until MAXP) if (plife[i] > 0f) {
            n++
            val sx = pxs[i] - ox; val sy = pys[i] - oy
            c.drawRect(sx, sy, sx + 2f, sy + 2f, p)
        }
        activeP = n

        val fast = st == ST_PLAY && (ps == P_ZIP || boostFlyT > 0f || vx > 200f)
        val cnt = if (gfx == 0) 0 else if (gfx == 1) 4 else 8
        if (fast && cnt > 0) {
            val sx0 = floor(px).toInt() - ox; val sy0 = floor(py).toInt() - oy
            val seed = (time * 30f).toInt()
            for (i in 0 until cnt) {
                val h = hash(seed * 13 + i)
                val yy = sy0 - 26 + h % 30
                val len = 14 + h % 18
                rc(c, sx0 - 14 - len - (h % 12), yy, len, 1, WHITE)
            }
        }
    }

    private val WEBS = K(0xB9C7D6)

    private fun strand(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, sag: Float, wob: Float, frac: Float) {
        val dx = x2 - x1; val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        if (len < 3f) return
        val nx = -dy / len; val ny = dx / len
        val n = (len / 4f).toInt().coerceIn(4, 60)
        var pax = x1; var pay = y1; var pbx = x1; var pby = y1
        p.strokeWidth = 0.7f
        for (i in 1..n) {
            val t = i / n.toFloat() * frac
            val par = 4f * t * (1f - t)
            val cx = x1 + dx * t
            val cy = y1 + dy * t + sag * par
            val wv = sin(t * 14f + time * 30f) * wob * par
            val tw = sin(i * 1.1f + time * 4f) * 0.7f
            val qax = cx + nx * (wv + tw); val qay = cy + ny * (wv + tw)
            val qbx = cx + nx * (wv - tw); val qby = cy + ny * (wv - tw)
            p.color = WHITE; c.drawLine(pax, pay, qax, qay, p)
            p.color = WEBS; c.drawLine(pbx, pby, qbx, qby, p)
            pax = qax; pay = qay; pbx = qbx; pby = qby
        }
    }

    private fun splat(c: Canvas, x: Float, y: Float) {
        p.strokeWidth = 0.6f; p.color = WHITE
        for (k in 0 until 6) {
            val a = k * 1.0472f
            c.drawLine(x, y, x + cos(a) * 5f, y + sin(a) * 5f, p)
        }
        for (r in 1..2) {
            val rr = r * 2.2f
            for (k in 0 until 6) {
                val a0 = k * 1.0472f; val a1 = a0 + 1.0472f
                c.drawLine(x + cos(a0) * rr, y + sin(a0) * rr, x + cos(a1) * rr, y + sin(a1) * rr, p)
            }
        }
    }

    private fun drawWebs(c: Canvas, ox: Int, oy: Int) {
        val hx = handSx; val hy = handSy
        val frac = if (shootT > 0f) ((0.15f - shootT) / 0.12f).coerceIn(0f, 1f) else 1f
        if (ps == P_SWING) {
            val tx = ax - ox; val ty = ay - oy
            val dx = tx - hx; val dy = ty - hy
            val d = sqrt(dx * dx + dy * dy)
            val slack = (ropeL - d - 12f).coerceAtLeast(0f)
            val sag = min(slack * 0.6f, 14f) + (1f - frac) * 6f
            strand(c, hx, hy, tx, ty, sag, webWob, frac)
            if (frac >= 1f) splat(c, tx, ty)
        } else if (ps == P_ZIP) {
            val tx = zTx - ox; val ty = zTy - 6f - oy
            strand(c, hx, hy, tx, ty, 0f, 0f, frac)
            if (frac >= 1f) splat(c, tx, ty)
        }
    }

    private fun limb(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int) {
        p.color = col; p.strokeWidth = 3f
        c.drawLine(x1, y1, x2, y2, p)
    }

    private fun drawFrame(c: Canvas, f: Int) {
        val sh = heroSheet ?: return
        val row = suit.coerceIn(0, 2)
        fSrc.set(f * FW, row * FW, f * FW + FW, row * FW + FW)
        fDst.set(-PVX, -PVY, FW - PVX, FW - PVY)
        c.drawBitmap(sh, fSrc, fDst, spriteP)
    }

    private fun runFrame(phase: Float): Int = ((phase * 1.4324f).toInt() % 9) + 1

    private var rotS = 0f
    private var jumpStyle = 0
    private var jumpCnt = 0
    // -1 normal jump; 0 front flip, 1 back flip, 2 corkscrew, 3 hero glide, 4 double flip, 5 leap
    private val JUMP_DUR = floatArrayOf(0.5f, 0.55f, 0.55f, 0.6f, 0.65f, 0.6f)

    // swing releases pick a trick; ground jumps stay a normal jump
    private fun pickStyle(swing: Boolean) {
        jumpCnt++
        jumpStyle = if (swing) chooseTrick() else -1
        if (jumpStyle >= 0 && !anim.trickPermitted[jumpStyle]) jumpStyle = -1
        if (jumpStyle >= 0) animEvent(EV_TRICK, jumpStyle.toFloat())
    }

    // distance to the wall of a taller building ahead (we are below its roofline), 999 if none
    private fun wallAhead(): Float {
        var best = 999f
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x + b.w < px) continue
            if (b.x > px + 90f) break
            if (b.x > px && py > b.top + 4f) best = min(best, b.x - px - HW)
        }
        return best
    }

    // distance down to the roof directly beneath us, 999 if none
    private fun roofBelow(): Float {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (b.top >= py - 1f) return b.top - py
        }
        return 999f
    }

    private fun groundBuilding(): Building? {
        for (i in 0 until world.size) {
            val b = world[i]
            if (b.x > px + HW) break
            if (b.x + b.w < px - HW) continue
            if (abs(py - b.top) < 3f) return b.parent ?: b   // standing on a prop counts as the same building
        }
        return null
    }

    // Pick a trick from direction, speed and the space around us; never the same one twice running.
    private fun chooseTrick(): Int {
        val sp = sqrt(vx * vx + vy * vy)
        val wd = wallAhead(); val rb = roofBelow()
        var t = when {
            wd < 70f || (vy > 60f && rb < 40f) -> 5                  // tight space: no big rotations
            vy < -120f && sp > 330f -> 4                             // rising fast: double flip
            vy < -120f -> if (jumpCnt % 2 == 0) 0 else 2             // rising: front flip / corkscrew
            vy > 100f -> if (rb > 80f) 1 else 3                      // falling with room: back flip
            sp > 340f -> 3                                           // fast and level: hero glide
            else -> intArrayOf(2, 0, 1)[jumpCnt % 3]
        }
        if (t == lastTrick && t != 5) t = intArrayOf(0, 2, 3, 1, 4)[(t + 1 + jumpCnt) % 5]
        if (t != 5 && (wd < 70f || (vy > 60f && rb < 40f))) t = 5
        lastTrick = t
        return t
    }

    // ------------------------------------------------------------------
    // Animation events: one place that ties pose springs, camera, voice
    // ------------------------------------------------------------------
    private val EV_JUMP = 0; private val EV_BIGJUMP = 1; private val EV_LAND = 2; private val EV_SWING = 3
    private val EV_TRICK = 4; private val EV_ZIP = 5; private val EV_CORNER = 6; private val EV_BOOST = 7
    private val EV_KICK = 8; private val EV_LATCH = 9; private val EV_TOPOUT = 10; private val EV_LONG_FALL = 11; private val EV_VAULT = 12

    private fun say(cue: Int) {
        if (!voiceOn || snd == 0) return
        val ln = voice.say(cue, time, VOICE_VOL[snd]) ?: return
        bubbleText = ln.text; bubbleT = 1.4f
    }

    // saved from a deep fall (swing / zip / wall grab)?
    private fun nearMissCheck() {
        if (airLowY > 226f) { say(Cue.CLOSE); cam.thump(0f, 3f); cam.zoomPulse(1.04f, 0.12f) }
        airLowY = 0f
    }

    private fun animEvent(ev: Int, a: Float = 0f, b: Float = 0f, flag: Boolean = false) {
        when (ev) {
            EV_JUMP -> {
                sqz.kick(-0.16f, 3.2f)             // crouch, then spring tall, then settle
                say(Cue.JUMP)
            }
            EV_BIGJUMP -> {
                sqz.kick(-0.22f, 4.5f)
                cam.zoomPulse(1.05f, 0.25f); cam.sway(4f, -3f)
                say(Cue.JUMP)
            }
            EV_LAND -> {
                val impact = a; val airTime = b
                anim.noteLanding(landKind, impact, vx)
                when (landKind) {
                    LK_HERO -> {
                        sqz.kick(-0.10f, -1.5f); rotSp.kick(0f, 40f)
                        cam.thump(0f, 6f); cam.zoomPulse(1.05f, 0.16f)
                        shakeT = max(shakeT, 0.14f); shakeMag = max(shakeMag, 1.6f)
                    }
                    LK_ROLL -> {
                        sqz.kick(-0.06f, -1f)
                        cam.thump(0f, 3f); cam.sway(5f, 0f)
                        shakeT = max(shakeT, 0.1f); shakeMag = max(shakeMag, 1f)
                    }
                    LK_RUSH -> {
                        sqz.kick(-0.10f, -1f); rotSp.kick(0f, 60f)
                        cam.sway(6f, 2f)
                    }
                    else -> sqz.kick(-0.06f - min(0.08f, impact * 0.0001f), -0.5f)
                }
                nearMissCheck()
                if (flag && airTime > 0.45f) say(Cue.ARRIVE)
                else if (landKind != LK_HERO && (airTime > 0.5f || landKind == LK_RUSH)) say(Cue.LAND)
            }
            EV_SWING -> {
                rotSp.kick(0f, -70f); sqz.kick(0.04f, 0.6f)   // web-shot flick
                cam.sway(5f, -2f)
                nearMissCheck()
                say(Cue.SWING)
            }
            EV_TRICK -> {
                val st0 = a.toInt()
                anim.noteTrick(st0, JUMP_DUR[st0])
                sqz.kick(0f, 1.8f)
                if (st0 == 4 || st0 == 2) { cam.zoomPulse(1.06f, JUMP_DUR[st0]); cam.emphasize(JUMP_DUR[st0]) }
                else if (st0 != 5) cam.zoomPulse(1.03f, JUMP_DUR[st0] * 0.7f)
            }
            EV_ZIP -> {
                cam.sway(7f, -2f); sqz.kick(0f, 1.2f)
                if (a < 0.25f) { rotSp.kick(0f, 140f); say(Cue.WHOA) }
                nearMissCheck()
            }
            EV_CORNER -> {
                sqz.kick(-0.25f, 2f)
                cam.thump(0f, 4f); cam.zoomPulse(1.04f, 0.12f)
                say(Cue.ARRIVE)
            }
            EV_BOOST -> {
                sqz.kick(0f, 3f)
                cam.zoomPulse(1.07f, 0.35f); cam.emphasize(0.5f); cam.sway(8f, -4f)
                say(Cue.BOOST)
            }
            EV_KICK -> {
                spawnDust()
                rotSp.kick(0f, -220f); sqz.kick(0f, 2.5f)
                cam.sway(-8f, 0f)
                say(Cue.WHOA)
            }
            EV_LATCH -> {
                sqz.kick(-0.12f, 0f); rotSp.kick(0f, 90f); cam.thump(-3f, 0f)
                nearMissCheck()
            }
            EV_TOPOUT -> {
                anim.noteEdgeClimb()
                sqz.kick(0.06f, 3f)
                cam.sway(5f, -3f)
                say(Cue.ARRIVE)
            }
            EV_VAULT -> {
                anim.noteVault()
                sqz.kick(-0.08f, 2f); cam.sway(4f, -2f)
            }
            EV_LONG_FALL -> {
                rotSp.kick(0f, 150f)               // flailing
                cam.zoomPulse(1.03f, 0.3f)
                say(Cue.LONG_FALL)
            }
        }
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var d = (b - a) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return a + d * t
    }

    private fun smooth(t: Float): Float = t * t * (3f - 2f * t)

    private fun drawPlayer(c: Canvas, ox: Int, oy: Int) {
        val sx = floor(px).toInt() - ox
        val sy = floor(py).toInt() - oy
        var frame = 0
        var rot = 0f
        var offX = 0f; var offY = 0f
        var hx = 22f; var hy = -11f
        var kx = 1f; var ky = 1f          // local squash / stretch (along body axes)
        var follow = 0.35f                // how fast the body turns toward its target angle
        var ghosts = 0
        when (ps) {
            P_RUN -> {
                if (startT > 0f || vx < 8f) frame = IDLE0 + ((time * 8.33f).toInt() % IDLE_N)
                else {
                    frame = runFrame(runPhase)
                    // lean into the run, more the faster we go
                    rot = (vx * 0.025f).coerceIn(0f, 11f)
                    if (landT > 0f) {
                        frame = 4
                        when (landKind) {
                            LK_HERO -> {
                                // superhero landing: deep crouch held for a beat, head low, then rise
                                val k = (landT / 0.5f).coerceIn(0f, 1f)
                                val h = if (k > 0.3f) 1f else k / 0.3f
                                kx = 1f + 0.22f * h; ky = 1f - 0.30f * h
                                rot = 14f * h
                            }
                            LK_RUSH -> {
                                // fast approach: stay low and driving forward
                                val k = (landT / 0.2f).coerceIn(0f, 1f)
                                kx = 1f + 0.10f * k; ky = 1f - 0.12f * k
                                rot += 12f * k
                            }
                            else -> {
                                // soft landing: crouch and absorb, then spring up
                                val k = (landT / 0.2f).coerceIn(0f, 1f)
                                kx = 1f + 0.16f * k; ky = 1f - 0.20f * k
                                rot += 6f * k
                            }
                        }
                    }
                }
                if (boostT > 1f && vx > 150f) ghosts = 1
                if (rollT > 0f) {
                    // hard landing: tuck and roll out of it
                    val f = 1f - (rollT / 0.34f).coerceIn(0f, 1f)
                    rot = smooth(f) * 360f; frame = 4
                    kx = 0.85f; ky = 0.85f; offY = 10f
                    follow = 1f
                } else follow = 0.5f
            }
            P_AIR -> {
                if (vy < -20f) {
                    // launch: long reaching pose, stretched upward
                    frame = 6; rot = -10f
                    ky = 1.07f; kx = 0.95f
                } else if (vy > 260f) {
                    // falling fast: compact, head down a little
                    frame = 4; rot = (vy * 0.045f).coerceIn(10f, 28f)
                    ky = 1.08f; kx = 0.94f
                } else {
                    // apex: hang for a beat
                    frame = 5; rot = 4f
                }
                if (airT < 0.06f && jumped) frame = 4     // spring off the ground (squash comes from sqz)
                // obstacle awareness: heading into a wall below its roofline -> swing the feet toward it;
                // coming down onto a roof -> level out and reach with the legs
                run {
                    val wd = wallAhead()
                    if (wd < 60f && vx > 40f) {
                        val k = 1f - (wd / 60f).coerceIn(0f, 1f)
                        frame = 4; rot = -38f * k; follow = 0.45f
                    } else if (vy > 150f && roofBelow() < 30f) {
                        frame = 6; rot = 0f; ky = 1.06f; kx = 0.96f; follow = 0.5f
                    }
                }
                if (canFlip && jumpStyle >= 0) {
                    val f = ((airT - 0.08f) / JUMP_DUR[jumpStyle]).coerceIn(0f, 1f)
                    if (f < 1f && f > 0f) {
                        follow = 1f
                        when (jumpStyle) {
                            0 -> { rot = smooth(f) * 360f; frame = 4; kx = 0.88f; ky = 0.88f }
                            1 -> { rot = -smooth(f) * 360f; frame = 4; kx = 0.9f; ky = 0.9f }
                            2 -> {
                                // corkscrew: two turns around the vertical axis
                                frame = 5; rot = -6f
                                kx = cos(f * 4f * Math.PI).toFloat()
                                if (Math.abs(kx) < 0.2f) kx = if (kx < 0f) -0.2f else 0.2f
                                ky = 1.05f
                            }
                            3 -> {
                                // hero glide: stretched out, nose up then level
                                frame = 6; rot = -18f + 20f * smooth(f)
                                kx = 1.08f; ky = 0.95f; ghosts = 1
                            }
                            4 -> { rot = smooth(f) * 720f; frame = 4; kx = 0.8f; ky = 0.8f; ghosts = 1 }
                            else -> {
                                // wide leap
                                frame = 3; rot = -sin(f * Math.PI).toFloat() * 12f
                                kx = 1.06f; ky = 0.97f
                            }
                        }
                    }
                }
                if (boostFlyT > 0f) {
                    // explosive boost: legs extended, arms open, streaking along the flight path
                    val bang = Math.toDegrees(atan2(vx.toDouble(), -vy.toDouble())).toFloat()
                    frame = 6; rot = ((bang - 90f) * 0.8f).coerceIn(-70f, 70f)
                    kx = 1.15f; ky = 0.9f; ghosts = 3; follow = 0.45f
                }
                if (kickT > 0f) {
                    // wall kick: body flung away from the wall
                    frame = 6; rot = -32f * (kickT / 0.35f); kx = 1.08f; ky = 0.94f
                    follow = 0.6f
                }
                if (slideBuf > 0f && vy > 300f) {
                    // dive: head down, aiming for a landing slide
                    frame = 6; rot = 62f; kx = 1.1f; ky = 0.92f
                    follow = 0.5f; ghosts = 2
                }
                if (shootT > 0f) frame = 5
                if (vx > 260f) ghosts = 1
            }
            P_SLIDE -> {
                // lying back, feet first, skidding along the roof
                val inK = ((0.65f - slideT) / 0.1f).coerceIn(0f, 1f)
                val outK = (slideT / 0.15f).coerceIn(0f, 1f)
                val q = smooth(min(inK, outK))
                frame = 3
                rot = -74f * q; offY = 20f * q; offX = -4f * q
                kx = 1.04f; ky = 0.96f
                follow = 0.6f; ghosts = 1
            }
            P_SWING -> {
                rot = Math.toDegrees(atan2((ax - px).toDouble(), -(ay - (py - 11f)).toDouble())).toFloat()
                val sp = sqrt(vx * vx + vy * vy)
                frame = if (shootT > 0f) 5 else if (sp > 250f || px > ax) 6 else 0
                if (frame == 0) { hx = 7f; hy = -27f }
                // stretch out along the swing at speed, like a pendulum whip
                val k = ((sp - 150f) / 350f).coerceIn(0f, 1f)
                kx = 1f + 0.10f * k; ky = 1f - 0.05f * k
                follow = 0.7f
                if (sp > 300f) ghosts = 2
            }
            P_ZIP -> {
                val ang = Math.toDegrees(atan2(vx.toDouble(), -vy.toDouble())).toFloat()
                rot = (ang - 90f).coerceIn(-75f, 75f)
                frame = if (zipT < 0.08f) 5 else 6
                hx = 24f; hy = -11f
                // streak toward the target
                kx = 1.16f; ky = 0.88f
                follow = 0.6f
                ghosts = 3
                if (boostPreT > 0f) {
                    // pre-boost: pull in, knees bent
                    frame = 4; kx = 1.12f; ky = 0.8f; ghosts = 0; follow = 0.8f
                } else {
                    val ddx = zTx - px; val ddy = zTy - py
                    val dz = sqrt(ddx * ddx + ddy * ddy)
                    if (dz < 46f) {
                        // corner approach: straighten up and brace for the edge
                        frame = 5; rot *= dz / 46f; kx = 1.04f; ky = 0.96f; ghosts = 1
                    }
                }
            }
            P_CORNER -> {
                val e = 0.38f - cornerT
                if (e < 0.14f) { frame = 4; kx = 1.14f; ky = 0.82f }
                else frame = IDLE0 + ((time * 8.33f).toInt() % IDLE_N)
                rot = 0f; follow = 0.6f
            }
            P_WALL -> {
                if (zipHeld) {
                    // wall run: feet planted on the wall, body lying away from it
                    rot = -90f
                    offX = -18f; offY = 4f
                    frame = runFrame(climbPhase)
                    ghosts = 1
                } else {
                    // wall climb: hugging the wall, hand over hand
                    rot = -6f
                    offX = -7f; offY = 2f
                    frame = runFrame(climbPhase)
                    kx = 0.92f
                }
                hx = 22f; hy = -11f
                follow = 0.5f
            }
            else -> {}
        }
        rotS = if (follow >= 1f) rot else lerpAngle(rotS, rot, follow)
        // layered secondary motion: squash/stretch spring + body wobble spring
        val sq = sqz.x.coerceIn(-0.4f, 0.4f)
        ky *= 1f + sq; kx *= 1f - sq * 0.6f
        if (ps == P_RUN && rollT <= 0f) offY += PVY * (1f - ky)   // keep the feet planted while squashing
        val drawRot = rotS + rotSp.x.coerceIn(-35f, 35f)
        val cr = cos(Math.toRadians(drawRot.toDouble())).toFloat()
        val sr = sin(Math.toRadians(drawRot.toDouble())).toFloat()
        handSx = sx + (offX + hx * cr - hy * sr) / WS
        handSy = sy + (-PVY + offY + hx * sr + hy * cr) / WS
        c.save()
        c.scale(1f / WS, 1f / WS)
        c.translate((sx * WS).roundToInt().toFloat(), (sy * WS).roundToInt().toFloat())
        c.translate(offX, -PVY.toFloat() + offY)
        // speed ghosts: faint copies trailing behind the hero
        if (ghosts > 0) {
            val oldA = spriteP.alpha
            for (g in ghosts downTo 1) {
                c.save()
                c.translate(-vx * 0.022f * g, -vy * 0.022f * g)
                c.rotate(drawRot, 0f, 0f)
                c.scale(kx, ky, 0f, 0f)
                spriteP.alpha = 70 / g
                drawFrame(c, frame)
                c.restore()
            }
            spriteP.alpha = oldA
        }
        c.rotate(drawRot, 0f, 0f)
        c.scale(kx, ky, 0f, 0f)
        drawFrame(c, frame)
        c.restore()
    }

    private fun drawHud(c: Canvas) {
        text(c, "${meters()} M", 8f, 16f, 14f, WHITE)
        text(c, "BEST $best", 8f, 27f, 8f, CREAM)
        if (boostT > 0f) {
            rc(c, 8, 31, 38, 4, INK)
            rc(c, 9, 32, (36f * min(1f, boostT / 5f)).toInt(), 2, K(0xFFE27A))
            text(c, "BOOST", 50f, 36f, 7f, K(0xFFE27A))
        }
        if (toastT > 0f) text(c, toast, lw / 2f, 60f, 16f, K(0xFFE27A), true)
        if (startT > 0f) text(c, "GET READY", lw / 2f, 80f, 12f, WHITE, true)
    }

    private val labels = arrayOf("JUMP", "WEB", "ZIP", "II", "SLIDE")

    private fun drawButtons(c: Canvas) {
        val a = (opac * 255).toInt()
        for (k in 0 until NB) {
            val cx = bx[k] * lw; val cy = by[k] * LH; val r = bs[k] / 2f
            p.style = Paint.Style.FILL
            p.color = ((if (btnDown[k]) min(255, a + 70) else a) shl 24) or 0x1E2A3A
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f
            p.color = if (st == ST_EDIT && sel == k) K(0xFFE27A) else ((min(255, a + 60)) shl 24) or 0xFFFFFF
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.FILL
            p.textSize = max(7f, r * 0.42f); p.textAlign = Paint.Align.CENTER
            p.color = ((min(255, a + 90)) shl 24) or 0xFFFFFF
            c.drawText(labels[k], cx, cy + p.textSize * 0.35f, p)
        }
    }

    private fun drawItem(c: Canvas, m: Item) {
        val x = m.x.toInt(); val y = m.y.toInt(); val w = m.w.toInt(); val h = m.h.toInt()
        rc(c, x - 1, y - 1, w + 2, h + 2, INK)
        rc(c, x, y, w, h, if (m.id == ID_PLAY) RED else BLUE)
        rc(c, x, y, w, 2, if (m.id == ID_PLAY) K(0xE86A5A) else LIGHTB)
        text(c, label(m.id), m.x + m.w / 2f, m.y + m.h / 2f + 4f, 10f, WHITE, true)
    }

    private fun drawMenu(c: Canvas) {
        text(c, "ROOFTOP HERO", 24f, 44f, 28f, K(0xD62828))
        text(c, "RUN. SWING. ZIP.", 26f, 60f, 10f, WHITE)
        for (m in menuItems) drawItem(c, m)
        text(c, "BEST $best M   RUNS $runs   TOTAL $totalM M", 24f, 210f, 8f, WHITE)
        text(c, "HOLD WEB NEAR A SIGNAL  -  ZIP IN THE AIR", 156f, 205f, 7f, CREAM)
        if (suit == 0 && best < SUIT_REQ[1]) text(c, "UNLOCK SUITS: 500 M / 1500 M", 156f, 214f, 7f, CREAM)
    }

    private fun drawOver(c: Canvas) {
        dim(c)
        text(c, "WIPEOUT!", lw / 2f, 50f, 24f, K(0xFF6A5A), true)
        text(c, "${meters()} M", lw / 2f, 84f, 20f, WHITE, true)
        text(c, "BEST $best M", lw / 2f, 102f, 10f, CREAM, true)
        text(c, "RUNS $runs  TOTAL $totalM M", lw / 2f, 120f, 8f, CREAM, true)
        for (m in overItems) drawItem(c, m)
    }

    private fun drawDiag(c: Canvas) {
        val y0 = if (st == ST_PLAY) 52f else 12f
        text(c, "FPS ${fpsAvg.roundToInt()}  FRAME ${"%.1f".format(frameMs)} MS", 8f, y0, 7f, K(0xB6FFB6))
        text(c, "BUILDINGS ${visB}/${world.size}  PARTICLES $activeP", 8f, y0 + 9f, 7f, K(0xB6FFB6))
        text(c, "MEM $memMb MB  SEED $runSeed", 8f, y0 + 18f, 7f, K(0xB6FFB6))
        val al = anim.debugLines()
        for (k in al.indices) text(c, al[k], 8f, y0 + 30f + 9f * k, 7f, K(0xFFE9A8))
        val modeName = arrayOf("RUN", "AIR", "SWING", "ZIP", "WALL", "SLIDE", "CORNER")[ps.coerceIn(0, 6)]
        val zd = if (ps == P_ZIP) sqrt((zTx - px) * (zTx - px) + (zTy - py) * (zTy - py)).toInt() else -1
        val boostWin = ps == P_ZIP && boostPreT <= 0f && zipT > 0.06f && zd > 14
        val ex = arrayOf(
            "MODE $modeName  COLL ${if (wallHit) "WALL" else if (supported()) "GROUND" else "NONE"}  STYLE $stylePts",
            "ANCHOR ${if (ps == P_SWING) "${ax.toInt()},${ay.toInt()} ROPE ${ropeL.toInt()}" else "-"}  ZIPTGT ${if (ps == P_ZIP) "${zTx.toInt()},${zTy.toInt()} D$zd" else if (indZip) "${iZx.toInt()},${iZy.toInt()}" else "-"}",
            "CORNER ${if (ps == P_ZIP && zipCombo) "APPROACH" else if (ps == P_CORNER) "REACHED" else "-"}  BOOSTWIN ${if (boostWin) "OPEN" else "closed"}  COMBO ${"%.2f".format(comboWindow)}S"
        )
        for (k in ex.indices) text(c, ex[k], 8f, y0 + 30f + 9f * (al.size + k), 7f, K(0xFFE9A8))
    }
}
