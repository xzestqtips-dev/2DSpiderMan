package com.example.spiderrunner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure-JVM tests: scripted physics snapshots drive the state machine. */
class AnimStateMachineTest {
    private val dt = 1f / 120f

    private fun AnimStateMachine.run(secs: Float, f: AnimInput.() -> Unit) {
        val n = (secs / dt).toInt()
        repeat(n) { input().apply(f); update(dt) }
    }

    private fun AnimInput.ground(v: Float) { mode = GameView.P_RUN; grounded = true; vx = v; vy = 0f; landT = 0f; startT = 0f }

    @Test fun idleRunSprintHysteresis() {
        val sm = AnimStateMachine()
        sm.run(0.3f) { ground(0f) }; assertEquals(AnimState.IDLE, sm.current)
        sm.run(0.3f) { ground(150f) }; assertEquals(AnimState.RUN, sm.current)
        sm.run(0.3f) { ground(230f) }; assertEquals(AnimState.SPRINT, sm.current)
        sm.run(0.3f) { ground(215f) }; assertEquals("no flicker inside the hysteresis band", AnimState.SPRINT, sm.current)
        sm.run(0.3f) { ground(190f) }; assertEquals(AnimState.RUN, sm.current)
    }

    @Test fun repeatedJumpsNeverDropInput() {
        val sm = AnimStateMachine()
        repeat(20) {
            sm.run(0.2f) { ground(200f) }
            sm.run(0.05f) { mode = GameView.P_AIR; grounded = false; jumped = true; airT = 0.02f; vy = -300f; vx = 200f }
            assertEquals(AnimState.JUMP_TAKEOFF, sm.current)
            sm.run(0.3f) { mode = GameView.P_AIR; jumped = true; airT = 0.3f; vy = 200f }
        }
    }

    @Test fun landingInterruptsTrick() {
        val sm = AnimStateMachine()
        sm.noteTrick(0, 0.5f)
        sm.run(0.2f) { mode = GameView.P_AIR; grounded = false; airT = 0.3f; vy = 50f }
        assertEquals(AnimState.AIR_FRONTFLIP, sm.current)
        sm.noteLanding(GameView.LK_SOFT, 200f, 200f)
        sm.run(0.02f) { ground(200f); landT = 0.13f }
        assertEquals(AnimState.LAND_LIGHT, sm.current)
    }

    @Test fun swingReleaseFiresVoiceHookAndKeepsRunning() {
        val sm = AnimStateMachine()
        var released = 0
        sm.listener = { _, to -> if (to == AnimState.SWING_RELEASE) released++ }
        sm.run(0.3f) { mode = GameView.P_SWING; vx = 250f; vy = 100f; shootT = 0f }
        sm.noteRelease()
        sm.run(0.05f) { mode = GameView.P_AIR; grounded = false; airT = 0.02f; vx = 260f; vy = 90f; jumped = false }
        assertEquals(1, released)
        sm.run(0.5f) { mode = GameView.P_AIR; airT = 0.5f; vx = 260f; vy = 90f }
        assertNotEquals(AnimState.SWING_RELEASE, sm.current)
    }

    @Test fun wallContactLossEndsWallState() {
        val sm = AnimStateMachine()
        sm.run(0.3f) { mode = GameView.P_WALL; grounded = false; vy = -70f }
        assertEquals(AnimState.WALL_CLIMB, sm.current)
        sm.run(0.2f) { mode = GameView.P_AIR; airT = 0.2f; vy = 50f; vx = 0f }
        assertTrue(sm.current.isAir)
    }

    @Test fun heavyLandingIsForcedRecoveryThenReleases() {
        val sm = AnimStateMachine()
        sm.noteLanding(GameView.LK_HERO, 520f, 100f)
        sm.run(0.05f) { ground(100f); landT = 0.5f }
        assertEquals(AnimState.LAND_HEAVY, sm.current)
        // an air request inside the lock is held, then applied
        sm.run(0.04f) { mode = GameView.P_AIR; grounded = false; jumped = true; airT = 0.01f; vy = -300f }
        assertEquals(AnimState.JUMP_TAKEOFF, sm.pending ?: sm.current)
        sm.run(0.2f) { mode = GameView.P_AIR; grounded = false; jumped = true; airT = 0.2f; vy = 100f }
        assertTrue(sm.current.isAir)
    }

    @Test fun disallowedTrickIsIgnored() {
        val sm = AnimStateMachine()
        sm.trickPermitted[2] = false
        sm.noteTrick(2, 0.5f)
        sm.run(0.2f) { mode = GameView.P_AIR; grounded = false; airT = 0.3f; vy = 50f }
        assertNotEquals(AnimState.AIR_TWIST, sm.current)
    }

    @Test fun zipApproachThenBoostPrepareThenBoost() {
        val sm = AnimStateMachine()
        sm.run(0.2f) { mode = GameView.P_ZIP; grounded = false; vx = 300f; vy = -100f; zipDist = 120f }
        assertEquals(AnimState.ZIP, sm.current)
        sm.run(0.2f) { mode = GameView.P_ZIP; zipDist = 30f }
        assertEquals(AnimState.ZIP_APPROACH, sm.current)
        sm.run(0.1f) { mode = GameView.P_ZIP; zipDist = 30f; boostPreT = 0.05f }
        assertEquals(AnimState.BOOST_PREPARE, sm.current)
        sm.run(0.1f) { mode = GameView.P_AIR; boostFlyT = 0.4f; airT = 0.05f; vx = 500f; vy = -300f }
        assertEquals(AnimState.ZIP_BOOST, sm.current)
        sm.run(0.7f) { mode = GameView.P_AIR; boostFlyT = 0f; airT = 0.7f; vx = 400f; vy = -50f }
        assertEquals(AnimState.AIR_RISE, sm.current)
    }

    @Test fun cornerReachedEntersPerch() {
        val sm = AnimStateMachine()
        sm.run(0.2f) { mode = GameView.P_ZIP; zipDist = 8f }
        sm.run(0.2f) { mode = GameView.P_CORNER; grounded = true; vx = 0f; vy = 0f }
        assertEquals(AnimState.CORNER_PERCH, sm.current)
    }

    @Test fun vaultKeepsStateThenLands() {
        val sm = AnimStateMachine()
        sm.noteVault()
        sm.run(0.1f) { mode = GameView.P_AIR; grounded = false; airT = 0.05f; vx = 200f; vy = -250f }
        assertEquals(AnimState.VAULT_EXECUTE, sm.current)
        sm.run(0.6f) { mode = GameView.P_AIR; airT = 0.5f; vx = 200f; vy = 100f }
        assertTrue(sm.current.isAir)
    }

    @Test fun wallExitWithoutKick() {
        val sm = AnimStateMachine()
        sm.run(0.3f) { mode = GameView.P_WALL; grounded = false; vy = -70f }
        sm.run(0.03f) { mode = GameView.P_AIR; kickT = 0f; airT = 0.01f; vy = 20f; vx = 0f }
        assertEquals(AnimState.WALL_EXIT, sm.current)
    }

    @Test fun trickCompletionAwardedOnlyIfNotCutByLanding() {
        val sm = AnimStateMachine()
        var done = 0
        sm.onTrickComplete = { done++ }
        sm.noteTrick(0, 0.2f)
        sm.run(0.3f) { mode = GameView.P_AIR; grounded = false; airT = 0.3f; vy = 50f }
        assertEquals(1, done)
        sm.noteTrick(1, 0.5f)
        sm.run(0.1f) { mode = GameView.P_AIR; airT = 0.2f; vy = 80f }
        sm.run(0.1f) { ground(200f) }
        sm.run(0.5f) { ground(200f) }
        assertEquals("landing cut the trick short", 1, done)
    }
}
