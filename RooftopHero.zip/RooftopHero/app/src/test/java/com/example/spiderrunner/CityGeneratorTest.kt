package com.example.spiderrunner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.min

/** Pure-JVM checks of the procedural city: fairness, placement rules and seeded reproducibility. */
class CityGeneratorTest {
    private val speed = 170f
    private val reach = speed * 0.46f

    private class City(val buildings: ArrayList<Building>, val props: ArrayList<Building>, val anchors: ArrayList<Anchor>, val all: ArrayList<Building>)

    private fun build(seed: Long, n: Int, diff: Float): City {
        val gen = CityGenerator(); gen.reset(seed, -120f)
        val world = ArrayDeque<Building>(); val anchors = ArrayList<Anchor>()
        repeat(n) { gen.spawn(world, anchors, diff, speed) }
        val all = ArrayList(world)
        return City(ArrayList(all.filter { it.kind == BK_BUILDING }), ArrayList(all.filter { it.kind == BK_PROP }), anchors, all)
    }

    @Test fun sameSeedGivesSameCity() {
        val a = build(1234L, 150, 0.7f); val b = build(1234L, 150, 0.7f)
        assertEquals(a.all.size, b.all.size); assertEquals(a.anchors.size, b.anchors.size)
        for (i in a.all.indices) {
            assertEquals(a.all[i].x, b.all[i].x, 0f); assertEquals(a.all[i].top, b.all[i].top, 0f)
            assertEquals(a.all[i].ptype, b.all[i].ptype); assertEquals(a.all[i].decor.size, b.all[i].decor.size)
        }
        for (i in a.anchors.indices) { assertEquals(a.anchors[i].x, b.anchors[i].x, 0f); assertEquals(a.anchors[i].kind, b.anchors[i].kind) }
        val c = build(99L, 150, 0.7f)
        assertTrue("different seeds should differ", a.all.indices.any { it >= c.all.size || a.all[it].top != c.all[it].top })
    }

    @Test fun worldStaysSortedByX() {
        val c = build(7L, 300, 0.5f)
        for (i in 1 until c.all.size) assertTrue("x order at $i", c.all[i].x >= c.all[i - 1].x)
    }

    @Test fun heightsCoverShortToSkyscraper() {
        val c = build(42L, 600, 1f)
        val tiers = c.buildings.map { CityGenerator.tierOf(it.top) }.toSet()
        assertEquals(setOf(0, 1, 2, 3), tiers)
        val tallest = c.buildings.minOf { it.top }
        assertTrue("skyscrapers reach ~20 player heights (25 px): ${(288f - tallest) / 25f}", (288f - tallest) / 25f >= 16f)
        assertTrue(c.buildings.all { it.w >= 130f })
    }

    @Test fun roofsAreNeverRisenOrDroppedUnfairly() {
        for (seed in 1L..20L) {
            val c = build(seed, 200, 0.8f)
            for (i in 1 until c.buildings.size) {
                val p = c.buildings[i - 1]; val b = c.buildings[i]
                val gap = b.x - (p.x + p.w)
                assertTrue("rise too big", b.top >= p.top - CityGenerator.MAX_RISE - 0.01f)
                if (gap > reach) assertTrue("swing gap must land level or lower", b.top >= p.top - CityGenerator.MAX_RISE_SWING - 0.01f)
                assertTrue("gap fits a swing chain", gap <= 300f + 0.01f)
            }
        }
    }

    @Test fun everyWideGapHasAHighReachableAnchor() {
        for (seed in 1L..30L) {
            val c = build(seed, 250, 1f)
            for (i in 1 until c.buildings.size) {
                val p = c.buildings[i - 1]; val b = c.buildings[i]
                val gap = b.x - (p.x + p.w)
                if (gap <= reach * 0.85f) continue
                val l = p.x + p.w; val r = b.x; val base = min(p.top, b.top)
                val ok = c.anchors.any { it.x > l && it.x < r && it.y <= base - 46f }
                assertTrue("gap $gap at x=$l has no anchor (seed $seed)", ok)
            }
        }
    }

    @Test fun propsStandOnRoofsWithClearEnds() {
        for (seed in 1L..20L) {
            val c = build(seed, 200, 0.6f)
            val byParent = c.props.groupBy { it.parent }
            for ((parent, list) in byParent) {
                parent!!
                var lastEnd = -1e9f
                for (p in list.sortedBy { it.x }) {
                    assertTrue("prop left of runway", p.x >= parent.x + CityGenerator.EDGE_L - 0.01f)
                    assertTrue("prop right of take-off zone", p.x + p.w <= parent.x + parent.w - CityGenerator.EDGE_R + 0.01f)
                    assertEquals("prop sits on the roof", parent.top, p.top + p.h, 0.01f)
                    assertTrue("prop too tall to jump", p.h <= 36f)
                    assertTrue("props overlap", p.x >= lastEnd)
                    lastEnd = p.x + p.w
                }
            }
        }
    }

    @Test fun decorStaysOnTheRoofAndOffTheProps() {
        val c = build(5L, 300, 0.6f)
        for (b in c.buildings) for (d in b.decor) {
            assertTrue(d.dx >= CityGenerator.EDGE_L - 0.01f && d.dx + d.w <= b.w - CityGenerator.EDGE_R + 0.01f)
            for (p in c.props) if (p.parent === b) assertTrue("decor overlaps prop", d.dx + d.w <= p.x - b.x || d.dx >= p.x + p.w - b.x)
        }
    }

    @Test fun allSwingStructuresAppear() {
        val kinds = HashSet<Int>()
        for (seed in 1L..10L) build(seed, 300, 1f).anchors.forEach { kinds.add(it.kind) }
        assertEquals(setOf(AK_CRANE, AK_TOWER, AK_BOARD, AK_TANK, AK_SCAFF, AK_BEAM, AK_POLE), kinds)
    }
}
