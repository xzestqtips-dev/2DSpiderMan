# RooftopHero animation state machine

Code: `AnimStateMachine.kt`. Physics (`GameView.physics`) stays authoritative; the state machine
observes a per-step `AnimInput` snapshot, picks a named state, applies the transition rule and fires
entry hooks. It never writes velocity (all rules `keepVelocity = true`, `rootMotion = false`).

## Physics mode -> animation states
| Physics mode | States |
|---|---|
| RUN | IDLE, RUN, SPRINT, LAND_LIGHT/MEDIUM/HEAVY/ROLL, LAND_RECOVER, EDGE_CLIMB |
| SLIDE | SLIDE |
| AIR | VAULT_EXECUTE, WALL_EXIT, JUMP_TAKEOFF, AIR_RISE, AIR_FALL, AIR_FAST_FALL, AIR_FRONTFLIP/BACKFLIP/TWIST/STYLE/DOUBLEFLIP, SWING_RELEASE, WALL_KICK, ZIP_BOOST |
| SWING | SWING_START, SWING_RISING, SWING_APEX, SWING_DESCENDING, SWING_FAST, SWING_TURNING |
| ZIP | ZIP, ZIP_APPROACH (target within 45 px), BOOST_PREPARE (boostPreT > 0) |
| WALL | WALL_ENTER, WALL_CLIMB, WALL_RUN |
| CORNER | CORNER_PERCH |

## Entry conditions (resolve order, first match wins)
- RUN mode: edge top-out -> EDGE_CLIMB; landing timer -> LAND_*; recover window -> LAND_RECOVER; startT>0 or vx<8 -> IDLE; vx>=225 (exit <205) -> SPRINT; else RUN.
- AIR mode: wall kick -> WALL_KICK; boost flight -> ZIP_BOOST; release window -> SWING_RELEASE; live trick -> trick state; jumped and airT<0.12 and rising -> JUMP_TAKEOFF; vy>460 -> AIR_FAST_FALL; vy>40 -> AIR_FALL; else AIR_RISE.
- SWING mode: shootT>0 -> START; vx<30 -> TURNING; speed>350 -> FAST; |vy|<45 -> APEX; vy<0 -> RISING; else DESCENDING.
- WALL mode: first 0.10 s -> WALL_ENTER; zip held -> WALL_RUN; else WALL_CLIMB.

## Priority and interruption
Priority (high to low): CRITICAL (LAND_HEAVY), TRAVERSAL (wall/zip/corner/edge), MOVEMENT (jump/swing/air/landing), TRICK, LOCOMOTION.
A request interrupts if strictly higher priority, or the current state's `lockT` has elapsed. Blocked requests are re-resolved every step (shown as `HOLD>` in the debug panel), never dropped.
Landing (MOVEMENT) always interrupts tricks (TRICK).

## Transition table (duration s / curve)
| From -> To | Dur | Curve |
|---|---|---|
| default | 0.10 | smooth |
| IDLE -> RUN | 0.15 | smooth |
| RUN <-> SPRINT | 0.20 | smooth |
| any -> IDLE | 0.20 | smooth |
| any -> SLIDE | 0.06 | ease-out |
| any -> JUMP_TAKEOFF | 0.05 | ease-out |
| JUMP_TAKEOFF -> any | 0.12 | smooth |
| any -> AIR_FAST_FALL | 0.10 | ease-in |
| any -> LAND_* (HEAVY 0.03) | 0.05 | ease-out |
| LAND_* -> any | 0.12 | smooth |
| any -> LAND_RECOVER | 0.10 | smooth |
| any -> trick / trick -> any | 0.06 / 0.18 | ease-out / smooth |
| any -> SWING_START / SWING_START -> any | 0.06 / 0.10 | ease-out / smooth |
| any -> SWING_x substate | 0.12 | smooth |
| any -> SWING_RELEASE / -> any | 0.04 / 0.16 | ease-out / smooth |
| any -> ZIP / ZIP_BOOST / CORNER_PERCH | 0.05 / 0.04 / 0.06 | ease-out |
| any -> WALL_* / WALL_* -> any | 0.04 / 0.08 | ease-out / smooth |
| any -> EDGE_CLIMB | 0.08 | smooth |

All durations scale with `AnimStateMachine.durationScale`. Trick permissions: `trickPermitted[0..5]`.

## Voice hooks
Existing hooks (via `animEvent`): jump, swing start, long fall (AIR_FAST_FALL equivalent), wall kick / zip whoa.
New, fired on state entry: SWING_RELEASE "Let's keep moving.", AIR_TWIST/AIR_DOUBLEFLIP "Nice!", LAND_HEAVY "That was a rough landing."
Voice never blocks transitions (`VoiceDirector` is fire-and-forget with cooldowns, one voice at a time, priority).

## Adaptations from the 3D prompt
Side-scroller sprite game, so: no Jump_Prepare (impulse is instant; the crouch is a squash spring), no directional air blends
(travel is always forward), no wall-crawl/vault/hang states, no IK, foot locking, motion matching or animation layers.

## Added in the traversal pass
| State | Entry | Blend | Notes |
|---|---|---|---|
| ZIP_APPROACH | zipping, distance to target < 45 px | 0.08 ease-out | physics already eases speed to 150 + 9*d |
| BOOST_PREPARE | Jump during zip, `boostPreT > 0` | 0.04 ease-out | stored momentum captured; ends in ZIP_BOOST |
| VAULT_EXECUTE | ran or flew into a rooftop edge <= 26 px above feet at speed | 0.05 ease-out | real impulse + gravity, speed kept, wall latch suppressed 0.4 s |
| WALL_EXIT | wall contact lost, no kick | 0.08 smooth | 0.14 s window |

Boost input window: open only while zipping, after 0.06 s, with more than 14 px to go, and not already preparing.
Jump buffer is cleared when a zip starts and when the corner is reached, so a stale tap cannot boost.
Simultaneous Swing + Zip window: `GameView.comboWindow` (default 0.12 s).
Style points: +50 per completed trick, +100 for a double flip; a landing that cuts a trick short awards none.

Not implemented (see summary): WALL_TURN, Vault_Prepare, Edge_Approach, Edge_Hang, wall-crawl, trick anticipation-specific art.
