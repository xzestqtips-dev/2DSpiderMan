# City generation (CityGenerator.kt)

## Layout of the system
- `Building` rectangles (x, w, top, infinitely deep) are still the only things the physics collides with.
  `kind = BK_PROP` entries are **solid rooftop props** stored in the same x-sorted list, so landing, wall hits,
  vaulting (<= 26 px) and wall-climb work on them with no new collision code.
- `Decor` (antennas, dishes, pipes, solar panels, stacks, rebar columns...) is draw-only: no collision, no web target.
- `Anchor` is the **only** web target. Each anchor is a structure that is drawn exactly where it attaches:
  crane jib hook, tower tip, billboard frame top, water-tank frame top, scaffold top beam, cantilever steel beam,
  facade flag pole. `findAnchor()` still applies the old rules (40-300 px, >= 35 px above the hero, clear line).
- Background layers (`cityLayer`) are decorative only and are never anchors.
- `FIXED_SEED` in `GameView.companion` replays the same city every run; the diagnostics overlay shows the seed.

## Heights (street = y 288, hero ~ 25 px tall)
| tier | roof y | height | x hero |
|---|---|---|---|
| short | 100..176 | 112-188 | 4.5-7.5 |
| medium | 10..100 | 188-278 | 7.5-11 |
| tall | -110..10 | 278-398 | 11-16 |
| skyscraper | -250..-110 | 398-538 | 16-21 |

Next roof may be at most 90 px higher (wall climb / corner zip), or 18 px higher after a swing-only gap; any drop up to 280.
Tier unlock by distance: medium+short from the start, tall after ~100 m, skyscrapers after ~300 m.
Roof length 130-480 px (tier based, +80..200 for the odd very long roof, narrowed up to 20% with difficulty).
Gaps: hop 12..(0.25 reach+18), jump 0.45 reach+10 .. 0.95 reach+10, swing 1.5 reach .. 300 px (reach = 0.46 x run speed).

## Fairness rules
- Left 40 px and right 34 px of every roof are always empty (landing runway / take-off zone / crane masts).
- Props are 7-34 px tall: <= 26 px auto-vault, taller ones need a jump or a wall climb. 25% of roofs are bare.
- Every gap wider than 0.85 reach gets a crane (or beam) whose hook is >= 48 px above BOTH roofs; gaps >= 190 px get two hooks on one jib so swings chain.
- Taller facades (>= 100 px drop) can also carry a flag pole to swing from.
- Free-standing swing structures (billboard, water tank, tower, scaffold, roof crane) stand on ~45% of wide roofs, >= 46 px high so the hero can run under the board / tank.

## Verified
`tools/swing_sim.py` ports the swing / air physics and sweeps 144 bot timings per case: every gap size 100-300 px at 105, 170 and 240 px/s
has landing routes (see the table in the chat summary). `CityGeneratorTest` checks determinism, sort order, tiers, fairness, prop placement, decor overlap and anchor coverage.
