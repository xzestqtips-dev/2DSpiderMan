import math, random, itertools
G=1100.0; DT=1/120; JUMP_V=335.0; HW=4.0; DEATH=296.0

def anchors_for_gap(g, tl, tr, rnd, cfg):
    """returns list of (ax, ay) with x relative to left roof's right edge (x=0), y absolute"""
    base=min(tl,tr)
    n = 1 if g < cfg['two'] else 2
    out=[]
    if n==1:
        H = cfg['h0'] + cfg['hg']*g + rnd.random()*cfg['hr']
        out.append((g*0.5, base-H))
    else:
        H1 = cfg['h0'] + cfg['hg']*g*0.75 + rnd.random()*cfg['hr']
        H2 = cfg['h0'] + cfg['hg']*g*0.75 + rnd.random()*cfg['hr']
        out.append((g*cfg['f1'], base-H1)); out.append((g*cfg['f2'], base-H2))
    return out

def blocked(x1,y1,x2,y2,bl):
    for s in range(1,8):
        t=s/8; sx=x1+(x2-x1)*t; sy=y1+(y2-y1)*t
        for (bx,bw,bt) in bl:
            if bx>sx: break
            if sx<=bx+bw and sy>bt: return True
    return False

def find_anchor(px,py,ans,bl):
    cy=py-11; best=None; bd=1e9
    for (ax,ay) in ans:
        if ax<px+8: continue
        dx=ax-px; dy=ay-cy; d=math.hypot(dx,dy)
        if d>300 or d<40 or ay>py-35: continue
        if blocked(px,cy,ax,ay,bl): continue
        if d<bd: bd=d; best=(ax,ay)
    return best

def run(g, tl, tr, ts, ans, jump_at_edge, press_delay, rel_frac, rel2_frac, press2_delay):
    bl=[(-400,400,tl),(g,400,tr)]
    px,py=-6.0,tl; vx=ts; vy=0.0
    if jump_at_edge: vy=-JUMP_V
    ps='AIR'; t=0.0; ax=ay=ropeL=0; nswing=0; tsw=0.0; air_since=0.0; latest=0
    while t<8:
        t+=DT; air_since+=DT
        if ps=='AIR':
            if vx<ts: vx+=160*DT
            vy=min(vy+G*DT,720)
            # x move
            nx=px+vx*DT
            if py>tr+2 and px+HW<=g+0.5 and nx+HW>g:
                # wall hit
                return ('latch' if py-tr<=260 else 'wallhigh', t, py) if py>tr+26 else ('vault',t,py)
            px=nx
            pf=py; py+=vy*DT
            if vy>=0:
                for (bx,bw,bt) in bl:
                    if px+HW-1>bx and px-HW+1<bx+bw and pf<=bt+0.01 and py>=bt:
                        if bx==g: return ('land',t,py)
                        py=bt; vy=0  # landed back left roof
                        return ('backland',t,py)
            if py>DEATH: return ('death',t,py)
            # swing press
            want = press_delay if nswing==0 else press2_delay
            if air_since>=want and nswing<2 and t>0.02:
                a=find_anchor(px,py,ans,bl)
                if a:
                    ax,ay=a; ropeL=math.hypot(ax-px,ay-(py-11)); ropeMin=ropeL*0.6
                    ps='SWING'; nswing+=1; tsw=0
        else:
            tsw+=DT
            oxp=px; oyp=py-11
            vy=min(vy+G*DT,720)
            sp0=math.hypot(vx,vy)
            if sp0<260: vx+=55*DT
            dgm=0.00025*sp0*DT; vx-=vx*dgm; vy-=vy*dgm
            if py-11>ay+24: ropeL=max(ropeMin,ropeL-14*DT)
            nx=px+vx*DT
            if py>tr+2 and px+HW<=g+0.5 and nx+HW>g:
                return ('latch' if py-tr<=260 else 'wallhigh', t, py) if py>tr+26 else ('vault',t,py)
            px=nx
            pf=py; py+=vy*DT
            if vy>=0:
                for (bx,bw,bt) in bl:
                    if px+HW-1>bx and px-HW+1<bx+bw and pf<=bt+0.01 and py>=bt:
                        return ('land' if bx==g else 'backland',t,py)
            ddx=px-ax; ddy=(py-11)-ay; d=math.hypot(ddx,ddy)
            if d>ropeL:
                k=ropeL/d; px=ax+ddx*k; py=ay+ddy*k+11
                vx=(px-oxp)/DT; vy=(py-11-oyp)/DT
            sp=math.hypot(vx,vy)
            if sp>430: vx*=430/sp; vy*=430/sp
            if py>DEATH: return ('death',t,py)
            frac = rel_frac if nswing==1 else rel2_frac
            if px>ax+frac*ropeL*0 + frac*ropeL:
                # release
                spr=math.hypot(vx,vy)
                if spr>60:
                    vx*=1.05; vy*=1.05
                    if vy<0: vy-=25
                ps='AIR'; air_since=0.0
    return ('timeout',t,py)

def success_rate(g, tl, tr, ts, cfg, rnd):
    ans=anchors_for_gap(g,tl,tr,rnd,cfg)
    ok=False; best='death'
    for ja in (False,True):
      for pd in (0.0,0.15,0.3):
        for rf in (0.0,0.25,0.5,0.75):
          for rf2 in (0.0,0.3,0.6):
            for p2 in (0.0,0.1):
              r=run(g,tl,tr,ts,ans,ja,pd,rf,rf2,p2)[0]
              if r in ('land','latch','vault'): return True, ans
    return False, ans

if __name__=='__main__':
    import sys
    cfg=dict(two=190,h0=48,hg=0.30,hr=16,f1=0.3,f2=0.72)
    rnd=random.Random(1)
    for ts in (105,150,200,240):
        print('speed',ts)
        for g in (120,160,200,240,280,300):
            res=[]
            for dtr in (-18,0,40,100):
                tl=150
                ok,ans=success_rate(g,tl,tl+dtr,ts,cfg,rnd)
                res.append(ok)
            print('  gap',g,res)
